import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID, ARRAY

from app.db.database import Base


class GoogleAccount(Base):
    """
    A workspace's connected Google identity — covers Search Console + GA4.
    OAuth refresh token is stored ENCRYPTED (app.core.security.encrypt_token),
    never in plaintext, per spec section 46.
    """
    __tablename__ = "google_accounts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    google_email = Column(String, nullable=False)
    encrypted_refresh_token = Column(Text, nullable=False)
    scopes = Column(ARRAY(String), default=list)
    connected_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
