import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class MediaAsset(Base):
    """
    Section 53 — uploaded video/image files. Stored in S3-compatible object
    storage (never in Postgres — spec section 53: "Do not store large media
    directly in the database"). The `public_url` this produces is what
    feeds into TikTok's draft-upload (needs a public video_url), Meta's
    post/ad creative, and the campaign wizard.
    """
    __tablename__ = "media_assets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    filename = Column(String, nullable=False)
    content_type = Column(String, nullable=False)  # video/mp4, image/jpeg, etc.
    size_bytes = Column(Integer, nullable=True)
    storage_key = Column(String, nullable=False)  # path/key inside the bucket
    public_url = Column(String, nullable=False)
    uploaded_by_user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
