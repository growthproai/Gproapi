import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, JSON
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class SEOAudit(Base):
    """Technical + on-page audit result (spec section 6-7, 65)."""
    __tablename__ = "seo_audits"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    website_id = Column(UUID(as_uuid=True), ForeignKey("websites.id"), nullable=False, index=True)
    score_overall = Column(Integer, nullable=False)
    score_breakdown = Column(JSON, nullable=False)   # {"technical":.., "onpage":.., "content":.., "schema":..}
    issues = Column(JSON, nullable=False)             # [{problem, why_it_matters, priority, fix}, ...]
    source_note = Column(String, default="ai-content-analysis")  # distinguishes from a real crawler run
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class KeywordSet(Base):
    """One keyword-research run (spec section 8-9)."""
    __tablename__ = "keyword_sets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    seed_topic = Column(String, nullable=False)
    location = Column(String, nullable=True)
    data = Column(JSON, nullable=False)  # primary/long_tail/questions/local/clusters
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
