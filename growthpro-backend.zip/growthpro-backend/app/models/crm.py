import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Enum, Integer, Text
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class LeadStatus(str, enum.Enum):
    new = "new"
    qualified = "qualified"
    contacted = "contacted"
    proposal = "proposal"
    negotiation = "negotiation"
    won = "won"
    lost = "lost"


class LeadTemperature(str, enum.Enum):
    hot = "hot"
    warm = "warm"
    cold = "cold"


class Contact(Base):
    """Section 38 — CRM contact. A Lead converts into a Contact once qualified."""
    __tablename__ = "contacts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    company_name = Column(String, nullable=True)
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Lead(Base):
    """Sections 36-37 — a raw lead before/while it's being qualified, with AI-scored temperature."""
    __tablename__ = "leads"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    contact_id = Column(UUID(as_uuid=True), ForeignKey("contacts.id"), nullable=True)
    name = Column(String, nullable=False)
    email = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    source = Column(String, default="manual")  # website | landing_page | ads | social | form | api | wordpress | manual
    campaign = Column(String, nullable=True)
    product_interest = Column(String, nullable=True)
    estimated_value = Column(Integer, nullable=True)  # smallest currency unit (cents/fils) to avoid float rounding
    status = Column(Enum(LeadStatus), default=LeadStatus.new)
    temperature = Column(Enum(LeadTemperature), nullable=True)
    temperature_reason = Column(Text, nullable=True)  # AI's plain-language "why hot/warm/cold"
    notes = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Deal(Base):
    """Section 39 — sales pipeline entry, one per Contact per opportunity."""
    __tablename__ = "deals"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    contact_id = Column(UUID(as_uuid=True), ForeignKey("contacts.id"), nullable=True)
    lead_id = Column(UUID(as_uuid=True), ForeignKey("leads.id"), nullable=True)
    title = Column(String, nullable=False)
    stage = Column(Enum(LeadStatus), default=LeadStatus.new)
    value = Column(Integer, nullable=True)  # smallest currency unit
    probability_percent = Column(Integer, default=50)
    source = Column(String, nullable=True)
    campaign = Column(String, nullable=True)
    owner_user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
    closed_at = Column(DateTime(timezone=True), nullable=True)


class CrmTask(Base):
    """Follow-up tasks (section 38-40) — what a salesperson needs to do next on a lead/deal."""
    __tablename__ = "crm_tasks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    lead_id = Column(UUID(as_uuid=True), ForeignKey("leads.id"), nullable=True)
    deal_id = Column(UUID(as_uuid=True), ForeignKey("deals.id"), nullable=True)
    title = Column(String, nullable=False)
    due_at = Column(DateTime(timezone=True), nullable=True)
    completed = Column(String, default="pending")  # pending | done
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
