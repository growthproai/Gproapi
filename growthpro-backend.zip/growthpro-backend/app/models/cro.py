import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Enum, JSON
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class ExperimentStatus(str, enum.Enum):
    running = "running"
    concluded = "concluded"


class Experiment(Base):
    """
    Section 34 — A/B testing. Tracks two variants of something (headline,
    CTA, page) with real visitor/conversion counters. Statistical
    significance is computed at read time (see cro.py) using a standard
    two-proportion z-test — never declares a winner on sample size alone.
    """
    __tablename__ = "experiments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    element_type = Column(String, nullable=False)  # headline | cta | image | offer | form
    variant_a = Column(JSON, nullable=False)   # {"label": "Control", "content": "..."}
    variant_b = Column(JSON, nullable=False)
    variant_a_visitors = Column(Integer, default=0)
    variant_a_conversions = Column(Integer, default=0)
    variant_b_visitors = Column(Integer, default=0)
    variant_b_conversions = Column(Integer, default=0)
    status = Column(Enum(ExperimentStatus), default=ExperimentStatus.running)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
