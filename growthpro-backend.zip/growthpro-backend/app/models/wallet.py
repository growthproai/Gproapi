import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Enum, Text
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class TransactionType(str, enum.Enum):
    topup = "topup"                # Stripe payment added funds
    ai_credit_usage = "ai_credit_usage"
    ad_spend = "ad_spend"
    media_processing = "media_processing"
    marketplace_purchase = "marketplace_purchase"
    refund = "refund"


class TransactionStatus(str, enum.Enum):
    pending = "pending"
    completed = "completed"
    failed = "failed"


class Wallet(Base):
    """Section 59 — one wallet per organization. Balance in smallest currency unit (fils/cents)."""
    __tablename__ = "wallets"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, unique=True, index=True)
    balance = Column(Integer, default=0)
    currency = Column(String, default="AED")
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class WalletTransaction(Base):
    __tablename__ = "wallet_transactions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    wallet_id = Column(UUID(as_uuid=True), ForeignKey("wallets.id"), nullable=False, index=True)
    type = Column(Enum(TransactionType), nullable=False)
    amount = Column(Integer, nullable=False)  # positive for credit, negative for debit — smallest currency unit
    status = Column(Enum(TransactionStatus), default=TransactionStatus.completed)
    stripe_payment_intent_id = Column(String, nullable=True)
    description = Column(Text, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
