import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Text
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class GoogleBusinessProfile(Base):
    """Section 11 — Local SEO: the connected Google Business Profile listing."""
    __tablename__ = "google_business_profiles"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    gbp_location_id = Column(String, nullable=True)  # Google Business Profile API location ID once connected
    business_name = Column(String, nullable=True)
    address = Column(String, nullable=True)
    phone = Column(String, nullable=True)
    category = Column(String, nullable=True)
    connected_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Review(Base):
    """Section 12 — reviews pulled from supported platforms, or logged manually."""
    __tablename__ = "reviews"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    platform = Column(String, default="google")  # google | facebook | manual
    reviewer_name = Column(String, nullable=True)
    rating = Column(Integer, nullable=False)  # 1-5
    text = Column(Text, nullable=True)
    sentiment = Column(String, nullable=True)  # positive | neutral | negative — AI-assigned
    ai_suggested_response = Column(Text, nullable=True)
    review_date = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
