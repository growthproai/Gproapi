from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, Boolean

from app.db.database import Base


class FeatureFlag(Base):
    """Section 70 — global module toggles, controlled from Super Admin. Not per-workspace, platform-wide."""
    __tablename__ = "feature_flags"

    key = Column(String, primary_key=True)  # slug, e.g. "seo_enabled", "ai_content_enabled"
    label = Column(String, nullable=False)
    is_enabled = Column(Boolean, default=True)
    updated_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc), onupdate=lambda: datetime.now(timezone.utc))
