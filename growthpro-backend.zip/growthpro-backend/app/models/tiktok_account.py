import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID, ARRAY

from app.db.database import Base


class TikTokAccount(Base):
    """A workspace's connected TikTok account (spec section 19)."""
    __tablename__ = "tiktok_accounts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    open_id = Column(String, nullable=False)
    display_name = Column(String, nullable=True)
    encrypted_access_token = Column(Text, nullable=False)
    encrypted_refresh_token = Column(Text, nullable=False)
    scopes = Column(ARRAY(String), default=list)
    connected_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
