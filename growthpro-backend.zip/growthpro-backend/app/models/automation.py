import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Enum, JSON, Boolean
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class WorkflowTrigger(str, enum.Enum):
    lead_created = "lead_created"
    lead_status_changed = "lead_status_changed"
    deal_won = "deal_won"
    deal_lost = "deal_lost"
    review_received = "review_received"


class Workflow(Base):
    """Section 41 — Marketing Automation: Trigger -> Condition -> Action."""
    __tablename__ = "workflows"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    trigger = Column(Enum(WorkflowTrigger), nullable=False)
    conditions = Column(JSON, default=list)   # [{"field": "source", "op": "equals", "value": "website"}]
    actions = Column(JSON, default=list)      # [{"type": "create_task", "params": {...}}, {"type": "notify", ...}]
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class WorkflowRun(Base):
    """Audit trail of every time a workflow actually fired (spec section 76: audit logs)."""
    __tablename__ = "workflow_runs"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workflow_id = Column(UUID(as_uuid=True), ForeignKey("workflows.id"), nullable=False, index=True)
    trigger_payload = Column(JSON, default=dict)
    actions_executed = Column(JSON, default=list)
    ran_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
