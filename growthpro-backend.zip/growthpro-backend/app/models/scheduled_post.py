import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Enum
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class PostPlatform(str, enum.Enum):
    facebook = "facebook"
    instagram = "instagram"
    tiktok = "tiktok"


class PostStatus(str, enum.Enum):
    draft = "draft"
    scheduled = "scheduled"
    published = "published"
    failed = "failed"


class ScheduledPost(Base):
    """Content calendar entry (spec section 21-22) — user-approved, auto-published at scheduled_for."""
    __tablename__ = "scheduled_posts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    platform = Column(Enum(PostPlatform), nullable=False)
    message = Column(String, nullable=False)
    link = Column(String, nullable=True)
    scheduled_for = Column(DateTime(timezone=True), nullable=False)
    status = Column(Enum(PostStatus), default=PostStatus.scheduled)
    error_message = Column(String, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
