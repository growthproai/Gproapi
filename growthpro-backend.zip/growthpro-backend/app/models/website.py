import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class Website(Base):
    __tablename__ = "websites"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    url = Column(String, nullable=False)
    verified_search_console = Column(String, default="pending")  # pending | verified | failed
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
