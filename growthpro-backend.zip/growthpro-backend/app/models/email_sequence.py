import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, JSON, Boolean
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class EmailSequence(Base):
    """Drip campaign definition — an ordered list of emails sent N days after a contact enters the sequence."""
    __tablename__ = "email_sequences"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    trigger = Column(String, default="lead_created")  # reuses CRM trigger vocabulary
    steps = Column(JSON, default=list)  # [{"delay_days": 0, "subject": "", "body": ""}, ...]
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class SequenceEnrollment(Base):
    """One contact/lead's progress through a sequence — which step they're on and when the next send is due."""
    __tablename__ = "sequence_enrollments"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    sequence_id = Column(UUID(as_uuid=True), ForeignKey("email_sequences.id"), nullable=False, index=True)
    lead_id = Column(UUID(as_uuid=True), ForeignKey("leads.id"), nullable=True)
    email = Column(String, nullable=False)
    current_step = Column(Integer, default=0)
    next_send_at = Column(DateTime(timezone=True), nullable=True)
    completed = Column(Boolean, default=False)
    enrolled_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
