import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class Workspace(Base):
    """
    Isolated workspace inside an organization — one site/brand + its connected
    accounts (spec section 5: multi-tenant architecture, workspace A/B example).
    Every downstream table (websites, keywords, content, etc.) is scoped to a
    workspace_id, which is how tenant isolation is enforced at the query layer.
    """
    __tablename__ = "workspaces"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    niche = Column(String, nullable=True)

    # Business Setup Wizard fields (spec section 4) — captured once at onboarding,
    # used to seed AI Business Doctor + Growth Score + dashboard defaults.
    website_url = Column(String, nullable=True)
    industry = Column(String, nullable=True)
    country = Column(String, nullable=True)
    city = Column(String, nullable=True)
    products_services = Column(String, nullable=True)
    target_market = Column(String, nullable=True)
    business_size = Column(String, nullable=True)
    monthly_marketing_budget = Column(String, nullable=True)
    main_goal = Column(String, nullable=True)  # more_traffic | more_leads | more_sales | brand_awareness | local_customers | ecommerce_growth

    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
