import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID, ARRAY

from app.db.database import Base


class Notification(Base):
    """Section 58 — Notification Center. In-app notifications; email reuses email_service.py."""
    __tablename__ = "notifications"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=False, index=True)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=True)
    type = Column(String, nullable=False)  # new_lead | hot_lead | seo_issue | rank_change | campaign_alert | payment | subscription | ai_recommendation
    title = Column(String, nullable=False)
    body = Column(Text, nullable=True)
    is_read = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class WebhookEndpoint(Base):
    """Section 55-56 — outbound webhooks for developer integrations."""
    __tablename__ = "webhook_endpoints"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    url = Column(String, nullable=False)
    events = Column(ARRAY(String), default=list)  # e.g. ["lead.created", "deal.won"]
    signing_secret = Column(String, nullable=False)  # for HMAC-signing payloads, so receivers can verify authenticity
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class WebhookDelivery(Base):
    """Delivery log — audit trail + retry bookkeeping."""
    __tablename__ = "webhook_deliveries"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    webhook_endpoint_id = Column(UUID(as_uuid=True), ForeignKey("webhook_endpoints.id"), nullable=False, index=True)
    event = Column(String, nullable=False)
    payload = Column(Text, nullable=False)
    response_status = Column(String, nullable=True)
    success = Column(Boolean, default=False)
    attempted_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
