import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, Boolean, DateTime
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class User(Base):
    __tablename__ = "users"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    email = Column(String, unique=True, index=True, nullable=False)
    hashed_password = Column(String, nullable=False)
    full_name = Column(String, nullable=True)
    is_active = Column(Boolean, default=True)
    is_platform_admin = Column(Boolean, default=False)  # section 41-42: admin panel access
    is_verified = Column(Boolean, default=False)  # email verification required before full access
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
