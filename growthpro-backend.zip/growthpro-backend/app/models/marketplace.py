import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Enum, Text, JSON
from sqlalchemy.dialects.postgresql import UUID, ARRAY

from app.db.database import Base


class OrderStatus(str, enum.Enum):
    requested = "requested"
    accepted = "accepted"
    in_progress = "in_progress"
    delivered = "delivered"
    completed = "completed"
    cancelled = "cancelled"


class Creator(Base):
    """Section 63 — a creator/influencer profile, discoverable by advertisers."""
    __tablename__ = "creators"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    display_name = Column(String, nullable=False)
    platforms = Column(ARRAY(String), default=list)   # ["instagram", "tiktok", "youtube"]
    category = Column(String, nullable=True)
    country = Column(String, nullable=True)
    follower_count = Column(Integer, nullable=True)   # self-reported, not platform-verified in this build
    content_type = Column(String, nullable=True)
    starting_price = Column(Integer, nullable=True)   # smallest currency unit
    bio = Column(Text, nullable=True)
    portfolio_links = Column(ARRAY(String), default=list)
    is_verified = Column(String, default="unverified")  # unverified | verified — manual admin verification
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class Publisher(Base):
    """Section 64 — a website/app/media property that can run ads or accept guest content."""
    __tablename__ = "publishers"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    property_name = Column(String, nullable=False)
    property_url = Column(String, nullable=False)
    property_type = Column(String, default="website")  # website | app | blog
    category = Column(String, nullable=True)
    monthly_traffic_estimate = Column(Integer, nullable=True)  # self-reported
    is_verified = Column(String, default="unverified")
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class MarketplaceOrder(Base):
    """Section 65 — a business hiring a creator/service provider through the marketplace."""
    __tablename__ = "marketplace_orders"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    creator_id = Column(UUID(as_uuid=True), ForeignKey("creators.id"), nullable=True)
    publisher_id = Column(UUID(as_uuid=True), ForeignKey("publishers.id"), nullable=True)
    service_description = Column(Text, nullable=False)
    agreed_price = Column(Integer, nullable=True)
    platform_commission_percent = Column(Integer, default=15)  # GrowthPro's cut (spec section 65)
    status = Column(Enum(OrderStatus), default=OrderStatus.requested)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
