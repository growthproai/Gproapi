import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Boolean
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class Plan(Base):
    """Configurable pricing plan (spec section 43 — admin-editable)."""
    __tablename__ = "plans"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    code = Column(String, unique=True, nullable=False)  # free | starter | professional | business | agency
    name = Column(String, nullable=False)
    price_aed_cents = Column(Integer, nullable=False, default=0)
    ai_credits_per_month = Column(Integer, default=0)
    max_websites = Column(Integer, default=1)
    max_workspaces = Column(Integer, default=1)
    features = Column(String, default="")  # comma-separated feature flags, kept simple for MVP


class Subscription(Base):
    __tablename__ = "subscriptions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    organization_id = Column(UUID(as_uuid=True), ForeignKey("organizations.id"), nullable=False, index=True)
    plan_id = Column(UUID(as_uuid=True), ForeignKey("plans.id"), nullable=False)
    status = Column(String, default="active")  # active | past_due | canceled
    stripe_customer_id = Column(String, nullable=True)
    stripe_subscription_id = Column(String, nullable=True)
    ai_credits_remaining = Column(Integer, default=0)
    current_period_end = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
