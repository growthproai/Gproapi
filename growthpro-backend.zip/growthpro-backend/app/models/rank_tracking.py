import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class RankEntry(Base):
    """
    One rank-check data point (spec section 30). In production this table is
    populated by a scheduled worker calling a licensed rank-tracking data
    source — never a scraper that violates a search engine's terms.
    """
    __tablename__ = "rank_entries"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    keyword = Column(String, nullable=False)
    search_engine = Column(String, default="Google")
    country = Column(String, default="Global")
    device = Column(String, default="mobile")
    position = Column(Integer, nullable=False)
    checked_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
