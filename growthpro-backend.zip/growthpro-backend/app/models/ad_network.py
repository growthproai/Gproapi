import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Float
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class AdSlot(Base):
    """Section 28 — a publisher's ad placement inventory."""
    __tablename__ = "ad_slots"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    publisher_id = Column(UUID(as_uuid=True), ForeignKey("publishers.id"), nullable=False, index=True)
    slot_name = Column(String, nullable=False)
    width = Column(Integer, nullable=True)
    height = Column(Integer, nullable=True)
    floor_price_cpm = Column(Integer, default=0)  # smallest currency unit, per 1000 impressions
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))


class NetworkImpression(Base):
    """One ad served — the raw event this whole network is built on."""
    __tablename__ = "network_impressions"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    ad_slot_id = Column(UUID(as_uuid=True), ForeignKey("ad_slots.id"), nullable=False, index=True)
    campaign_id = Column(UUID(as_uuid=True), ForeignKey("ad_campaigns.id"), nullable=False, index=True)
    cost_charged = Column(Integer, default=0)     # what the advertiser's wallet was debited
    publisher_earning = Column(Integer, default=0)  # after platform commission
    was_clicked = Column(Integer, default=0)  # 0/1 — SQLite/Postgres-portable boolean-as-int for fast aggregate counts
    ip_hash = Column(String, nullable=True)   # hashed, never raw IP — basic fraud-signal input, not a fraud SYSTEM
    served_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
