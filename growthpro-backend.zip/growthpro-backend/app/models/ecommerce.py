import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class EcommerceStore(Base):
    """Section 56 — Shopify/WooCommerce connection. OAuth for Shopify, API key for WooCommerce (no OAuth flow there)."""
    __tablename__ = "ecommerce_stores"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    platform = Column(String, nullable=False)  # shopify | woocommerce
    store_url = Column(String, nullable=False)
    encrypted_access_token = Column(Text, nullable=False)  # Shopify: OAuth token. WooCommerce: consumer_secret
    api_key = Column(String, nullable=True)  # WooCommerce consumer_key (not sensitive enough alone to need encryption)
    connected_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
