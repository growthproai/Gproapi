import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class YouTubeAccount(Base):
    """
    A workspace's connected YouTube channel (via the same Google OAuth grant,
    scoped with youtube.readonly / yt-analytics.readonly — spec section 13).
    """
    __tablename__ = "youtube_accounts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    channel_id = Column(String, nullable=False)
    channel_title = Column(String, nullable=True)
    encrypted_refresh_token = Column(Text, nullable=False)
    connected_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
