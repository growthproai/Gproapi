import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Integer, Enum, JSON
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class AdPlatform(str, enum.Enum):
    google = "google"
    meta = "meta"
    tiktok = "tiktok"
    growthpro_network = "growthpro_network"


class CampaignStatus(str, enum.Enum):
    draft = "draft"              # AI-proposed, awaiting user approval — spec section 26
    pending_approval = "pending_approval"
    active = "active"
    paused = "paused"
    ended = "ended"


class AdFormat(str, enum.Enum):
    video_ad = "video_ad"
    photo_ad = "photo_ad"
    lead_ad = "lead_ad"          # native lead-gen forms (Meta Lead Ads / Google Lead Form extensions)
    carousel_ad = "carousel_ad"
    text_ad = "text_ad"          # Google Search-style text ads


class AdCampaign(Base):
    """Sections 25-27 — one campaign, on one platform, always starting as `draft` until user approves spend."""
    __tablename__ = "ad_campaigns"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    platform = Column(Enum(AdPlatform), nullable=False)
    ad_format = Column(Enum(AdFormat), default=AdFormat.photo_ad)
    external_campaign_id = Column(String, nullable=True)  # ID on Google/Meta once actually created there
    objective = Column(String, nullable=True)  # traffic | leads | sales | awareness | video_views
    daily_budget = Column(Integer, nullable=True)  # smallest currency unit
    total_budget = Column(Integer, nullable=True)
    ai_generated_copy = Column(JSON, nullable=True)
    # Audience targeting (spec section 26: audience suggestion is part of Smart Campaign)
    target_country = Column(String, nullable=True)
    target_city = Column(String, nullable=True)
    target_profession = Column(String, nullable=True)
    target_age_min = Column(Integer, nullable=True)
    target_age_max = Column(Integer, nullable=True)
    destination = Column(String, default="social")  # social | website | blog — where the content actually goes
    status = Column(Enum(CampaignStatus), default=CampaignStatus.draft)
    approved_by_user_id = Column(UUID(as_uuid=True), ForeignKey("users.id"), nullable=True)
    approved_at = Column(DateTime(timezone=True), nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
