import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, JSON
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class TrackingEvent(Base):
    """
    Section 35 — GrowthPro Pixel. First-party events from a website that
    installs the tracking snippet: page views, custom events, and
    conversions. This is what makes revenue attribution (section 45) real
    instead of manual CRM entry — a conversion event here can be matched to
    the campaign/source that brought the visitor.
    """
    __tablename__ = "tracking_events"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    event_type = Column(String, nullable=False)  # page_view | custom | conversion
    event_name = Column(String, nullable=True)   # e.g. "signup", "purchase", custom event label
    page_url = Column(String, nullable=True)
    referrer = Column(String, nullable=True)
    utm_source = Column(String, nullable=True)
    utm_medium = Column(String, nullable=True)
    utm_campaign = Column(String, nullable=True)
    visitor_id = Column(String, nullable=True)   # anonymous cookie-based ID set by the pixel, not PII
    value = Column(String, nullable=True)        # optional conversion value, kept as string (currency-agnostic)
    meta = Column(JSON, default=dict)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
