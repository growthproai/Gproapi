import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, JSON
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class GeoVisibilityCheck(Base):
    """
    Section 18 — AI/GEO Search Intelligence. Stores the result of asking an
    AI model directly whether/how it mentions the brand for a given query —
    this is the only honest way to measure "AI visibility" right now (there
    is no official API from OpenAI/Google/Perplexity that reports brand
    mention frequency across real user queries — anyone claiming otherwise
    is estimating too). This is explicitly a sampled proxy, not a
    comprehensive share-of-voice metric, and the UI must say so.
    """
    __tablename__ = "geo_visibility_checks"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    query = Column(String, nullable=False)
    brand_mentioned = Column(String, nullable=False)  # "yes" | "no" | "indirectly"
    mention_context = Column(String, nullable=True)
    competitors_mentioned = Column(JSON, default=list)
    raw_response_excerpt = Column(String, nullable=True)
    checked_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
