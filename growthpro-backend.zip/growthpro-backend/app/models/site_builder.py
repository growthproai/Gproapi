import uuid
import enum
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, JSON, Enum, Boolean
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class PageType(str, enum.Enum):
    website = "website"        # multi-page site (home/about/services/contact)
    landing_page = "landing_page"  # single campaign-specific page


class BuiltPage(Base):
    """
    Sections 31-32 — AI-generated site/landing pages. `content` stores a JSON
    section tree (hero, features, testimonials, cta, ...) that the public
    renderer (app/api/routes/site_builder.py -> /api/public/site/{slug})
    turns into HTML. This is an AI-generation + JSON-schema builder, not a
    pixel-level drag-and-drop editor — sections can be edited by re-prompting
    the AI or patching the JSON directly.
    """
    __tablename__ = "built_pages"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    page_type = Column(Enum(PageType), default=PageType.landing_page)
    slug = Column(String, nullable=False, unique=True, index=True)  # public URL: /site/{slug}
    title = Column(String, nullable=False)
    sections = Column(JSON, nullable=False)  # [{"type": "hero", "headline": "", "subheadline": "", "cta_text": ""}, ...]
    is_published = Column(Boolean, default=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
