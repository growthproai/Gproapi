import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID

from app.db.database import Base


class ContentItem(Base):
    """AI-generated content library entry (spec section 11-12)."""
    __tablename__ = "content_items"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    content_type = Column(String, nullable=False)  # blog | meta | social | youtube | ad | script
    topic = Column(String, nullable=False)
    platform = Column(String, nullable=True)
    language = Column(String, default="English")
    output = Column(Text, nullable=False)
    created_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
