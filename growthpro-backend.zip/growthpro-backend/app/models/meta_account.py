import uuid
from datetime import datetime, timezone
from sqlalchemy import Column, String, DateTime, ForeignKey, Text
from sqlalchemy.dialects.postgresql import UUID, ARRAY

from app.db.database import Base


class MetaAccount(Base):
    """
    A workspace's connected Meta identity — covers Facebook Page + linked
    Instagram professional account (spec section 17-18). Long-lived access
    token stored ENCRYPTED, never in plaintext (spec section 46).
    """
    __tablename__ = "meta_accounts"

    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    workspace_id = Column(UUID(as_uuid=True), ForeignKey("workspaces.id"), nullable=False, index=True)
    facebook_page_id = Column(String, nullable=True)
    facebook_page_name = Column(String, nullable=True)
    instagram_business_id = Column(String, nullable=True)
    instagram_username = Column(String, nullable=True)
    encrypted_long_lived_token = Column(Text, nullable=False)
    scopes = Column(ARRAY(String), default=list)
    connected_at = Column(DateTime(timezone=True), default=lambda: datetime.now(timezone.utc))
