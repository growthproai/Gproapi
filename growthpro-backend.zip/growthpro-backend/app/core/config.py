from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    """
    Central app configuration, loaded from environment variables / .env.
    Never hard-code secrets here — see .env.example for the full list.
    """
    model_config = SettingsConfigDict(env_file=".env", extra="ignore")

    APP_ENV: str = "development"
    SECRET_KEY: str
    TOKEN_ENCRYPTION_KEY: str
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 1440
    FRONTEND_URL: str = "http://localhost:3000"
    ALLOWED_ORIGINS: str = "http://localhost:3000"  # comma-separated for multiple prod domains
    BACKEND_BASE_URL: str = "http://localhost:8000"

    DATABASE_URL: str
    REDIS_URL: str = "redis://localhost:6379/0"

    GOOGLE_CLIENT_ID: str = ""
    GOOGLE_CLIENT_SECRET: str = ""
    GOOGLE_REDIRECT_URI: str = "http://localhost:8000/api/google/oauth/callback"

    ANTHROPIC_API_KEY: str = ""

    SENTRY_DSN: str = ""  # error tracking — sentry.io, leave blank to disable
    RATE_LIMIT_DEFAULT: str = "100/minute"

    RESEND_API_KEY: str = ""  # resend.com — swap for SendGrid/SES if you prefer
    EMAIL_FROM: str = "GrowthPro <noreply@yourdomain.com>"

    DATAFORSEO_LOGIN: str = ""
    DATAFORSEO_PASSWORD: str = ""

    GOOGLE_ADS_DEVELOPER_TOKEN: str = ""

    S3_ENDPOINT_URL: str = ""
    S3_BUCKET: str = ""
    S3_ACCESS_KEY: str = ""
    S3_SECRET_KEY: str = ""
    S3_REGION: str = ""
    S3_PUBLIC_BASE_URL: str = ""

    SHOPIFY_CLIENT_ID: str = ""
    SHOPIFY_CLIENT_SECRET: str = ""
    SHOPIFY_REDIRECT_URI: str = "http://localhost:8000/api/ecommerce/shopify/oauth/callback"

    META_APP_ID: str = ""
    META_APP_SECRET: str = ""
    META_REDIRECT_URI: str = "http://localhost:8000/api/meta/oauth/callback"

    TIKTOK_CLIENT_KEY: str = ""
    TIKTOK_CLIENT_SECRET: str = ""
    TIKTOK_REDIRECT_URI: str = "http://localhost:8000/api/tiktok/oauth/callback"

    STRIPE_SECRET_KEY: str = ""
    STRIPE_WEBHOOK_SECRET: str = ""
    STRIPE_SUCCESS_URL: str = "http://localhost:3000/billing/success"
    STRIPE_CANCEL_URL: str = "http://localhost:3000/billing/cancel"


settings = Settings()
