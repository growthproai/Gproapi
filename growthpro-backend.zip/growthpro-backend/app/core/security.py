from datetime import datetime, timedelta, timezone
from passlib.context import CryptContext
from jose import jwt, JWTError
from cryptography.fernet import Fernet

from app.core.config import settings

pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# TOKEN_ENCRYPTION_KEY must be a real, persistent Fernet key. Falling back to
# a randomly generated key here would silently make every previously-stored
# OAuth refresh token undecryptable on the next server restart — fail loudly
# instead so this gets caught in setup, not in production three weeks later.
try:
    _fernet = Fernet(settings.TOKEN_ENCRYPTION_KEY.encode())
except Exception as exc:
    raise RuntimeError(
        "TOKEN_ENCRYPTION_KEY in .env is missing or invalid. Generate one with:\n"
        '  python -c "from cryptography.fernet import Fernet; print(Fernet.generate_key().decode())"\n'
        "and put the output in .env — do not change it after tokens have been stored."
    ) from exc

ALGORITHM = "HS256"


def hash_password(password: str) -> str:
    return pwd_context.hash(password)


def verify_password(plain: str, hashed: str) -> bool:
    return pwd_context.verify(plain, hashed)


def create_access_token(subject: str, expires_minutes: int | None = None) -> str:
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=expires_minutes or settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload = {"sub": subject, "exp": expire}
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=ALGORITHM)


def decode_access_token(token: str) -> str | None:
    try:
        payload = jwt.decode(token, settings.SECRET_KEY, algorithms=[ALGORITHM])
        return payload.get("sub")
    except JWTError:
        return None


# OAuth tokens must be encrypted at rest and never exposed to frontend logs (spec section 46, 82).
def encrypt_token(raw_token: str) -> str:
    return _fernet.encrypt(raw_token.encode()).decode()


def decrypt_token(encrypted_token: str) -> str:
    return _fernet.decrypt(encrypted_token.encode()).decode()
