"""Automated report generation (spec section 40) — PDF/Excel, per workspace."""
import io
from datetime import datetime, timedelta
from celery.utils.log import get_task_logger
from reportlab.lib.pagesizes import A4
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
import openpyxl

from app.worker import celery_app
from app.db.database import SessionLocal
from app.models.workspace import Workspace
from app.models.seo import KeywordSet, SEOAudit
from app.models.content import ContentItem
from app.models.rank_tracking import RankEntry
from app.models.backlink import Backlink
from app.services.email_service import send_email

logger = get_task_logger(__name__)


def build_pdf_report(workspace: Workspace, stats: dict) -> bytes:
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4)
    styles = getSampleStyleSheet()
    elements = [
        Paragraph(f"GrowthPro Weekly Report — {workspace.name}", styles["Title"]),
        Paragraph(datetime.utcnow().strftime("%Y-%m-%d"), styles["Normal"]),
        Spacer(1, 16),
    ]
    table_data = [["Metric", "Value"]] + [[k, str(v)] for k, v in stats.items()]
    table = Table(table_data, colWidths=[220, 220])
    table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#111B2E")),
        ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
        ("GRID", (0, 0), (-1, -1), 0.5, colors.grey),
        ("FONTSIZE", (0, 0), (-1, -1), 10),
    ]))
    elements.append(table)
    doc.build(elements)
    return buf.getvalue()


def build_excel_report(workspace: Workspace, stats: dict) -> bytes:
    wb = openpyxl.Workbook()
    ws = wb.active
    ws.title = "Summary"
    ws.append(["Metric", "Value"])
    for k, v in stats.items():
        ws.append([k, v])
    buf = io.BytesIO()
    wb.save(buf)
    return buf.getvalue()


def _collect_stats(db, workspace_id) -> dict:
    since = datetime.utcnow() - timedelta(days=7)
    return {
        "Keyword research runs (7d)": db.query(KeywordSet).filter(KeywordSet.workspace_id == workspace_id, KeywordSet.created_at >= since).count(),
        "Content pieces generated (7d)": db.query(ContentItem).filter(ContentItem.workspace_id == workspace_id, ContentItem.created_at >= since).count(),
        "Rank checks logged (7d)": db.query(RankEntry).filter(RankEntry.workspace_id == workspace_id, RankEntry.checked_at >= since).count(),
        "Backlink prospects (total)": db.query(Backlink).filter(Backlink.workspace_id == workspace_id).count(),
    }


@celery_app.task
def generate_weekly_reports_for_all_workspaces():
    db = SessionLocal()
    try:
        for workspace in db.query(Workspace).all():
            generate_report_for_workspace.delay(str(workspace.id))
    finally:
        db.close()


@celery_app.task
def generate_report_for_workspace(workspace_id: str, email_to: str | None = None):
    db = SessionLocal()
    try:
        workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
        if not workspace:
            return
        stats = _collect_stats(db, workspace_id)
        pdf_bytes = build_pdf_report(workspace, stats)
        logger.info("Generated report for workspace %s (%d bytes)", workspace.name, len(pdf_bytes))
        if email_to:
            send_email(
                to=email_to,
                subject=f"GrowthPro weekly report — {workspace.name}",
                html=f"<p>Your weekly report for {workspace.name} is attached.</p>",
                attachment_bytes=pdf_bytes,
                attachment_filename="weekly-report.pdf",
            )
        # In production: upload pdf_bytes to S3-compatible storage (spec section 53)
        # instead of / in addition to emailing it directly.
    finally:
        db.close()
