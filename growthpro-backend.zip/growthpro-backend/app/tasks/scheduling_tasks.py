"""Publishes content-calendar posts whose scheduled_for time has passed (spec section 21, 62)."""
from datetime import datetime, timezone
from celery.utils.log import get_task_logger

from app.worker import celery_app
from app.db.database import SessionLocal
from app.models.scheduled_post import ScheduledPost, PostStatus, PostPlatform
from app.models.meta_account import MetaAccount
from app.models.tiktok_account import TikTokAccount
from app.core.security import decrypt_token
from app.services import meta_graph_service, tiktok_service

logger = get_task_logger(__name__)


@celery_app.task
def publish_due_posts():
    """Runs every 15 min (see app/worker.py beat schedule). Only touches posts the
    user already approved by scheduling them — never creates or approves content itself."""
    db = SessionLocal()
    try:
        due = db.query(ScheduledPost).filter(
            ScheduledPost.status == PostStatus.scheduled,
            ScheduledPost.scheduled_for <= datetime.now(timezone.utc),
        ).all()
        for post in due:
            try:
                if post.platform == PostPlatform.facebook:
                    account = db.query(MetaAccount).filter(MetaAccount.workspace_id == post.workspace_id).first()
                    if not account:
                        raise RuntimeError("No Meta account connected")
                    token = decrypt_token(account.encrypted_long_lived_token)
                    meta_graph_service.publish_page_post(account.facebook_page_id, token, post.message, post.link)
                elif post.platform == PostPlatform.tiktok:
                    account = db.query(TikTokAccount).filter(TikTokAccount.workspace_id == post.workspace_id).first()
                    if not account:
                        raise RuntimeError("No TikTok account connected")
                    token = decrypt_token(account.encrypted_access_token)
                    if not post.link:
                        raise RuntimeError("TikTok posts need a source video_url in `link`")
                    tiktok_service.upload_video_as_draft(token, post.link, post.message)
                # Instagram publishing needs a media container step (image/video upload
                # first, then publish) — left as a follow-up since it depends on asset storage.
                post.status = PostStatus.published
            except Exception as e:
                post.status = PostStatus.failed
                post.error_message = str(e)
                logger.error("Failed to publish scheduled post %s: %s", post.id, e)
        db.commit()
        logger.info("Processed %d due scheduled posts", len(due))
    finally:
        db.close()
