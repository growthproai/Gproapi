"""
Scheduled rank-checking using real DataForSEO SERP data (spec section 30:
"must respect search engine policies and data-source licensing" — this is
why it's a licensed API call, not a scraper). Requires DATAFORSEO_LOGIN /
DATAFORSEO_PASSWORD in .env and a `website_url` recorded per workspace to
know which domain's position to look for.
"""
from celery.utils.log import get_task_logger

from app.worker import celery_app
from app.db.database import SessionLocal
from app.models.rank_tracking import RankEntry
from app.models.website import Website
from app.services import dataforseo_service

logger = get_task_logger(__name__)


@celery_app.task
def check_all_tracked_keywords():
    """Daily job (see app/worker.py beat schedule) — re-checks every distinct tracked keyword."""
    db = SessionLocal()
    try:
        distinct = db.query(
            RankEntry.keyword, RankEntry.search_engine, RankEntry.country, RankEntry.workspace_id
        ).distinct().all()

        checked, skipped = 0, 0
        for keyword, engine, country, workspace_id in distinct:
            if engine.lower() != "google":
                skipped += 1
                continue  # DataForSEO also supports Bing/YouTube SERPs — add those engines here as needed

            website = db.query(Website).filter(Website.workspace_id == workspace_id).first()
            if not website:
                skipped += 1
                continue

            try:
                position = dataforseo_service.get_serp_position(keyword, website.url)
            except Exception as e:
                logger.error("Rank check failed for %s (%s): %s", keyword, website.url, e)
                continue

            if position is not None:
                db.add(RankEntry(workspace_id=workspace_id, keyword=keyword, search_engine=engine, country=country, position=position))
                checked += 1

        db.commit()
        logger.info("Rank check complete: %d checked, %d skipped (no website or unsupported engine)", checked, skipped)
    finally:
        db.close()
