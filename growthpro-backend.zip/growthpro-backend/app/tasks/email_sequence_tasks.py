"""Sends due drip-sequence emails and advances each enrollment to its next step."""
from datetime import datetime, timedelta, timezone
from celery.utils.log import get_task_logger

from app.worker import celery_app
from app.db.database import SessionLocal
from app.models.email_sequence import EmailSequence, SequenceEnrollment
from app.services.email_service import send_email

logger = get_task_logger(__name__)


@celery_app.task
def send_due_sequence_emails():
    db = SessionLocal()
    try:
        due = db.query(SequenceEnrollment).filter(
            SequenceEnrollment.completed == False,  # noqa: E712
            SequenceEnrollment.next_send_at <= datetime.now(timezone.utc),
        ).all()

        for enrollment in due:
            sequence = db.query(EmailSequence).filter(EmailSequence.id == enrollment.sequence_id).first()
            if not sequence or not sequence.is_active or enrollment.current_step >= len(sequence.steps):
                enrollment.completed = True
                continue

            step = sequence.steps[enrollment.current_step]
            send_email(to=enrollment.email, subject=step["subject"], html=step["body"])

            enrollment.current_step += 1
            if enrollment.current_step >= len(sequence.steps):
                enrollment.completed = True
            else:
                next_step = sequence.steps[enrollment.current_step]
                delay_diff = next_step.get("delay_days", 0) - step.get("delay_days", 0)
                enrollment.next_send_at = datetime.now(timezone.utc) + timedelta(days=max(delay_diff, 0))

        db.commit()
        logger.info("Processed %d due sequence emails", len(due))
    finally:
        db.close()
