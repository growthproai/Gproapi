"""
Real TikTok Login Kit OAuth flow. Requires a TikTok for Developers app at
developers.tiktok.com with Login Kit + Content Posting API products added.
Note: full public direct-posting requires app review/audit (spec section 19,
57, 64) — unaudited apps can post but with visibility restrictions.
Docs: https://developers.tiktok.com/doc/login-kit-web
"""
import httpx
from app.core.config import settings

AUTH_BASE = "https://www.tiktok.com/v2/auth/authorize"
TOKEN_URL = "https://open.tiktokapis.com/v2/oauth/token/"

SCOPES = ["user.info.basic", "video.list", "video.publish"]


def build_authorization_url(state: str) -> str:
    scope_str = ",".join(SCOPES)
    return (
        f"{AUTH_BASE}?client_key={settings.TIKTOK_CLIENT_KEY}"
        f"&scope={scope_str}"
        f"&response_type=code"
        f"&redirect_uri={settings.TIKTOK_REDIRECT_URI}"
        f"&state={state}"
    )


def exchange_code_for_tokens(code: str) -> dict:
    resp = httpx.post(TOKEN_URL, data={
        "client_key": settings.TIKTOK_CLIENT_KEY,
        "client_secret": settings.TIKTOK_CLIENT_SECRET,
        "code": code,
        "grant_type": "authorization_code",
        "redirect_uri": settings.TIKTOK_REDIRECT_URI,
    }, headers={"Content-Type": "application/x-www-form-urlencoded"})
    resp.raise_for_status()
    return resp.json()  # {access_token, refresh_token, open_id, expires_in, ...}


def refresh_access_token(refresh_token: str) -> dict:
    resp = httpx.post(TOKEN_URL, data={
        "client_key": settings.TIKTOK_CLIENT_KEY,
        "client_secret": settings.TIKTOK_CLIENT_SECRET,
        "grant_type": "refresh_token",
        "refresh_token": refresh_token,
    })
    resp.raise_for_status()
    return resp.json()
