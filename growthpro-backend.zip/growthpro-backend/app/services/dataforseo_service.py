"""
Real third-party SEO data via DataForSEO (dataforseo.com) — replaces the
AI-estimated "high/medium/low" placeholders with actual search volume, CPC,
SERP positions, and backlink/domain-authority numbers. Pay-as-you-go, no
Google/Ahrefs partnership needed to get started.

Auth is HTTP Basic (login:password from your DataForSEO dashboard), not OAuth.
Docs: https://docs.dataforseo.com/v3/
"""
import base64
import httpx

from app.core.config import settings

BASE_URL = "https://api.dataforseo.com/v3"


def _headers() -> dict:
    if not settings.DATAFORSEO_LOGIN or not settings.DATAFORSEO_PASSWORD:
        raise RuntimeError(
            "DATAFORSEO_LOGIN / DATAFORSEO_PASSWORD not set in .env — "
            "sign up at https://app.dataforseo.com/register to get these."
        )
    token = base64.b64encode(f"{settings.DATAFORSEO_LOGIN}:{settings.DATAFORSEO_PASSWORD}".encode()).decode()
    return {"Authorization": f"Basic {token}", "Content-Type": "application/json"}


def get_search_volume(keywords: list[str], location_code: int = 2784, language_code: str = "en") -> list[dict]:
    """
    Real monthly search volume + CPC + competition for up to 1000 keywords
    per call. location_code 2784 = United Arab Emirates; see DataForSEO's
    locations endpoint for other countries: https://docs.dataforseo.com/v3/keywords_data/google_ads/locations/
    """
    resp = httpx.post(
        f"{BASE_URL}/keywords_data/google_ads/search_volume/live",
        headers=_headers(),
        json=[{"keywords": keywords, "location_code": location_code, "language_code": language_code}],
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    tasks = data.get("tasks", [])
    if not tasks or not tasks[0].get("result"):
        return []
    return [
        {
            "keyword": row["keyword"],
            "search_volume": row.get("search_volume"),
            "cpc": row.get("cpc"),
            "competition": row.get("competition"),
        }
        for row in tasks[0]["result"] if row
    ]


def get_serp_position(keyword: str, target_domain: str, location_code: int = 2784, language_code: str = "en") -> int | None:
    """Real Google SERP check — returns the rank position of target_domain, or None if not in top 100."""
    resp = httpx.post(
        f"{BASE_URL}/serp/google/organic/live/regular",
        headers=_headers(),
        json=[{"keyword": keyword, "location_code": location_code, "language_code": language_code, "depth": 100}],
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    tasks = data.get("tasks", [])
    if not tasks or not tasks[0].get("result"):
        return None
    items = tasks[0]["result"][0].get("items", [])
    for item in items:
        if target_domain.replace("https://", "").replace("http://", "").rstrip("/") in (item.get("domain") or ""):
            return item.get("rank_absolute")
    return None


def get_backlink_summary(target_domain: str) -> dict:
    """Real referring-domains count + domain rank (DataForSEO's authority metric) for a domain."""
    resp = httpx.post(
        f"{BASE_URL}/backlinks/summary/live",
        headers=_headers(),
        json=[{"target": target_domain}],
        timeout=30,
    )
    resp.raise_for_status()
    data = resp.json()
    tasks = data.get("tasks", [])
    if not tasks or not tasks[0].get("result"):
        return {}
    result = tasks[0]["result"][0]
    return {
        "referring_domains": result.get("referring_domains"),
        "backlinks_total": result.get("backlinks"),
        "domain_rank": result.get("rank"),
    }
