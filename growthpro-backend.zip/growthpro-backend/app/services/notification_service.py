from sqlalchemy.orm import Session
from app.models.notification import Notification


def notify(db: Session, user_id, workspace_id, type: str, title: str, body: str | None = None):
    db.add(Notification(user_id=user_id, workspace_id=workspace_id, type=type, title=title, body=body))
    db.commit()
