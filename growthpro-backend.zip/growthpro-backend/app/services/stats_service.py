"""
Two-proportion z-test for A/B test significance — the standard, honest way
to say "is B actually better than A" rather than eyeballing raw percentages
(spec section 34: "Never claim a variation is better until statistically
meaningful evidence is available").
"""
import math


def two_proportion_z_test(conversions_a: int, visitors_a: int, conversions_b: int, visitors_b: int) -> dict:
    if visitors_a == 0 or visitors_b == 0:
        return {"significant": False, "p_value": None, "reason": "Not enough visitors yet on one or both variants."}

    p1 = conversions_a / visitors_a
    p2 = conversions_b / visitors_b
    p_pool = (conversions_a + conversions_b) / (visitors_a + visitors_b)
    se = math.sqrt(p_pool * (1 - p_pool) * (1 / visitors_a + 1 / visitors_b))

    if se == 0:
        return {"significant": False, "p_value": None, "reason": "No variance yet — need more data."}

    z = (p2 - p1) / se
    # two-tailed p-value from the standard normal CDF approximation
    p_value = 2 * (1 - _normal_cdf(abs(z)))

    return {
        "significant": p_value < 0.05,
        "p_value": round(p_value, 4),
        "conversion_rate_a": round(p1 * 100, 2),
        "conversion_rate_b": round(p2 * 100, 2),
        "relative_lift_percent": round((p2 - p1) / p1 * 100, 1) if p1 > 0 else None,
        "winner": "B" if (p_value < 0.05 and p2 > p1) else ("A" if (p_value < 0.05 and p1 > p2) else None),
    }


def _normal_cdf(x: float) -> float:
    return 0.5 * (1 + math.erf(x / math.sqrt(2)))
