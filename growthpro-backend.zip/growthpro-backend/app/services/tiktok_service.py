"""TikTok Content Posting + user info (spec section 19, 57)."""
import httpx

API_BASE = "https://open.tiktokapis.com/v2"


def get_user_info(access_token: str) -> dict:
    resp = httpx.get(f"{API_BASE}/user/info/", params={"fields": "open_id,display_name,avatar_url"},
                      headers={"Authorization": f"Bearer {access_token}"})
    resp.raise_for_status()
    return resp.json().get("data", {}).get("user", {})


def list_videos(access_token: str) -> list[dict]:
    resp = httpx.post(f"{API_BASE}/video/list/", json={"max_count": 20},
                       headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"})
    resp.raise_for_status()
    return resp.json().get("data", {}).get("videos", [])


def upload_video_as_draft(access_token: str, video_url: str, title: str) -> dict:
    """
    Uploads via PULL_FROM_URL as an inbox draft the creator finishes/publishes
    inside the TikTok app — the safer default before an app has passed audit
    for direct public posting (spec section 64).
    """
    resp = httpx.post(f"{API_BASE}/post/publish/inbox/video/init/", json={
        "post_info": {"title": title},
        "source_info": {"source": "PULL_FROM_URL", "video_url": video_url},
    }, headers={"Authorization": f"Bearer {access_token}", "Content-Type": "application/json"})
    resp.raise_for_status()
    return resp.json()
