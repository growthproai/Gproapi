"""
S3-compatible object storage for video/photo uploads (spec section 53).
Works with AWS S3, Cloudflare R2, DigitalOcean Spaces, or any S3-compatible
provider — just set the endpoint URL. Cloudflare R2 is worth considering:
S3-compatible API, and R2 has no egress fees (unlike AWS S3), which matters
a lot for a platform that's constantly serving video to TikTok/Meta.
"""
import uuid
import boto3
from botocore.client import Config

from app.core.config import settings


def _client():
    return boto3.client(
        "s3",
        endpoint_url=settings.S3_ENDPOINT_URL,
        aws_access_key_id=settings.S3_ACCESS_KEY,
        aws_secret_access_key=settings.S3_SECRET_KEY,
        config=Config(signature_version="s3v4"),
        region_name=settings.S3_REGION or "auto",
    )


def upload_file(file_bytes: bytes, filename: str, content_type: str, workspace_id: str) -> dict:
    ext = filename.rsplit(".", 1)[-1] if "." in filename else "bin"
    key = f"{workspace_id}/{uuid.uuid4()}.{ext}"

    client = _client()
    client.put_object(
        Bucket=settings.S3_BUCKET,
        Key=key,
        Body=file_bytes,
        ContentType=content_type,
        ACL="public-read",  # media needs to be publicly fetchable for TikTok/Meta to pull it
    )

    public_url = f"{settings.S3_PUBLIC_BASE_URL.rstrip('/')}/{key}"
    return {"storage_key": key, "public_url": public_url, "size_bytes": len(file_bytes)}


def delete_file(storage_key: str):
    client = _client()
    client.delete_object(Bucket=settings.S3_BUCKET, Key=storage_key)
