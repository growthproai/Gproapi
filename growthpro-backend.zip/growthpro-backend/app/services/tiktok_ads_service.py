"""
Real TikTok Marketing API wrapper. Requires a TikTok for Business account
+ a TikTok Ads app registered at business-api.tiktok.com with the Marketing
API product enabled — approval is faster than Google/Meta (often near-
instant for basic access) but a real ad account with billing set up is
still required for any of this to actually spend money.
Docs: https://business-api.tiktok.com/portal/docs
"""
import httpx

API_BASE = "https://business-api.tiktok.com/open_api/v1.3"


def list_advertiser_accounts(access_token: str, app_id: str, secret: str) -> list[dict]:
    resp = httpx.get(f"{API_BASE}/oauth2/advertiser/get/", params={
        "app_id": app_id, "secret": secret,
    }, headers={"Access-Token": access_token})
    resp.raise_for_status()
    return resp.json().get("data", {}).get("list", [])


def create_campaign(access_token: str, advertiser_id: str, name: str, objective: str, daily_budget: float) -> dict:
    """Creates the campaign — TikTok campaigns default to a manageable OFF status equivalent via budget/status fields."""
    resp = httpx.post(f"{API_BASE}/campaign/create/", json={
        "advertiser_id": advertiser_id,
        "campaign_name": name,
        "objective_type": objective,  # e.g. TRAFFIC, LEAD_GENERATION, VIDEO_VIEWS, CONVERSIONS
        "budget_mode": "BUDGET_MODE_DAY",
        "budget": daily_budget,
        "operation_status": "DISABLE",  # created paused — spec section 62: never auto-launch spend
    }, headers={"Access-Token": access_token, "Content-Type": "application/json"})
    resp.raise_for_status()
    return resp.json()
