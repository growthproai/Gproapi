"""
Real Stripe billing integration — checkout session creation + webhook
verification (spec section 45). No card data ever touches our server;
Stripe Checkout hosts the payment form.
"""
import stripe
from app.core.config import settings

stripe.api_key = settings.STRIPE_SECRET_KEY


def get_or_create_customer(email: str, organization_id: str) -> str:
    customers = stripe.Customer.list(email=email, limit=1)
    if customers.data:
        return customers.data[0].id
    customer = stripe.Customer.create(email=email, metadata={"organization_id": organization_id})
    return customer.id


def create_checkout_session(customer_id: str, price_id: str, organization_id: str) -> stripe.checkout.Session:
    return stripe.checkout.Session.create(
        customer=customer_id,
        mode="subscription",
        line_items=[{"price": price_id, "quantity": 1}],
        success_url=settings.STRIPE_SUCCESS_URL + "?session_id={CHECKOUT_SESSION_ID}",
        cancel_url=settings.STRIPE_CANCEL_URL,
        metadata={"organization_id": organization_id},
    )


def construct_webhook_event(payload: bytes, sig_header: str):
    """Verifies the Stripe-Signature header — never trust an unverified webhook body."""
    return stripe.Webhook.construct_event(payload, sig_header, settings.STRIPE_WEBHOOK_SECRET)


def create_billing_portal_session(customer_id: str) -> stripe.billing_portal.Session:
    """Lets a customer manage/cancel their own subscription via Stripe's hosted portal."""
    return stripe.billing_portal.Session.create(customer=customer_id, return_url=settings.FRONTEND_URL)
