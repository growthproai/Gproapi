"""
Real Google Ads API wrapper — BUT this needs a Google Ads Developer Token,
which Google issues manually per application after reviewing your use case
(can take days to weeks, and Basic Access has API-call limits until you
apply for Standard Access). Nothing in code can skip that human review step.
Docs: https://developers.google.com/google-ads/api/docs/first-call/overview
Apply for a token: https://ads.google.com/aw/apicenter
"""
from google.ads.googleads.client import GoogleAdsClient
from app.core.config import settings


def _client(refresh_token: str) -> "GoogleAdsClient":
    return GoogleAdsClient.load_from_dict({
        "developer_token": settings.GOOGLE_ADS_DEVELOPER_TOKEN,
        "client_id": settings.GOOGLE_CLIENT_ID,
        "client_secret": settings.GOOGLE_CLIENT_SECRET,
        "refresh_token": refresh_token,
        "use_proto_plus": True,
    })


def list_accessible_customers(refresh_token: str) -> list[str]:
    client = _client(refresh_token)
    service = client.get_service("CustomerService")
    return list(service.list_accessible_customers().resource_names)


def create_campaign_budget(refresh_token: str, customer_id: str, name: str, daily_budget_micros: int) -> str:
    """Real campaign-budget creation call — the first of several calls needed to launch a live Google Ads campaign."""
    client = _client(refresh_token)
    budget_service = client.get_service("CampaignBudgetService")
    operation = client.get_type("CampaignBudgetOperation")
    budget = operation.create
    budget.name = name
    budget.amount_micros = daily_budget_micros
    budget.delivery_method = client.enums.BudgetDeliveryMethodEnum.STANDARD
    response = budget_service.mutate_campaign_budgets(customer_id=customer_id, operations=[operation])
    return response.results[0].resource_name
