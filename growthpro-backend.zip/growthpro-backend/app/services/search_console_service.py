"""
Wraps the real Google Search Console API (searchconsole v1 / webmasters v3).
Docs: https://developers.google.com/webmaster-tools/v1/searchanalytics/query
"""
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials


def list_sites(credentials: Credentials) -> list[dict]:
    service = build("searchconsole", "v1", credentials=credentials)
    resp = service.sites().list().execute()
    return resp.get("siteEntry", [])


def get_search_performance(
    credentials: Credentials,
    site_url: str,
    start_date: str,
    end_date: str,
    dimensions: list[str] | None = None,
) -> dict:
    """
    Returns queries/clicks/impressions/CTR/position for a verified property
    (spec section 28). site_url must be a property already verified by the
    connected Google account in Search Console.
    """
    service = build("searchconsole", "v1", credentials=credentials)
    body = {
        "startDate": start_date,
        "endDate": end_date,
        "dimensions": dimensions or ["query"],
        "rowLimit": 100,
    }
    return service.searchanalytics().query(siteUrl=site_url, body=body).execute()
