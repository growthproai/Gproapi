"""
Delivers real HTTP POSTs to registered webhook endpoints (spec section 55),
HMAC-signed so receivers can verify the payload actually came from
GrowthPro and wasn't forged. No retry queue yet — see the note in
dispatch_event() for what production would add.
"""
import hmac
import hashlib
import json
import httpx
from sqlalchemy.orm import Session

from app.models.notification import WebhookEndpoint, WebhookDelivery


def _sign(secret: str, body: str) -> str:
    return hmac.new(secret.encode(), body.encode(), hashlib.sha256).hexdigest()


def dispatch_event(db: Session, organization_id, event: str, data: dict):
    """
    Synchronous delivery for now — fine at low volume. At real scale this
    should enqueue onto Celery (app/worker.py already exists) so a slow or
    dead receiver endpoint can't block the request that triggered the event.
    """
    endpoints = db.query(WebhookEndpoint).filter(
        WebhookEndpoint.organization_id == organization_id,
        WebhookEndpoint.is_active == True,  # noqa: E712
    ).all()

    for ep in endpoints:
        if event not in (ep.events or []):
            continue
        body = json.dumps({"event": event, "data": data})
        signature = _sign(ep.signing_secret, body)
        try:
            resp = httpx.post(ep.url, content=body, headers={
                "Content-Type": "application/json",
                "X-GrowthPro-Signature": signature,
                "X-GrowthPro-Event": event,
            }, timeout=10)
            db.add(WebhookDelivery(webhook_endpoint_id=ep.id, event=event, payload=body, response_status=str(resp.status_code), success=resp.is_success))
        except Exception as e:
            db.add(WebhookDelivery(webhook_endpoint_id=ep.id, event=event, payload=body, response_status=str(e), success=False))
    db.commit()
