"""
Transactional email via Resend (resend.com — generous free tier, simple API).
Swap the internals for SendGrid/AWS SES if you already use one of those;
callers only depend on send_email()'s signature, not the provider.
"""
import base64
import resend

from app.core.config import settings

resend.api_key = settings.RESEND_API_KEY


def send_email(to: str, subject: str, html: str, attachment_bytes: bytes | None = None, attachment_filename: str | None = None) -> dict:
    if not settings.RESEND_API_KEY:
        # Fail soft in development so the rest of the flow (e.g. registration)
        # still completes — but this must be configured before going live.
        print(f"[email_service] RESEND_API_KEY not set — would have sent to {to}: {subject}")
        return {"skipped": True}

    params: dict = {"from": settings.EMAIL_FROM, "to": [to], "subject": subject, "html": html}
    if attachment_bytes and attachment_filename:
        params["attachments"] = [{
            "filename": attachment_filename,
            "content": list(attachment_bytes),  # Resend expects a byte array, not base64, per its Python SDK
        }]
    return resend.Emails.send(params)
