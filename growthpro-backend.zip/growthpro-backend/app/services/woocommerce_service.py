"""
Real WooCommerce REST API. No OAuth — WooCommerce uses a consumer
key/secret pair the store owner generates themselves in
WP Admin > WooCommerce > Settings > Advanced > REST API. Simpler than
Shopify's OAuth but means the store owner has to go get these credentials
manually and paste them in (no "Connect" button redirect flow possible).
Docs: https://woocommerce.github.io/woocommerce-rest-api-docs/
"""
import httpx


def get_orders(store_url: str, consumer_key: str, consumer_secret: str, per_page: int = 50) -> list[dict]:
    resp = httpx.get(f"{store_url.rstrip('/')}/wp-json/wc/v3/orders", params={"per_page": per_page},
                      auth=(consumer_key, consumer_secret))
    resp.raise_for_status()
    return resp.json()


def get_products(store_url: str, consumer_key: str, consumer_secret: str, per_page: int = 50) -> list[dict]:
    resp = httpx.get(f"{store_url.rstrip('/')}/wp-json/wc/v3/products", params={"per_page": per_page},
                      auth=(consumer_key, consumer_secret))
    resp.raise_for_status()
    return resp.json()
