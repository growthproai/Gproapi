"""
Section 50 — Business Templates. Ready-made presets that configure a
workspace's KPIs/goals/starting content ideas by industry, applied at
Setup Wizard time or anytime after. Static data, not AI-generated —
templates should be consistent and reviewable, not different every time.
"""

TEMPLATES = {
    "restaurant": {
        "label": "Restaurant / Cafe",
        "suggested_main_goal": "local_customers",
        "kpi_focus": ["Google Business Profile ranking", "Local pack visibility", "Review rating", "Reservation/order leads"],
        "content_starter_topics": ["Menu highlights", "Behind-the-scenes kitchen", "Customer reviews", "Local events/offers"],
        "recommended_platforms": ["google_business", "instagram", "tiktok"],
    },
    "ecommerce": {
        "label": "E-commerce",
        "suggested_main_goal": "more_sales",
        "kpi_focus": ["Organic product-page traffic", "Conversion rate", "Cart abandonment", "Return customer rate"],
        "content_starter_topics": ["Product comparison guides", "How-to/usage content", "Customer testimonials", "Seasonal buying guides"],
        "recommended_platforms": ["instagram", "facebook", "tiktok", "google_ads"],
    },
    "real_estate": {
        "label": "Real Estate",
        "suggested_main_goal": "more_leads",
        "kpi_focus": ["Lead volume", "Lead-to-viewing rate", "Local keyword rankings", "Listing page traffic"],
        "content_starter_topics": ["Neighborhood guides", "Market trend updates", "Buyer/investor FAQs", "Property walkthroughs"],
        "recommended_platforms": ["youtube", "instagram", "google_ads"],
    },
    "clinic": {
        "label": "Clinic / Healthcare",
        "suggested_main_goal": "more_leads",
        "kpi_focus": ["Appointment bookings", "Local search visibility", "Review rating", "Website trust signals"],
        "content_starter_topics": ["Common patient questions (FAQ)", "Service explainers", "Doctor/staff intro", "Patient testimonials (with consent)"],
        "recommended_platforms": ["google_business", "instagram"],
    },
    "agency": {
        "label": "Agency",
        "suggested_main_goal": "more_leads",
        "kpi_focus": ["Client acquisition cost", "Portfolio traffic", "Case study engagement", "Proposal-to-close rate"],
        "content_starter_topics": ["Case studies", "Industry insights", "Client results (with permission)", "Team expertise posts"],
        "recommended_platforms": ["linkedin", "instagram"],
    },
    "beauty_salon": {
        "label": "Beauty Salon",
        "suggested_main_goal": "local_customers",
        "kpi_focus": ["Booking volume", "Local pack visibility", "Instagram engagement", "Repeat client rate"],
        "content_starter_topics": ["Before/after transformations", "Service explainers", "Staff spotlights", "Seasonal promotions"],
        "recommended_platforms": ["instagram", "tiktok", "google_business"],
    },
    "education": {
        "label": "Education / Courses",
        "suggested_main_goal": "more_leads",
        "kpi_focus": ["Enrollment leads", "Free-trial signups", "Content engagement", "Student testimonials"],
        "content_starter_topics": ["Free mini-lessons", "Student success stories", "Curriculum breakdowns", "FAQ content"],
        "recommended_platforms": ["youtube", "instagram", "facebook"],
    },
    "saas": {
        "label": "SaaS",
        "suggested_main_goal": "more_leads",
        "kpi_focus": ["Trial signups", "Trial-to-paid conversion", "Organic blog traffic", "Feature-page engagement"],
        "content_starter_topics": ["Use-case guides", "Comparison content", "Product updates", "Customer case studies"],
        "recommended_platforms": ["linkedin", "youtube"],
    },
}


def list_templates() -> dict:
    return {key: {"key": key, **val} for key, val in TEMPLATES.items()}


def get_template(key: str) -> dict | None:
    t = TEMPLATES.get(key)
    return {"key": key, **t} if t else None
