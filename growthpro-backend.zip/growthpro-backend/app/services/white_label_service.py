"""
White-label branding resolution (spec section 62). The DATA side of this is
fully real: an agency org sets a custom domain + logo + name, and any
request identifies which org's branding to apply by looking at the
Host header. What can't be "finished" in code alone is the DNS/SSL side —
see the deployment note below.
"""
from sqlalchemy.orm import Session

from app.models.organization import Organization


def resolve_branding(db: Session, host_header: str) -> dict:
    """
    Call this at the start of any request that renders branded output
    (PDF reports, the dashboard shell, emails). Falls back to default
    GrowthPro branding if the Host header doesn't match a configured
    white-label domain.
    """
    domain = host_header.split(":")[0].lower()  # strip port if present
    org = db.query(Organization).filter(Organization.white_label_domain == domain).first()
    if org:
        return {
            "organization_id": str(org.id),
            "brand_name": org.name,
            "logo_url": org.white_label_logo_url,
            "is_white_label": True,
        }
    return {"organization_id": None, "brand_name": "GrowthPro", "logo_url": None, "is_white_label": False}
