"""
Wraps the real YouTube Data API v3. Docs:
https://developers.google.com/youtube/v3/docs
"""
from googleapiclient.discovery import build
from google.oauth2.credentials import Credentials


def get_my_channel(credentials: Credentials) -> dict:
    service = build("youtube", "v3", credentials=credentials)
    resp = service.channels().list(part="snippet,statistics", mine=True).execute()
    items = resp.get("items", [])
    return items[0] if items else {}


def list_my_videos(credentials: Credentials, max_results: int = 25) -> list[dict]:
    """
    Retrieves the authorized channel's uploads (spec section 13-14). Two-step
    call: find the channel's "uploads" playlist, then list its items.
    """
    service = build("youtube", "v3", credentials=credentials)
    channel = get_my_channel(credentials)
    if not channel:
        return []
    uploads_playlist = channel["contentDetails"]["relatedPlaylists"]["uploads"] \
        if "contentDetails" in channel else None
    if not uploads_playlist:
        ch = service.channels().list(part="contentDetails", mine=True).execute()
        uploads_playlist = ch["items"][0]["contentDetails"]["relatedPlaylists"]["uploads"]

    resp = service.playlistItems().list(
        part="snippet,contentDetails",
        playlistId=uploads_playlist,
        maxResults=max_results,
    ).execute()
    return resp.get("items", [])


def update_video_metadata(credentials: Credentials, video_id: str, title: str, description: str, tags: list[str]) -> dict:
    """
    Pushes an AI-optimized title/description/tags back to YouTube — requires
    the broader youtube (not youtube.readonly) scope and explicit user
    approval per video (spec section 62: no unexpected publishing).
    """
    service = build("youtube", "v3", credentials=credentials)
    video = service.videos().list(part="snippet", id=video_id).execute()["items"][0]
    snippet = video["snippet"]
    snippet["title"] = title
    snippet["description"] = description
    snippet["tags"] = tags
    return service.videos().update(part="snippet", body={"id": video_id, "snippet": snippet}).execute()
