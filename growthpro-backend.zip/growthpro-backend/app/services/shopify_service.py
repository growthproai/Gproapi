"""
Real Shopify Admin API (OAuth). Requires a Shopify Partner account +
a custom/public app registered at partners.shopify.com — approval is
usually near-instant for custom apps installed on your own store, but
a public app (for other people's stores) needs Shopify App Store review.
Docs: https://shopify.dev/docs/api/admin-rest
"""
import httpx
from app.core.config import settings

SCOPES = "read_products,read_orders,read_customers"


def build_authorization_url(shop: str, state: str) -> str:
    return (
        f"https://{shop}/admin/oauth/authorize"
        f"?client_id={settings.SHOPIFY_CLIENT_ID}&scope={SCOPES}"
        f"&redirect_uri={settings.SHOPIFY_REDIRECT_URI}&state={state}"
    )


def exchange_code_for_token(shop: str, code: str) -> str:
    resp = httpx.post(f"https://{shop}/admin/oauth/access_token", json={
        "client_id": settings.SHOPIFY_CLIENT_ID, "client_secret": settings.SHOPIFY_CLIENT_SECRET, "code": code,
    })
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_orders(shop: str, access_token: str, limit: int = 50) -> list[dict]:
    resp = httpx.get(f"https://{shop}/admin/api/2024-10/orders.json", params={"limit": limit, "status": "any"},
                      headers={"X-Shopify-Access-Token": access_token})
    resp.raise_for_status()
    return resp.json().get("orders", [])


def get_products(shop: str, access_token: str, limit: int = 50) -> list[dict]:
    resp = httpx.get(f"https://{shop}/admin/api/2024-10/products.json", params={"limit": limit},
                      headers={"X-Shopify-Access-Token": access_token})
    resp.raise_for_status()
    return resp.json().get("products", [])
