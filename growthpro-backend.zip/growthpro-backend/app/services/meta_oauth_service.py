"""
Real Facebook Login / Meta OAuth flow (Graph API). Requires a Meta App at
developers.facebook.com/apps with the Facebook Login product added, and
(for Instagram) an Instagram professional account linked to a Facebook Page.
Docs: https://developers.facebook.com/docs/facebook-login/guides/access-tokens
"""
import httpx
from app.core.config import settings

GRAPH_VERSION = "v20.0"
GRAPH_BASE = f"https://graph.facebook.com/{GRAPH_VERSION}"

# Minimum scopes for reading Page insights + publishing with approval,
# and resolving the linked Instagram business account (spec section 17-18).
SCOPES = [
    "pages_show_list",
    "pages_read_engagement",
    "pages_manage_posts",
    "instagram_basic",
    "instagram_manage_insights",
    "instagram_content_publish",
]


def build_authorization_url(state: str) -> str:
    scope_str = ",".join(SCOPES)
    return (
        f"https://www.facebook.com/{GRAPH_VERSION}/dialog/oauth"
        f"?client_id={settings.META_APP_ID}"
        f"&redirect_uri={settings.META_REDIRECT_URI}"
        f"&state={state}"
        f"&scope={scope_str}"
        f"&response_type=code"
    )


def exchange_code_for_token(code: str) -> str:
    """Returns a short-lived user access token."""
    resp = httpx.get(f"{GRAPH_BASE}/oauth/access_token", params={
        "client_id": settings.META_APP_ID,
        "client_secret": settings.META_APP_SECRET,
        "redirect_uri": settings.META_REDIRECT_URI,
        "code": code,
    })
    resp.raise_for_status()
    return resp.json()["access_token"]


def exchange_for_long_lived_token(short_lived_token: str) -> str:
    """Short-lived (~1-2h) -> long-lived (~60 days) user token."""
    resp = httpx.get(f"{GRAPH_BASE}/oauth/access_token", params={
        "grant_type": "fb_exchange_token",
        "client_id": settings.META_APP_ID,
        "client_secret": settings.META_APP_SECRET,
        "fb_exchange_token": short_lived_token,
    })
    resp.raise_for_status()
    return resp.json()["access_token"]


def get_pages(user_access_token: str) -> list[dict]:
    """Pages the user manages, each with its own page access token."""
    resp = httpx.get(f"{GRAPH_BASE}/me/accounts", params={"access_token": user_access_token})
    resp.raise_for_status()
    return resp.json().get("data", [])


def get_instagram_business_account(page_id: str, page_access_token: str) -> dict | None:
    resp = httpx.get(f"{GRAPH_BASE}/{page_id}", params={
        "fields": "instagram_business_account{id,username}",
        "access_token": page_access_token,
    })
    resp.raise_for_status()
    return resp.json().get("instagram_business_account")
