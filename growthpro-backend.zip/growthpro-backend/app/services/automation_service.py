"""
Executes Workflow actions when a trigger fires. Kept intentionally simple:
supported actions are the ones that don't require external communication
approval (spec section 62 — no unapproved external comms), so today it's
internal-only (create a task, tag a lead). Email/SMS actions would need an
explicit per-workflow opt-in before this should send anything to a customer.
"""
from sqlalchemy.orm import Session
from datetime import datetime, timezone

from app.models.automation import Workflow, WorkflowRun, WorkflowTrigger
from app.models.crm import CrmTask, Lead


def _matches_conditions(payload: dict, conditions: list) -> bool:
    for cond in conditions:
        field, op, value = cond.get("field"), cond.get("op", "equals"), cond.get("value")
        actual = payload.get(field)
        if op == "equals" and actual != value:
            return False
        if op == "not_equals" and actual == value:
            return False
    return True


def _execute_action(db: Session, action: dict, payload: dict):
    action_type = action.get("type")
    if action_type == "create_task":
        db.add(CrmTask(
            workspace_id=payload["workspace_id"],
            lead_id=payload.get("lead_id"),
            title=action.get("params", {}).get("title", "Follow up"),
        ))
    elif action_type == "tag_lead" and payload.get("lead_id"):
        lead = db.query(Lead).filter(Lead.id == payload["lead_id"]).first()
        if lead:
            tag = action.get("params", {}).get("tag", "")
            lead.notes = f"{lead.notes or ''}\n[workflow tag] {tag}".strip()
    # Extend here for: send_email, send_notification, etc. — each needs its
    # own explicit consent/approval story before it's added.


def fire_trigger(db: Session, workspace_id, trigger: WorkflowTrigger, payload: dict):
    payload = {**payload, "workspace_id": workspace_id}
    workflows = db.query(Workflow).filter(
        Workflow.workspace_id == workspace_id, Workflow.trigger == trigger, Workflow.is_active == True  # noqa: E712
    ).all()
    for wf in workflows:
        if not _matches_conditions(payload, wf.conditions or []):
            continue
        for action in (wf.actions or []):
            _execute_action(db, action, payload)
        db.add(WorkflowRun(workflow_id=wf.id, trigger_payload=payload, actions_executed=wf.actions, ran_at=datetime.now(timezone.utc)))
    db.commit()
