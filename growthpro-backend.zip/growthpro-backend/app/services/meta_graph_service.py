"""Read Page/Instagram data and publish content — with the token stored per workspace."""
import httpx
from app.services.meta_oauth_service import GRAPH_BASE


def get_page_insights(page_id: str, access_token: str, metrics: list[str] | None = None) -> dict:
    metrics = metrics or ["page_impressions", "page_engaged_users", "page_fans"]
    resp = httpx.get(f"{GRAPH_BASE}/{page_id}/insights", params={
        "metric": ",".join(metrics),
        "access_token": access_token,
    })
    resp.raise_for_status()
    return resp.json()


def list_page_posts(page_id: str, access_token: str) -> list[dict]:
    resp = httpx.get(f"{GRAPH_BASE}/{page_id}/posts", params={
        "fields": "message,created_time,permalink_url,insights.metric(post_impressions,post_engaged_users)",
        "access_token": access_token,
    })
    resp.raise_for_status()
    return resp.json().get("data", [])


def publish_page_post(page_id: str, access_token: str, message: str, link: str | None = None) -> dict:
    """Requires explicit user approval before calling (spec section 62)."""
    payload = {"message": message, "access_token": access_token}
    if link:
        payload["link"] = link
    resp = httpx.post(f"{GRAPH_BASE}/{page_id}/feed", data=payload)
    resp.raise_for_status()
    return resp.json()


def get_instagram_media_insights(ig_business_id: str, access_token: str) -> list[dict]:
    resp = httpx.get(f"{GRAPH_BASE}/{ig_business_id}/media", params={
        "fields": "caption,timestamp,permalink,like_count,comments_count",
        "access_token": access_token,
    })
    resp.raise_for_status()
    return resp.json().get("data", [])


def publish_instagram_media(ig_business_id: str, access_token: str, image_or_video_url: str, caption: str, is_video: bool = False) -> dict:
    """
    Real Instagram publish — a two-step process per Meta's Content
    Publishing API: (1) create a media container referencing a PUBLICLY
    reachable image/video URL, (2) publish that container. Video
    containers need time to process before they're publishable, so this
    polls status briefly; a real production system should do this via a
    background job instead of blocking the request.
    """
    import time

    container_params = {"caption": caption, "access_token": access_token}
    if is_video:
        container_params["media_type"] = "REELS"
        container_params["video_url"] = image_or_video_url
    else:
        container_params["image_url"] = image_or_video_url

    create_resp = httpx.post(f"{GRAPH_BASE}/{ig_business_id}/media", data=container_params)
    create_resp.raise_for_status()
    container_id = create_resp.json()["id"]

    if is_video:
        # Video containers process asynchronously — poll for FINISHED before publishing.
        for _ in range(10):
            status_resp = httpx.get(f"{GRAPH_BASE}/{container_id}", params={"fields": "status_code", "access_token": access_token})
            status = status_resp.json().get("status_code")
            if status == "FINISHED":
                break
            if status == "ERROR":
                raise RuntimeError("Instagram video container processing failed")
            time.sleep(3)

    publish_resp = httpx.post(f"{GRAPH_BASE}/{ig_business_id}/media_publish", data={
        "creation_id": container_id, "access_token": access_token,
    })
    publish_resp.raise_for_status()
    return publish_resp.json()
