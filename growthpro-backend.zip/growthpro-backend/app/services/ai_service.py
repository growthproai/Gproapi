"""
Centralized AI service (spec section 58) — every AI call in the app goes
through here, so the provider/model is swappable in one place and prompts
stay server-side (never exposing ANTHROPIC_API_KEY to the frontend).
"""
import json
import anthropic

from app.core.config import settings

_client = anthropic.Anthropic(api_key=settings.ANTHROPIC_API_KEY)
MODEL = "claude-sonnet-4-6"


def generate(system: str, user_prompt: str, max_tokens: int = 1200) -> str:
    resp = _client.messages.create(
        model=MODEL,
        max_tokens=max_tokens,
        system=system,
        messages=[{"role": "user", "content": user_prompt}],
    )
    return "".join(block.text for block in resp.content if block.type == "text").strip()


def generate_json(system: str, user_prompt: str, max_tokens: int = 1200) -> dict:
    raw = generate(system + "\nRespond with ONLY valid JSON. No markdown fences, no commentary.", user_prompt, max_tokens)
    text = raw.strip()
    if text.startswith("```"):
        text = text.strip("`")
        text = text[4:] if text.lower().startswith("json") else text
    start, end = text.find("{"), text.rfind("}")
    if start != -1 and end != -1:
        text = text[start:end + 1]
    return json.loads(text)
