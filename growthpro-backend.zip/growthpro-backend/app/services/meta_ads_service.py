"""
Real Meta Marketing API wrapper — the `ads_management` permission needs
Meta App Review (same manual-approval story as Google Ads), and actually
spending money needs the connected ad account to have valid billing set up
in Meta's own Ads Manager. This wraps the real Graph API marketing endpoints.
Docs: https://developers.facebook.com/docs/marketing-apis
"""
import httpx
from app.services.meta_oauth_service import GRAPH_BASE


def list_ad_accounts(user_access_token: str) -> list[dict]:
    resp = httpx.get(f"{GRAPH_BASE}/me/adaccounts", params={"fields": "name,account_status,currency", "access_token": user_access_token})
    resp.raise_for_status()
    return resp.json().get("data", [])


def create_campaign(ad_account_id: str, access_token: str, name: str, objective: str, daily_budget_cents: int) -> dict:
    """Creates the campaign in PAUSED status — never launches live spend automatically (spec section 62)."""
    resp = httpx.post(f"{GRAPH_BASE}/{ad_account_id}/campaigns", data={
        "name": name,
        "objective": objective,  # e.g. OUTCOME_TRAFFIC, OUTCOME_LEADS, OUTCOME_SALES
        "status": "PAUSED",
        "daily_budget": daily_budget_cents,
        "special_ad_categories": "[]",
        "access_token": access_token,
    })
    resp.raise_for_status()
    return resp.json()
