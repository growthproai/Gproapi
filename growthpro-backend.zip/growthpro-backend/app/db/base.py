# Import every model here so Alembic's autogenerate can discover them
# through Base.metadata, without each router needing to import every model.
from app.db.database import Base  # noqa
from app.models.user import User  # noqa
from app.models.organization import Organization, Membership  # noqa
from app.models.workspace import Workspace  # noqa
from app.models.website import Website  # noqa
from app.models.google_account import GoogleAccount  # noqa
from app.models.youtube_account import YouTubeAccount  # noqa
from app.models.meta_account import MetaAccount  # noqa
from app.models.tiktok_account import TikTokAccount  # noqa
from app.models.seo import SEOAudit, KeywordSet  # noqa
from app.models.content import ContentItem  # noqa
from app.models.backlink import Backlink  # noqa
from app.models.rank_tracking import RankEntry  # noqa
from app.models.audit_log import AuditLog  # noqa
from app.models.subscription import Plan, Subscription  # noqa
from app.models.scheduled_post import ScheduledPost  # noqa
from app.models.crm import Contact, Lead, Deal, CrmTask  # noqa
from app.models.reputation import GoogleBusinessProfile, Review  # noqa
from app.models.competitor import Competitor  # noqa
from app.models.automation import Workflow, WorkflowRun  # noqa
from app.models.wallet import Wallet, WalletTransaction  # noqa
from app.models.marketplace import Creator, Publisher, MarketplaceOrder  # noqa
from app.models.site_builder import BuiltPage  # noqa
from app.models.advertising import AdCampaign  # noqa
from app.models.ad_network import AdSlot, NetworkImpression  # noqa
from app.models.geo_visibility import GeoVisibilityCheck  # noqa
from app.models.notification import Notification, WebhookEndpoint, WebhookDelivery  # noqa
from app.models.cro import Experiment  # noqa
from app.models.media_asset import MediaAsset  # noqa
from app.models.tracking import TrackingEvent  # noqa
from app.models.feature_flag import FeatureFlag  # noqa
from app.models.support import SupportTicket, TicketMessage  # noqa
from app.models.ecommerce import EcommerceStore  # noqa
from app.models.email_sequence import EmailSequence, SequenceEnrollment  # noqa
