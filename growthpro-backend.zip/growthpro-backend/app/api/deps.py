import uuid
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.core.security import decode_access_token
from app.models.user import User
from app.models.organization import Membership
from app.models.workspace import Workspace

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/auth/login", auto_error=False)


def get_current_user(
    token: str = Depends(oauth2_scheme),
    access_token: str | None = None,
    db: Session = Depends(get_db),
) -> User:
    """
    Accepts the JWT from the Authorization header (normal API calls) OR from
    an `access_token` query param — needed for the OAuth "connect" buttons,
    since a browser full-page redirect can't attach a custom header. A query
    param in a URL is more exposure-prone (browser history, server logs), so
    swap this for a short-lived signed one-time link before going to production.
    """
    raw = token or access_token
    if not raw:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Not authenticated")
    user_id = decode_access_token(raw)
    if not user_id:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid or expired token")
    user = db.query(User).filter(User.id == uuid.UUID(user_id)).first()
    if not user or not user.is_active:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="User not found or inactive")
    return user


def require_platform_admin(user: User = Depends(get_current_user)) -> User:
    """Gate for /api/admin/* routes (spec section 41-42)."""
    if not user.is_platform_admin:
        raise HTTPException(status_code=403, detail="Platform admin access required")
    return user


def get_workspace_or_403(workspace_id: uuid.UUID, db: Session, user: User) -> Workspace:
    """
    Tenant-isolation guard: confirms `user` belongs to an organization that
    owns `workspace_id` before any route touches that workspace's data.
    This check is what makes the multi-tenant model in spec section 5 real —
    every workspace-scoped route must call this before running a query.
    """
    workspace = db.query(Workspace).filter(Workspace.id == workspace_id).first()
    if not workspace:
        raise HTTPException(status_code=404, detail="Workspace not found")
    membership = (
        db.query(Membership)
        .filter(
            Membership.user_id == user.id,
            Membership.organization_id == workspace.organization_id,
        )
        .first()
    )
    if not membership:
        raise HTTPException(status_code=403, detail="You don't have access to this workspace")
    return workspace
