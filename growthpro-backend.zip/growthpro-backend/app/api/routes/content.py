import uuid
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.content import ContentItem
from app.services.ai_service import generate

router = APIRouter(prefix="/api/content", tags=["content"])

CONTENT_PROMPTS = {
    "blog": "an SEO-optimized blog article with headings, ~500-700 words",
    "meta": "a meta title (<=60 chars) and meta description (<=155 chars), 3 variants",
    "social": "a social media caption plus relevant hashtags",
    "youtube": "3 YouTube title options, a description, and tags",
    "ad": "ad copy (headline + primary text + CTA), 3 variants",
    "script": "a 30-45 second short-form video script (hook + body + CTA)",
}


class ContentRequest(BaseModel):
    workspace_id: uuid.UUID
    content_type: str
    topic: str
    keywords: str | None = None
    tone: str = "Professional"
    language: str = "English"
    platform: str | None = None


@router.post("")
@limiter.limit("20/hour")
def generate_content(request: Request, payload: ContentRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    instruction = CONTENT_PROMPTS.get(payload.content_type, payload.content_type)
    output = generate(
        system="You are an expert SEO content writer. Write only the requested content — no preamble. "
               "Never promise guaranteed rankings/virality or fabricate statistics.",
        user_prompt=f"Write: {instruction}\nTopic: {payload.topic}\n"
                    f"Keywords: {payload.keywords or 'n/a'}\nTone: {payload.tone}\nLanguage: {payload.language}\n"
                    f"Platform: {payload.platform or 'n/a'}",
    )
    row = ContentItem(
        workspace_id=payload.workspace_id, content_type=payload.content_type, topic=payload.topic,
        platform=payload.platform, language=payload.language, output=output,
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row
