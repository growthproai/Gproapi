"""
Unified Analytics, Revenue Attribution, Customer Retention, and AI
Forecasting (spec sections 42, 44-47). Computed from real CRM data that
actually exists in this workspace — never fabricated. Forecasting is
clearly labeled as an estimate, never a guarantee (spec section 47).
"""
import uuid
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, Request
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.crm import Lead, Deal, LeadStatus
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


@router.get("/overview")
def analytics_overview(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 44 — unified leads/sales/revenue view from real CRM records."""
    get_workspace_or_403(workspace_id, db, user)

    total_leads = db.query(Lead).filter(Lead.workspace_id == workspace_id).count()
    won_deals = db.query(Deal).filter(Deal.workspace_id == workspace_id, Deal.stage == LeadStatus.won).all()
    lost_deals = db.query(Deal).filter(Deal.workspace_id == workspace_id, Deal.stage == LeadStatus.lost).count()
    open_deals = db.query(Deal).filter(Deal.workspace_id == workspace_id, Deal.stage.notin_([LeadStatus.won, LeadStatus.lost])).count()

    revenue = sum(d.value or 0 for d in won_deals)

    by_source = (
        db.query(Lead.source, func.count(Lead.id))
        .filter(Lead.workspace_id == workspace_id).group_by(Lead.source).all()
    )
    revenue_by_source = (
        db.query(Deal.source, func.sum(Deal.value))
        .filter(Deal.workspace_id == workspace_id, Deal.stage == LeadStatus.won).group_by(Deal.source).all()
    )

    return {
        "total_leads": total_leads,
        "won_deals": len(won_deals),
        "lost_deals": lost_deals,
        "open_deals": open_deals,
        "win_rate_percent": round(len(won_deals) / (len(won_deals) + lost_deals) * 100, 1) if (len(won_deals) + lost_deals) else None,
        "total_revenue": revenue,
        "leads_by_source": [{"source": s or "unknown", "count": c} for s, c in by_source],
        "revenue_by_source": [{"source": s or "unknown", "revenue": r or 0} for s, r in revenue_by_source],
    }


@router.get("/retention")
def customer_retention(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """
    Section 42 — churn-risk signal from real deal/contact data: a contact
    with a won deal more than 90 days ago and no new deal since is flagged
    as at-risk. Simple and honest rather than a fabricated ML churn score.
    """
    get_workspace_or_403(workspace_id, db, user)
    cutoff = datetime.now(timezone.utc) - timedelta(days=90)

    won = db.query(Deal).filter(Deal.workspace_id == workspace_id, Deal.stage == LeadStatus.won).all()
    by_contact: dict = {}
    for d in won:
        if d.contact_id:
            by_contact.setdefault(str(d.contact_id), []).append(d)

    at_risk, repeat_customers = [], []
    for contact_id, deals in by_contact.items():
        last_deal = max(deals, key=lambda d: d.closed_at or d.created_at)
        last_date = last_deal.closed_at or last_deal.created_at
        if len(deals) > 1:
            repeat_customers.append(contact_id)
        if last_date and last_date.replace(tzinfo=timezone.utc) < cutoff:
            at_risk.append({"contact_id": contact_id, "last_purchase": last_date.isoformat(), "total_deals": len(deals)})

    return {
        "repeat_customers": len(repeat_customers),
        "at_risk_customers": at_risk,
        "note": "At-risk = no won deal in 90+ days. This is a simple recency rule, not a predictive churn model.",
    }


@router.get("/forecast")
@limiter.limit("10/hour")
def ai_forecast(request: Request, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 47 — AI forecast, explicitly labeled as an estimate."""
    get_workspace_or_403(workspace_id, db, user)

    since = datetime.now(timezone.utc) - timedelta(days=90)
    recent_leads = db.query(Lead).filter(Lead.workspace_id == workspace_id, Lead.created_at >= since).count()
    recent_won = db.query(Deal).filter(Deal.workspace_id == workspace_id, Deal.stage == LeadStatus.won, Deal.closed_at >= since).all()
    recent_revenue = sum(d.value or 0 for d in recent_won)

    if recent_leads == 0 and not recent_won:
        return {"forecast_available": False, "reason": "Not enough historical data yet (need at least some leads/deals from the last 90 days)."}

    result = generate_json(
        system="You are a business forecasting assistant. NEVER present a forecast as guaranteed — "
               "always frame it as an estimate with a plain-language confidence caveat.",
        user_prompt=f"Last 90 days: {recent_leads} leads, {len(recent_won)} deals won, revenue {recent_revenue}.\n"
                    'Return JSON: {"forecast_next_30_days":{"leads_estimate":0,"revenue_estimate":0},'
                    '"confidence":"low|medium|high","confidence_reason":"","label":"Forecast / Estimate — not a guarantee"}',
    )
    result["forecast_available"] = True
    return result
