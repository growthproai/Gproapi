"""
NeerMela/GrowthPro Wallet (spec section 59) — a debit ledger, funded via
Stripe. Every balance change is a row, never an in-place update-only field,
so the transaction history is always reconstructable and auditable.
"""
import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.organization import Membership
from app.models.wallet import Wallet, WalletTransaction, TransactionType, TransactionStatus
from app.services import stripe_service

router = APIRouter(prefix="/api/wallet", tags=["wallet"])


def _get_or_create_wallet(db: Session, organization_id: uuid.UUID) -> Wallet:
    wallet = db.query(Wallet).filter(Wallet.organization_id == organization_id).first()
    if not wallet:
        wallet = Wallet(organization_id=organization_id)
        db.add(wallet)
        db.commit()
        db.refresh(wallet)
    return wallet


def _require_membership(db: Session, user: User, organization_id: uuid.UUID):
    if not db.query(Membership).filter(Membership.user_id == user.id, Membership.organization_id == organization_id).first():
        raise HTTPException(403, "Not a member of this organization")


@router.get("/balance")
def get_balance(organization_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _require_membership(db, user, organization_id)
    wallet = _get_or_create_wallet(db, organization_id)
    return {"balance": wallet.balance, "currency": wallet.currency}


@router.get("/transactions")
def list_transactions(organization_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    _require_membership(db, user, organization_id)
    wallet = _get_or_create_wallet(db, organization_id)
    return db.query(WalletTransaction).filter(WalletTransaction.wallet_id == wallet.id).order_by(WalletTransaction.created_at.desc()).all()


class TopupRequest(BaseModel):
    organization_id: uuid.UUID
    amount: int  # smallest currency unit
    stripe_price_id: str  # a one-time Price in Stripe Dashboard for wallet top-ups


@router.post("/topup-session")
def start_topup(payload: TopupRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Creates a Stripe Checkout session for a one-time top-up. On success, the
    webhook (see billing.py — extend it for `checkout.session.completed` with
    mode=payment) should call `credit_wallet()` below rather than crediting client-side."""
    _require_membership(db, user, payload.organization_id)
    customer_id = stripe_service.get_or_create_customer(user.email, str(payload.organization_id))
    session = stripe_service.create_checkout_session(customer_id, payload.stripe_price_id, str(payload.organization_id))
    return {"checkout_url": session.url}


def credit_wallet(db: Session, organization_id: uuid.UUID, amount: int, tx_type: TransactionType, description: str, stripe_payment_intent_id: str | None = None) -> WalletTransaction:
    wallet = _get_or_create_wallet(db, organization_id)
    wallet.balance += amount
    tx = WalletTransaction(wallet_id=wallet.id, type=tx_type, amount=amount, description=description, stripe_payment_intent_id=stripe_payment_intent_id)
    db.add(tx)
    db.commit()
    return tx


def debit_wallet(db: Session, organization_id: uuid.UUID, amount: int, tx_type: TransactionType, description: str) -> WalletTransaction:
    """Raises if the debit would take the balance negative — never allow overdraft silently."""
    wallet = _get_or_create_wallet(db, organization_id)
    if wallet.balance < amount:
        raise HTTPException(402, f"Insufficient wallet balance: have {wallet.balance}, need {amount}")
    wallet.balance -= amount
    tx = WalletTransaction(wallet_id=wallet.id, type=tx_type, amount=-amount, description=description)
    db.add(tx)
    db.commit()
    return tx
