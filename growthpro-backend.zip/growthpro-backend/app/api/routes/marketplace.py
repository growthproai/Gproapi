"""Creator/Publisher Marketplace (spec sections 63-65)."""
import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.marketplace import Creator, Publisher, MarketplaceOrder, OrderStatus
from app.api.deps import require_platform_admin

router = APIRouter(prefix="/api/marketplace", tags=["marketplace"])


# ---- Creator profiles ----
class CreatorCreate(BaseModel):
    display_name: str
    platforms: list[str] = []
    category: str | None = None
    country: str | None = None
    follower_count: int | None = None
    content_type: str | None = None
    starting_price: int | None = None
    bio: str | None = None
    portfolio_links: list[str] = []


@router.post("/creators")
def create_creator_profile(payload: CreatorCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    row = Creator(user_id=user.id, **payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/creators")
def discover_creators(category: str | None = None, platform: str | None = None, country: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Public-to-any-logged-in-user discovery — advertisers browse this to find creators."""
    q = db.query(Creator)
    if category:
        q = q.filter(Creator.category == category)
    if country:
        q = q.filter(Creator.country == country)
    if platform:
        q = q.filter(Creator.platforms.contains([platform]))
    return q.all()


@router.post("/creators/{creator_id}/verify")
def verify_creator(creator_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    """Manual admin verification — this build doesn't auto-verify follower counts against real platform APIs."""
    creator = db.query(Creator).filter(Creator.id == creator_id).first()
    if creator:
        creator.is_verified = "verified"
        db.commit()
    return creator


# ---- Publisher profiles ----
class PublisherCreate(BaseModel):
    property_name: str
    property_url: str
    property_type: str = "website"
    category: str | None = None
    monthly_traffic_estimate: int | None = None


@router.post("/publishers")
def create_publisher_profile(payload: PublisherCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    row = Publisher(user_id=user.id, **payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/publishers")
def discover_publishers(category: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    q = db.query(Publisher)
    if category:
        q = q.filter(Publisher.category == category)
    return q.all()


# ---- Orders ----
class OrderCreate(BaseModel):
    workspace_id: uuid.UUID
    creator_id: uuid.UUID | None = None
    publisher_id: uuid.UUID | None = None
    service_description: str
    agreed_price: int | None = None


@router.post("/orders")
def create_order(payload: OrderCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    if not payload.creator_id and not payload.publisher_id:
        raise HTTPException(400, "Specify either creator_id or publisher_id")
    row = MarketplaceOrder(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/orders")
def list_orders(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(MarketplaceOrder).filter(MarketplaceOrder.workspace_id == workspace_id).all()


@router.post("/orders/{order_id}/status")
def update_order_status(order_id: uuid.UUID, workspace_id: uuid.UUID, status: OrderStatus, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    order = db.query(MarketplaceOrder).filter(MarketplaceOrder.id == order_id).first()
    if order:
        order.status = status
        db.commit()
    return order
