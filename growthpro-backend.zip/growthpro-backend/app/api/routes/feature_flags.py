"""Feature flags — spec section 70. Public GET (any client needs to know what's on), admin-only writes."""
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import require_platform_admin
from app.models.user import User
from app.models.feature_flag import FeatureFlag

router = APIRouter(prefix="/api/feature-flags", tags=["feature-flags"])

DEFAULT_FLAGS = {
    "seo_enabled": "SEO Intelligence", "ai_content_enabled": "AI Content", "geo_enabled": "AI/GEO Visibility",
    "social_enabled": "Social Growth", "ads_enabled": "Ad Center", "crm_enabled": "CRM",
    "creator_network_enabled": "Creator Network", "publisher_network_enabled": "Publisher Network",
    "marketplace_enabled": "Marketplace", "api_enabled": "Developer API", "ad_network_enabled": "GrowthPro Ad Network",
}


def _ensure_defaults(db: Session):
    existing = {f.key for f in db.query(FeatureFlag.key).all()}
    for key, label in DEFAULT_FLAGS.items():
        if key not in existing:
            db.add(FeatureFlag(key=key, label=label, is_enabled=True))
    db.commit()


@router.get("")
def list_flags(db: Session = Depends(get_db)):
    """No auth required — every part of the app (backend routes, frontend nav) needs to check these."""
    _ensure_defaults(db)
    flags = db.query(FeatureFlag).all()
    return {f.key: f.is_enabled for f in flags}


@router.post("/{key}/toggle")
def toggle_flag(key: str, db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    _ensure_defaults(db)
    flag = db.query(FeatureFlag).filter(FeatureFlag.key == key).first()
    if not flag:
        return {"error": "Unknown flag"}
    flag.is_enabled = not flag.is_enabled
    db.commit()
    return {"key": key, "is_enabled": flag.is_enabled}
