"""
Public, unauthenticated endpoints — the top of the funnel (spec section 76-77:
Visitor -> Free Growth Audit -> Create Account -> ...). No login required by
design; this is meant to sit behind a public landing page and be the reason
a stranger creates an account.
"""
from fastapi import APIRouter, Request, HTTPException
import httpx

from app.core.limiter import limiter
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/public", tags=["public"])


@router.get("/growth-audit")
@limiter.limit("5/hour")  # this endpoint costs an AI call and has no auth — must be tightly limited against abuse
def free_growth_audit(request: Request, website_url: str):
    if not website_url.startswith(("http://", "https://")):
        website_url = "https://" + website_url

    try:
        resp = httpx.get(website_url, timeout=10, follow_redirects=True)
        page_content = resp.text[:5000]
    except Exception:
        raise HTTPException(400, "Couldn't reach that website — check the URL and that it's publicly accessible.")

    result = generate_json(
        system="You are GrowthPro's free public Growth Audit tool — a lightweight teaser, not the full "
               "AI Business Doctor. Base every finding strictly on the page content given. Keep it useful "
               "but clearly limited: this is meant to make the visitor want the full report after signing up.",
        user_prompt=f'Website: {website_url}\nPage content (truncated):\n"""{page_content}"""\n'
                    'Return JSON: {"basic_growth_score":0-100,"seo_score":0-100,"website_score":0-100,'
                    '"top_3_opportunities":["","",""],"teaser_message":"one line encouraging sign-up for the full report"}',
    )
    result["_note"] = "Free preview — based only on your homepage's public content. Full report needs a connected account."
    return result
