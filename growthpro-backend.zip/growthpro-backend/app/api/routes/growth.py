"""
AI Growth Command Center backend (spec sections 2-6): Growth Score and
AI Business Doctor. Both are computed on-demand from whatever data actually
exists for the workspace — they degrade gracefully and say so explicitly
when a module (ads, CRM, social) isn't connected yet, rather than
fabricating a number for something nobody has plugged in.
"""
import uuid
from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.workspace import Workspace
from app.models.seo import SEOAudit, KeywordSet
from app.models.content import ContentItem
from app.models.backlink import Backlink
from app.models.rank_tracking import RankEntry
from app.models.website import Website
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/growth", tags=["growth"])


def _gather_workspace_signals(db: Session, workspace: Workspace) -> dict:
    website = db.query(Website).filter(Website.workspace_id == workspace.id).first()
    latest_audit = (
        db.query(SEOAudit).join(Website, SEOAudit.website_id == Website.id)
        .filter(Website.workspace_id == workspace.id).order_by(SEOAudit.created_at.desc()).first()
    )
    return {
        "business": {
            "name": workspace.name, "industry": workspace.industry, "niche": workspace.niche,
            "country": workspace.country, "city": workspace.city,
            "target_market": workspace.target_market, "main_goal": workspace.main_goal,
        },
        "website_connected": website is not None,
        "latest_seo_score": latest_audit.score_breakdown if latest_audit else None,
        "keyword_research_runs": db.query(KeywordSet).filter(KeywordSet.workspace_id == workspace.id).count(),
        "content_pieces_published": db.query(ContentItem).filter(ContentItem.workspace_id == workspace.id).count(),
        "backlink_prospects": db.query(Backlink).filter(Backlink.workspace_id == workspace.id).count(),
        "rank_checks_logged": db.query(RankEntry).filter(RankEntry.workspace_id == workspace.id).count(),
        # These modules don't exist yet in this build — the AI is told explicitly
        # so it never invents a social/ads/CRM number that looks measured but isn't.
        "modules_not_yet_connected": ["social_analytics", "advertising", "crm_leads", "ai_geo_visibility"],
    }


@router.get("/score")
@limiter.limit("30/hour")
def growth_score(request: Request, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace = get_workspace_or_403(workspace_id, db, user)
    signals = _gather_workspace_signals(db, workspace)

    result = generate_json(
        system="You are GrowthPro's Growth Score engine. Compute a transparent 0-100 score from the REAL "
               "signals given — never invent data for a module listed under modules_not_yet_connected; "
               "instead note it's unmeasured and exclude it from the score rather than guessing a number. "
               "This score must never be presented as an official Google/Meta ranking — it's GrowthPro's own metric.",
        user_prompt=f"Workspace signals (JSON): {signals}\n"
                    'Return JSON: {"overall_score":0-100,"breakdown":{"seo":0-100,"content":0-100,"website":0-100},'
                    '"unmeasured_modules":["..."],"why":"1-2 sentence plain-language explanation",'
                    '"top_priority_actions":["","",""]}',
    )
    result["_data_source_note"] = "Computed from connected GrowthPro data only. Unmeasured modules are excluded, not estimated."
    return result


@router.get("/business-doctor")
@limiter.limit("10/hour")
def ai_business_doctor(request: Request, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 5 — full SWOT-style audit using whatever real data exists for this workspace."""
    workspace = get_workspace_or_403(workspace_id, db, user)
    signals = _gather_workspace_signals(db, workspace)

    if not signals["business"]["industry"] and not signals["website_connected"]:
        raise HTTPException(
            400,
            "Not enough business context yet — complete the Business Setup Wizard "
            "(POST /api/workspaces/setup-wizard) and connect a website first."
        )

    result = generate_json(
        system="You are GrowthPro's AI Business Doctor. Produce a SWOT-style business health report "
               "grounded ONLY in the real signals provided. For any area with no data (see "
               "modules_not_yet_connected), say so explicitly in that section rather than inventing findings.",
        user_prompt=f"Workspace signals (JSON): {signals}\n"
                    'Return JSON: {"strengths":["..."],"weaknesses":["..."],"opportunities":["..."],'
                    '"threats":["..."],"growth_opportunities":["..."],'
                    '"recommended_actions":[{"action":"","why":"","priority":"High|Medium|Low"}]}',
        max_tokens=1500,
    )
    return result
