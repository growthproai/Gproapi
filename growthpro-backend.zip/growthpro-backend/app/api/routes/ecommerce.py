"""Shopify + WooCommerce integration routes (spec section 56)."""
import uuid
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session
from itsdangerous import URLSafeSerializer, BadSignature

from app.db.database import get_db
from app.core.config import settings
from app.core.security import encrypt_token, decrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.ecommerce import EcommerceStore
from app.services import shopify_service, woocommerce_service

router = APIRouter(prefix="/api/ecommerce", tags=["ecommerce"])
_signer = URLSafeSerializer(settings.SECRET_KEY, salt="shopify-oauth-state")


@router.get("/shopify/oauth/authorize")
def shopify_authorize(shop: str, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    state = _signer.dumps({"workspace_id": str(workspace_id), "shop": shop})
    return RedirectResponse(shopify_service.build_authorization_url(shop, state))


@router.get("/shopify/oauth/callback")
def shopify_callback(shop: str, code: str, state: str, db: Session = Depends(get_db)):
    try:
        payload = _signer.loads(state)
    except BadSignature:
        raise HTTPException(400, "Invalid OAuth state")
    token = shopify_service.exchange_code_for_token(shop, code)
    store = EcommerceStore(workspace_id=payload["workspace_id"], platform="shopify", store_url=shop, encrypted_access_token=encrypt_token(token))
    db.add(store)
    db.commit()
    return RedirectResponse(f"{settings.FRONTEND_URL}/settings/integrations?connected=shopify")


class WooCommerceConnect(BaseModel):
    workspace_id: uuid.UUID
    store_url: str
    consumer_key: str
    consumer_secret: str


@router.post("/woocommerce/connect")
def woocommerce_connect(payload: WooCommerceConnect, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """No OAuth redirect for WooCommerce — the store owner pastes their own generated API keys."""
    get_workspace_or_403(payload.workspace_id, db, user)
    # verify the credentials actually work before saving them
    try:
        woocommerce_service.get_products(payload.store_url, payload.consumer_key, payload.consumer_secret, per_page=1)
    except Exception as e:
        raise HTTPException(400, f"Couldn't connect — check your store URL and API keys: {e}")

    store = EcommerceStore(
        workspace_id=payload.workspace_id, platform="woocommerce", store_url=payload.store_url,
        api_key=payload.consumer_key, encrypted_access_token=encrypt_token(payload.consumer_secret),
    )
    db.add(store)
    db.commit()
    return {"connected": True}


@router.get("/orders")
def get_orders(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    store = db.query(EcommerceStore).filter(EcommerceStore.workspace_id == workspace_id).first()
    if not store:
        raise HTTPException(404, "No Shopify/WooCommerce store connected")

    if store.platform == "shopify":
        return shopify_service.get_orders(store.store_url, decrypt_token(store.encrypted_access_token))
    return woocommerce_service.get_orders(store.store_url, store.api_key, decrypt_token(store.encrypted_access_token))


@router.get("/products")
def get_products(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    store = db.query(EcommerceStore).filter(EcommerceStore.workspace_id == workspace_id).first()
    if not store:
        raise HTTPException(404, "No Shopify/WooCommerce store connected")

    if store.platform == "shopify":
        return shopify_service.get_products(store.store_url, decrypt_token(store.encrypted_access_token))
    return woocommerce_service.get_products(store.store_url, store.api_key, decrypt_token(store.encrypted_access_token))
