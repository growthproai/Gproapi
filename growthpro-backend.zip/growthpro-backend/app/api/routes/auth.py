import re
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session
from itsdangerous import URLSafeTimedSerializer, BadSignature, SignatureExpired

from app.db.database import get_db
from app.core.config import settings
from app.core.security import hash_password, verify_password, create_access_token
from app.core.limiter import limiter
from app.models.user import User
from app.models.organization import Organization, Membership, MemberRole
from app.schemas.auth import (
    UserRegister, UserLogin, Token, UserOut,
    ForgotPasswordRequest, ResetPasswordRequest, VerifyEmailRequest,
)
from app.api.deps import get_current_user
from app.services.email_service import send_email

router = APIRouter(prefix="/api/auth", tags=["auth"])

_email_serializer = URLSafeTimedSerializer(settings.SECRET_KEY, salt="email-verify")
_reset_serializer = URLSafeTimedSerializer(settings.SECRET_KEY, salt="password-reset")

VERIFY_TOKEN_MAX_AGE = 60 * 60 * 24        # 24h
RESET_TOKEN_MAX_AGE = 60 * 60              # 1h


def slugify(name: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")


def _send_verification_email(user: User):
    token = _email_serializer.dumps(str(user.id))
    verify_url = f"{settings.FRONTEND_URL}/verify-email?token={token}"
    send_email(
        to=user.email,
        subject="Verify your GrowthPro account",
        html=f"<p>Welcome to GrowthPro. Click to verify your email:</p><p><a href='{verify_url}'>{verify_url}</a></p><p>This link expires in 24 hours.</p>",
    )


@router.post("/register", response_model=Token)
@limiter.limit("5/minute")
def register(request: Request, payload: UserRegister, db: Session = Depends(get_db)):
    if db.query(User).filter(User.email == payload.email).first():
        raise HTTPException(400, "Email already registered")

    user = User(email=payload.email, hashed_password=hash_password(payload.password), full_name=payload.full_name)
    db.add(user)
    db.flush()

    org = Organization(name=payload.organization_name, slug=slugify(payload.organization_name))
    db.add(org)
    db.flush()

    db.add(Membership(user_id=user.id, organization_id=org.id, role=MemberRole.owner))
    db.commit()

    _send_verification_email(user)

    return Token(access_token=create_access_token(str(user.id)))


@router.post("/login", response_model=Token)
@limiter.limit("10/minute")
def login(request: Request, form_data: OAuth2PasswordRequestForm = Depends(), db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == form_data.username).first()
    if not user or not verify_password(form_data.password, user.hashed_password):
        raise HTTPException(401, "Incorrect email or password")
    return Token(access_token=create_access_token(str(user.id)))


@router.get("/me", response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return current_user


# ---- Email verification (spec section 4) ----
@router.post("/verify-email/resend")
def resend_verification(current_user: User = Depends(get_current_user)):
    if current_user.is_verified:
        return {"already_verified": True}
    _send_verification_email(current_user)
    return {"sent": True}


@router.post("/verify-email/confirm")
def confirm_verification(payload: VerifyEmailRequest, db: Session = Depends(get_db)):
    try:
        user_id = _email_serializer.loads(payload.token, max_age=VERIFY_TOKEN_MAX_AGE)
    except SignatureExpired:
        raise HTTPException(400, "Verification link expired — request a new one")
    except BadSignature:
        raise HTTPException(400, "Invalid verification link")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    user.is_verified = True
    db.commit()
    return {"verified": True}


# ---- Password reset (spec section 4) ----
@router.post("/forgot-password")
@limiter.limit("5/hour")
def forgot_password(request: Request, payload: ForgotPasswordRequest, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if user:
        token = _reset_serializer.dumps(str(user.id))
        reset_url = f"{settings.FRONTEND_URL}/reset-password?token={token}"
        send_email(
            to=user.email,
            subject="Reset your GrowthPro password",
            html=f"<p>Click to reset your password:</p><p><a href='{reset_url}'>{reset_url}</a></p><p>This link expires in 1 hour. If you didn't request this, ignore this email.</p>",
        )
    # Always return the same response whether or not the email exists —
    # otherwise this endpoint becomes a way to enumerate registered emails.
    return {"message": "If that email is registered, a reset link has been sent."}


@router.post("/reset-password")
@limiter.limit("5/hour")
def reset_password(request: Request, payload: ResetPasswordRequest, db: Session = Depends(get_db)):
    try:
        user_id = _reset_serializer.loads(payload.token, max_age=RESET_TOKEN_MAX_AGE)
    except SignatureExpired:
        raise HTTPException(400, "Reset link expired — request a new one")
    except BadSignature:
        raise HTTPException(400, "Invalid reset link")

    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    user.hashed_password = hash_password(payload.new_password)
    db.commit()
    return {"reset": True}
