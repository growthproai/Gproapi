import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.core.security import decrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.youtube_account import YouTubeAccount
from app.services import google_oauth_service, youtube_service

router = APIRouter(prefix="/api/youtube", tags=["youtube"])


def _get_credentials(workspace_id: uuid.UUID, db: Session):
    account = db.query(YouTubeAccount).filter(YouTubeAccount.workspace_id == workspace_id).first()
    if not account:
        raise HTTPException(404, "No YouTube channel connected for this workspace.")
    refresh_token = decrypt_token(account.encrypted_refresh_token)
    return google_oauth_service.credentials_from_refresh_token(refresh_token)


@router.get("/channel")
def channel(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    creds = _get_credentials(workspace_id, db)
    return youtube_service.get_my_channel(creds)


@router.get("/videos")
def videos(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    creds = _get_credentials(workspace_id, db)
    return youtube_service.list_my_videos(creds)


@router.post("/videos/{video_id}/metadata")
def update_metadata(
    video_id: str,
    workspace_id: uuid.UUID,
    title: str,
    description: str,
    tags: list[str],
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """User-approved metadata update (spec section 62 — never automatic)."""
    get_workspace_or_403(workspace_id, db, user)
    creds = _get_credentials(workspace_id, db)
    return youtube_service.update_video_metadata(creds, video_id, title, description, tags)
