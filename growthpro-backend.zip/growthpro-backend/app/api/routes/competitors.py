"""
Competitor Intelligence (spec section 22). Combines real backlink/domain-
authority data (DataForSEO, when configured) with AI-driven content/keyword
gap analysis — clearly labels which parts of the report are measured vs.
AI inference, per the Trust Center principle (spec section 66).
"""
import uuid
from datetime import datetime, timezone
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.competitor import Competitor
from app.models.workspace import Workspace
from app.models.content import ContentItem
from app.services.ai_service import generate_json
from app.services import dataforseo_service

router = APIRouter(prefix="/api/competitors", tags=["competitors"])


class CompetitorCreate(BaseModel):
    workspace_id: uuid.UUID
    domain: str
    name: str | None = None


@router.get("")
def list_competitors(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(Competitor).filter(Competitor.workspace_id == workspace_id).all()


@router.post("")
def add_competitor(payload: CompetitorCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Competitor(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.delete("/{competitor_id}")
def remove_competitor(competitor_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    db.query(Competitor).filter(Competitor.id == competitor_id).delete()
    db.commit()
    return {"deleted": True}


@router.post("/{competitor_id}/analyze")
@limiter.limit("15/hour")
def analyze_competitor(request: Request, competitor_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace = get_workspace_or_403(workspace_id, db, user)
    competitor = db.query(Competitor).filter(Competitor.id == competitor_id).first()
    if not competitor:
        return {"error": "Competitor not found"}

    # Real data where available (falls back gracefully without DataForSEO configured)
    backlink_data = {}
    try:
        backlink_data = dataforseo_service.get_backlink_summary(competitor.domain)
    except Exception:
        pass

    own_content_topics = [
        c.topic for c in db.query(ContentItem).filter(ContentItem.workspace_id == workspace_id).limit(30)
    ]

    result = generate_json(
        system="You are a competitor-intelligence analyst. Base the content/keyword gap analysis on the "
               "business context and the competitor's domain given — flag clearly that specific competitor "
               "page content wasn't crawled in this analysis (that would need a separate fetch of their site), "
               "so gap suggestions are informed estimates, not a verified content audit.",
        user_prompt=f"Our business: {workspace.name}, industry: {workspace.industry or workspace.niche}\n"
                    f"Our recent content topics: {own_content_topics}\n"
                    f"Competitor domain: {competitor.domain}\n"
                    f"Competitor real backlink data (if empty, not available): {backlink_data}\n"
                    'Return JSON: {"likely_content_gaps":["..."],"likely_keyword_opportunities":["..."],'
                    '"suggested_actions":["..."]}',
    )
    result["real_backlink_data"] = backlink_data or None
    result["_data_source_note"] = "Backlink numbers are real (DataForSEO) when present. Content/keyword gaps are AI inference, not a crawled audit of the competitor's site."

    competitor.last_gap_report = result
    competitor.last_analyzed_at = datetime.now(timezone.utc)
    db.commit()
    return result
