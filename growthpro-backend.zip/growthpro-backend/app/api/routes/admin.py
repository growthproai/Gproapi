import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import require_platform_admin
from app.models.user import User
from app.models.organization import Organization, Membership
from app.models.workspace import Workspace
from app.models.subscription import Plan, Subscription
from app.models.audit_log import AuditLog

router = APIRouter(prefix="/api/admin", tags=["admin"])


# ---- Users (spec section 42) ----
@router.get("/users")
def list_users(db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    return db.query(User).all()


@router.post("/users/{user_id}/suspend")
def suspend_user(user_id: uuid.UUID, db: Session = Depends(get_db), admin: User = Depends(require_platform_admin)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    user.is_active = False
    db.add(AuditLog(user_id=admin.id, action="admin_suspended_user", meta={"target_user_id": str(user_id)}))
    db.commit()
    return {"suspended": True}


@router.post("/users/{user_id}/activate")
def activate_user(user_id: uuid.UUID, db: Session = Depends(get_db), admin: User = Depends(require_platform_admin)):
    user = db.query(User).filter(User.id == user_id).first()
    if not user:
        raise HTTPException(404, "User not found")
    user.is_active = True
    db.add(AuditLog(user_id=admin.id, action="admin_activated_user", meta={"target_user_id": str(user_id)}))
    db.commit()
    return {"activated": True}


# ---- Organizations & workspaces (read-only overview) ----
@router.get("/organizations")
def list_organizations(db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    return db.query(Organization).all()


@router.get("/organizations/{org_id}/workspaces")
def list_org_workspaces(org_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    return db.query(Workspace).filter(Workspace.organization_id == org_id).all()


@router.get("/organizations/{org_id}/members")
def list_org_members(org_id: uuid.UUID, db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    return db.query(Membership).filter(Membership.organization_id == org_id).all()


# ---- Plans (admin-editable pricing — spec section 43) ----
@router.get("/plans")
def list_plans(db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    return db.query(Plan).all()


@router.post("/plans")
def upsert_plan(
    code: str, name: str, price_aed_cents: int, ai_credits_per_month: int,
    max_websites: int = 1, max_workspaces: int = 1,
    db: Session = Depends(get_db), _: User = Depends(require_platform_admin),
):
    plan = db.query(Plan).filter(Plan.code == code).first()
    if plan:
        plan.name, plan.price_aed_cents, plan.ai_credits_per_month = name, price_aed_cents, ai_credits_per_month
        plan.max_websites, plan.max_workspaces = max_websites, max_workspaces
    else:
        plan = Plan(code=code, name=name, price_aed_cents=price_aed_cents, ai_credits_per_month=ai_credits_per_month,
                    max_websites=max_websites, max_workspaces=max_workspaces)
        db.add(plan)
    db.commit()
    db.refresh(plan)
    return plan


# ---- Subscriptions overview ----
@router.get("/subscriptions")
def list_subscriptions(db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    return db.query(Subscription).all()


# ---- Audit log viewer (spec section 76) ----
@router.get("/audit-logs")
def list_audit_logs(limit: int = 100, db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    return db.query(AuditLog).order_by(AuditLog.created_at.desc()).limit(limit).all()
