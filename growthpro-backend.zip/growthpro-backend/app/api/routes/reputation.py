"""
Local SEO + Reputation Management (spec sections 11-12). Google Business
Profile API access requires a separate Google approval process beyond
normal OAuth scopes (Google manually vets API access for this one) — so
this ships with manual review logging + AI sentiment/response working now,
and a connect endpoint ready for whenever GBP API access is approved.
"""
import uuid
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.reputation import Review
from app.services.ai_service import generate_json, generate

router = APIRouter(prefix="/api/reputation", tags=["reputation"])


class ReviewCreate(BaseModel):
    workspace_id: uuid.UUID
    platform: str = "manual"
    reviewer_name: str | None = None
    rating: int
    text: str | None = None


@router.get("/reviews")
def list_reviews(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(Review).filter(Review.workspace_id == workspace_id).order_by(Review.created_at.desc()).all()


@router.post("/reviews")
def add_review(payload: ReviewCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Review(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.post("/reviews/{review_id}/analyze")
@limiter.limit("30/hour")
def analyze_review(request: Request, review_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """AI sentiment + a draft response — the business always sends it themselves (spec section 62 principle)."""
    get_workspace_or_403(workspace_id, db, user)
    review = db.query(Review).filter(Review.id == review_id).first()
    if not review:
        return {"error": "Review not found"}

    result = generate_json(
        system="You are a reputation-management assistant. Classify sentiment honestly, including for "
               "mixed or lukewarm reviews — don't round a neutral review up to positive.",
        user_prompt=f'Review ({review.rating}/5 stars): "{review.text or "(no text)"}"\n'
                    'Return JSON: {"sentiment":"positive|neutral|negative"}',
    )
    response_draft = generate(
        system="Write a short, genuine, non-generic owner response to this customer review. "
               "For negative reviews: acknowledge specifically, no generic apology template, offer to make it right offline.",
        user_prompt=f'Review ({review.rating}/5): "{review.text or "(no text)"}" — by {review.reviewer_name or "a customer"}',
        max_tokens=300,
    )
    review.sentiment = result["sentiment"]
    review.ai_suggested_response = response_draft
    db.commit()
    db.refresh(review)
    return review


@router.get("/summary")
def reputation_summary(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 12 — trend view: average rating, sentiment split, recent negative spike detection."""
    get_workspace_or_403(workspace_id, db, user)
    reviews = db.query(Review).filter(Review.workspace_id == workspace_id).all()
    if not reviews:
        return {"total": 0, "average_rating": None, "sentiment_breakdown": {}}

    avg = sum(r.rating for r in reviews) / len(reviews)
    breakdown = {"positive": 0, "neutral": 0, "negative": 0, "unanalyzed": 0}
    for r in reviews:
        breakdown[r.sentiment or "unanalyzed"] += 1
    return {"total": len(reviews), "average_rating": round(avg, 2), "sentiment_breakdown": breakdown}
