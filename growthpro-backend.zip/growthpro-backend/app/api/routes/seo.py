import uuid
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.seo import KeywordSet, SEOAudit
from app.services.ai_service import generate_json
from app.services import dataforseo_service

router = APIRouter(prefix="/api/seo", tags=["seo"])


def _attach_real_volume(keyword_groups: dict, location_code: int) -> dict:
    """
    Replaces the AI's qualitative "high/medium/low" volume guess with real
    DataForSEO numbers wherever a DataForSEO account is configured. Falls
    back silently to the AI estimate if DATAFORSEO_LOGIN isn't set or the
    call fails — so this never breaks keyword research, it only upgrades it.
    """
    all_keywords = []
    for bucket in ("primary", "long_tail", "questions", "local"):
        all_keywords += [item["keyword"] for item in keyword_groups.get(bucket, [])]
    if not all_keywords:
        return keyword_groups

    try:
        real_data = dataforseo_service.get_search_volume(all_keywords[:100], location_code=location_code)
        volume_by_keyword = {row["keyword"].lower(): row for row in real_data}
    except Exception:
        return keyword_groups  # no DataForSEO configured, or the call failed — AI estimates stand

    for bucket in ("primary", "long_tail", "questions", "local"):
        for item in keyword_groups.get(bucket, []):
            real = volume_by_keyword.get(item["keyword"].lower())
            if real:
                item["search_volume"] = real["search_volume"]
                item["cpc"] = real["cpc"]
                item["data_source"] = "dataforseo"
            else:
                item["data_source"] = "ai_estimate"
    return keyword_groups


class KeywordResearchRequest(BaseModel):
    workspace_id: uuid.UUID
    seed_topic: str
    location: str | None = None
    location_code: int = 2784  # DataForSEO location code; 2784 = UAE. See their /locations endpoint for others.


@router.post("/keywords")
@limiter.limit("20/hour")
def keyword_research(request: Request, payload: KeywordResearchRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    data = generate_json(
        system="You are an SEO keyword research analyst. Estimate volume/competition qualitatively — never fabricate precise numbers, real numbers may be attached separately from a live data source.",
        user_prompt=f'Seed topic: "{payload.seed_topic}"\nLocation: {payload.location or "n/a"}\n'
                    'Return JSON: {"primary":[...],"long_tail":[...],"questions":[...],"local":[...],"clusters":[...]}',
    )
    data = _attach_real_volume(data, payload.location_code)
    row = KeywordSet(workspace_id=payload.workspace_id, seed_topic=payload.seed_topic, location=payload.location, data=data)
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


class AuditRequest(BaseModel):
    workspace_id: uuid.UUID
    website_id: uuid.UUID
    page_content: str
    target_keyword: str | None = None


@router.post("/audit")
@limiter.limit("20/hour")
def run_audit(request: Request, payload: AuditRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    result = generate_json(
        system="You are a technical + on-page SEO auditor working only from the given page content. Return only valid JSON.",
        user_prompt=f'Target keyword: {payload.target_keyword or "n/a"}\nPage content:\n"""{payload.page_content[:6000]}"""\n'
                    'Return JSON: {"score":{"onpage":0-100,"content":0-100,"keyword_usage":0-100,"overall":0-100},'
                    '"issues":[{"problem":"","why_it_matters":"","priority":"High|Medium|Low","fix":""}]}',
    )
    row = SEOAudit(
        website_id=payload.website_id,
        score_overall=result["score"]["overall"],
        score_breakdown=result["score"],
        issues=result["issues"],
    )
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/backlinks/domain-summary")
@limiter.limit("30/hour")
def domain_backlink_summary(request: Request, target_domain: str, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Real referring-domains count + DataForSEO domain rank for any domain (yours or a competitor's)."""
    get_workspace_or_403(workspace_id, db, user)
    return dataforseo_service.get_backlink_summary(target_domain)
