"""
GrowthPro Pixel — public ingest endpoint (no auth, called from any website
that installs the snippet) + authenticated read endpoints for the
dashboard. Consent matters here: the pixel snippet given to customers
includes a comment reminding them to get cookie consent per their
jurisdiction (spec section 35: "Track with appropriate consent").
"""
import uuid
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, Request
from fastapi.responses import Response
from pydantic import BaseModel
from sqlalchemy.orm import Session
from sqlalchemy import func

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.tracking import TrackingEvent

router = APIRouter(tags=["tracking"])

# 1x1 transparent GIF — the actual pixel image returned to the browser
PIXEL_GIF = bytes.fromhex("47494638396101000100800000000000ffffff21f90401000000002c00000000010001000002024401003b")


class TrackEventPayload(BaseModel):
    workspace_id: uuid.UUID
    event_type: str  # page_view | custom | conversion
    event_name: str | None = None
    page_url: str | None = None
    referrer: str | None = None
    utm_source: str | None = None
    utm_medium: str | None = None
    utm_campaign: str | None = None
    visitor_id: str | None = None
    value: str | None = None


@router.post("/api/public/track")
@limiter.limit("300/minute")  # public + high-volume by design (every page view on every customer site)
def track_event(request: Request, payload: TrackEventPayload, db: Session = Depends(get_db)):
    db.add(TrackingEvent(**payload.model_dump()))
    db.commit()
    return {"tracked": True}


@router.get("/api/public/pixel.gif")
@limiter.limit("300/minute")
def pixel_gif(
    request: Request,
    workspace_id: uuid.UUID,
    event_type: str = "page_view",
    event_name: str | None = None,
    page_url: str | None = None,
    utm_source: str | None = None,
    utm_medium: str | None = None,
    utm_campaign: str | None = None,
    visitor_id: str | None = None,
    db: Session = Depends(get_db),
):
    """Fallback for environments that block fetch/XHR — a plain <img> tag works everywhere."""
    db.add(TrackingEvent(
        workspace_id=workspace_id, event_type=event_type, event_name=event_name, page_url=page_url,
        utm_source=utm_source, utm_medium=utm_medium, utm_campaign=utm_campaign, visitor_id=visitor_id,
    ))
    db.commit()
    return Response(content=PIXEL_GIF, media_type="image/gif")


@router.get("/api/tracking/snippet")
def get_snippet(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Returns the ready-to-paste JS snippet for this workspace, with the workspace_id baked in."""
    get_workspace_or_403(workspace_id, db, user)
    snippet = f"""<!-- GrowthPro Pixel — paste before </head>. Get visitor consent per your jurisdiction before enabling. -->
<script>
(function() {{
  var WORKSPACE_ID = "{workspace_id}";
  var API_BASE = "{{{{YOUR_GROWTHPRO_API_URL}}}}"; // replace with your deployed backend URL
  function getVisitorId() {{
    var id = localStorage.getItem('_gp_vid');
    if (!id) {{ id = 'v_' + Math.random().toString(36).slice(2) + Date.now(); localStorage.setItem('_gp_vid', id); }}
    return id;
  }}
  function track(eventType, eventName, value) {{
    var params = new URLSearchParams(window.location.search);
    fetch(API_BASE + '/api/public/track', {{
      method: 'POST', headers: {{'Content-Type': 'application/json'}},
      body: JSON.stringify({{
        workspace_id: WORKSPACE_ID, event_type: eventType, event_name: eventName,
        page_url: window.location.href, referrer: document.referrer,
        utm_source: params.get('utm_source'), utm_medium: params.get('utm_medium'), utm_campaign: params.get('utm_campaign'),
        visitor_id: getVisitorId(), value: value
      }})
    }}).catch(function(){{}});
  }}
  track('page_view');
  window.growthpro_track = track; // call growthpro_track('conversion', 'purchase', '99.00') from your checkout success page
}})();
</script>"""
    return {"snippet": snippet}


@router.get("/api/tracking/summary")
def tracking_summary(workspace_id: uuid.UUID, days: int = 30, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    since = datetime.now(timezone.utc) - timedelta(days=days)

    events = db.query(TrackingEvent).filter(TrackingEvent.workspace_id == workspace_id, TrackingEvent.created_at >= since)
    page_views = events.filter(TrackingEvent.event_type == "page_view").count()
    conversions = events.filter(TrackingEvent.event_type == "conversion").count()
    unique_visitors = db.query(func.count(func.distinct(TrackingEvent.visitor_id))).filter(
        TrackingEvent.workspace_id == workspace_id, TrackingEvent.created_at >= since, TrackingEvent.visitor_id.isnot(None)
    ).scalar()

    by_source = (
        db.query(TrackingEvent.utm_source, func.count(TrackingEvent.id))
        .filter(TrackingEvent.workspace_id == workspace_id, TrackingEvent.created_at >= since, TrackingEvent.utm_source.isnot(None))
        .group_by(TrackingEvent.utm_source).all()
    )

    return {
        "page_views": page_views, "unique_visitors": unique_visitors, "conversions": conversions,
        "conversion_rate_percent": round(conversions / page_views * 100, 2) if page_views else None,
        "traffic_by_source": [{"source": s, "visits": c} for s, c in by_source],
    }
