"""CRM: Leads, Contacts, Deals/Pipeline, Tasks (spec sections 36-40) + AI lead scoring (section 37)."""
import uuid
from datetime import datetime
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.crm import Contact, Lead, Deal, CrmTask, LeadStatus, LeadTemperature
from app.services.ai_service import generate_json
from app.services.automation_service import fire_trigger
from app.services.notification_service import notify
from app.services.webhook_service import dispatch_event
from app.models.workspace import Workspace as WorkspaceModel
from app.models.automation import WorkflowTrigger

router = APIRouter(prefix="/api/crm", tags=["crm"])


# ---- Leads ----
class LeadCreate(BaseModel):
    workspace_id: uuid.UUID
    name: str
    email: str | None = None
    phone: str | None = None
    source: str = "manual"
    campaign: str | None = None
    product_interest: str | None = None
    estimated_value: int | None = None
    notes: str | None = None


@router.get("/leads")
def list_leads(workspace_id: uuid.UUID, status: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    q = db.query(Lead).filter(Lead.workspace_id == workspace_id)
    if status:
        q = q.filter(Lead.status == status)
    return q.order_by(Lead.created_at.desc()).all()


@router.post("/leads")
def create_lead(payload: LeadCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Lead(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    fire_trigger(db, payload.workspace_id, WorkflowTrigger.lead_created, {"lead_id": str(row.id), "source": row.source})
    return row


@router.post("/leads/{lead_id}/status")
def update_lead_status(lead_id: uuid.UUID, workspace_id: uuid.UUID, status: LeadStatus, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if lead:
        lead.status = status
        db.commit()
        fire_trigger(db, workspace_id, WorkflowTrigger.lead_status_changed, {"lead_id": str(lead.id), "status": status.value})
    return lead


@router.post("/leads/{lead_id}/score")
@limiter.limit("30/hour")
def score_lead(request: Request, lead_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 37 — AI lead scoring with a plain-language reason, not just a label."""
    get_workspace_or_403(workspace_id, db, user)
    lead = db.query(Lead).filter(Lead.id == lead_id).first()
    if not lead:
        return {"error": "Lead not found"}

    result = generate_json(
        system="You are a sales lead-scoring assistant. Classify temperature based ONLY on the fields given "
               "— never invent website visit history or behavior data that wasn't provided.",
        user_prompt=f"Lead: name={lead.name}, source={lead.source}, campaign={lead.campaign}, "
                    f"product_interest={lead.product_interest}, estimated_value={lead.estimated_value}, notes={lead.notes}\n"
                    'Return JSON: {"temperature":"hot|warm|cold","reason":"1-2 sentence plain-language explanation"}',
    )
    lead.temperature = result["temperature"]
    lead.temperature_reason = result["reason"]
    db.commit()
    db.refresh(lead)
    if lead.temperature == "hot":
        notify(db, user.id, workspace_id, "hot_lead", f"Hot lead: {lead.name}", lead.temperature_reason)
    return lead


# ---- Contacts ----
class ContactCreate(BaseModel):
    workspace_id: uuid.UUID
    name: str
    email: str | None = None
    phone: str | None = None
    company_name: str | None = None
    notes: str | None = None


@router.get("/contacts")
def list_contacts(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(Contact).filter(Contact.workspace_id == workspace_id).order_by(Contact.created_at.desc()).all()


@router.post("/contacts")
def create_contact(payload: ContactCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Contact(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


# ---- Deals / Pipeline ----
class DealCreate(BaseModel):
    workspace_id: uuid.UUID
    title: str
    contact_id: uuid.UUID | None = None
    lead_id: uuid.UUID | None = None
    value: int | None = None
    probability_percent: int = 50
    source: str | None = None
    campaign: str | None = None


@router.get("/deals")
def list_deals(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Returns every deal — group by `stage` client-side for the kanban pipeline view (section 39)."""
    get_workspace_or_403(workspace_id, db, user)
    return db.query(Deal).filter(Deal.workspace_id == workspace_id).order_by(Deal.created_at.desc()).all()


@router.post("/deals")
def create_deal(payload: DealCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Deal(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.post("/deals/{deal_id}/stage")
def move_deal_stage(deal_id: uuid.UUID, workspace_id: uuid.UUID, stage: LeadStatus, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    deal = db.query(Deal).filter(Deal.id == deal_id).first()
    if deal:
        deal.stage = stage
        if stage in (LeadStatus.won, LeadStatus.lost):
            deal.closed_at = datetime.utcnow()
            db.commit()
            trigger = WorkflowTrigger.deal_won if stage == LeadStatus.won else WorkflowTrigger.deal_lost
            fire_trigger(db, workspace_id, trigger, {"deal_id": str(deal.id), "value": deal.value})
            if stage == LeadStatus.won:
                notify(db, user.id, workspace_id, "payment", f"Deal won: {deal.title}", f"Value: {deal.value}")
                org_id = db.query(WorkspaceModel.organization_id).filter(WorkspaceModel.id == workspace_id).scalar()
                dispatch_event(db, org_id, "deal.won", {"deal_id": str(deal.id), "title": deal.title, "value": deal.value})
        else:
            db.commit()
    return deal


# ---- Tasks ----
class TaskCreate(BaseModel):
    workspace_id: uuid.UUID
    title: str
    lead_id: uuid.UUID | None = None
    deal_id: uuid.UUID | None = None
    due_at: datetime | None = None


@router.get("/tasks")
def list_tasks(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(CrmTask).filter(CrmTask.workspace_id == workspace_id).order_by(CrmTask.due_at).all()


@router.post("/tasks")
def create_task(payload: TaskCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = CrmTask(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.post("/tasks/{task_id}/complete")
def complete_task(task_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    task = db.query(CrmTask).filter(CrmTask.id == task_id).first()
    if task:
        task.completed = "done"
        db.commit()
    return task
