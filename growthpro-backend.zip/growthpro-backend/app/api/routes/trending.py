"""
Trending / viral content ideas for ads and organic video (ties Ad Center +
AI Media Studio together). Important honesty boundary: there is no public
API that reports real-time "trending on TikTok/Instagram right now" data —
platforms don't expose that externally. This generates AI-reasoned trend
*hypotheses* from the business's own niche/industry knowledge, explicitly
labeled as such — never presented as live trending-data.
"""
import uuid
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.workspace import Workspace
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/trending", tags=["trending"])


class TrendingIdeasRequest(BaseModel):
    workspace_id: uuid.UUID
    platform: str = "tiktok"  # tiktok | instagram | youtube_shorts


@router.post("/video-ideas")
@limiter.limit("15/hour")
def trending_video_ideas(request: Request, payload: TrendingIdeasRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace: Workspace = get_workspace_or_403(payload.workspace_id, db, user)

    result = generate_json(
        system="You are a short-form video strategist. You do NOT have access to live trending data from any "
               "platform — no such public API exists. Base ideas on durable short-form content patterns "
               "(hooks, formats, pacing) for this industry, not claims about what's trending literally today.",
        user_prompt=f"Business: {workspace.name}, industry: {workspace.industry or workspace.niche}\n"
                    f"Platform: {payload.platform}\n"
                    'Return JSON: {"video_ideas":[{"hook":"","format":"","concept":"","suggested_length_seconds":0}],'
                    '"trending_audio_style_note":"general guidance on audio/music style for this platform, not a specific real trending sound"}',
        max_tokens=1200,
    )
    result["_note"] = "AI-generated content ideas based on general short-form video patterns — not live trending data from any platform (no public API provides that)."
    return result
