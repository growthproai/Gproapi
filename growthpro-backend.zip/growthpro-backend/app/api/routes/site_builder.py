"""
AI Website / Landing Page Builder (spec sections 31-32). Generates a JSON
section tree via AI, stores it, and serves published pages as real HTML at
a public URL — no login needed to view a published page, same as any real
website builder. This is section-based generation (hero/features/CTA/etc),
not a pixel-perfect drag-and-drop canvas — that would be its own large
frontend engineering project (think Webflow/Unbounce-scale), out of scope here.
"""
import re
import uuid
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.workspace import Workspace
from app.models.site_builder import BuiltPage, PageType
from app.services.ai_service import generate_json

router = APIRouter(tags=["site-builder"])


def slugify(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", text.lower()).strip("-")


class GeneratePageRequest(BaseModel):
    workspace_id: uuid.UUID
    page_type: PageType = PageType.landing_page
    goal: str  # e.g. "landing page for our new spring sale" or "homepage for our clinic"
    tone: str = "Professional"


@router.post("/api/site-builder/generate")
@limiter.limit("15/hour")
def generate_page(request: Request, payload: GeneratePageRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace: Workspace = get_workspace_or_403(payload.workspace_id, db, user)

    result = generate_json(
        system="You are an AI website/landing-page copywriter. Generate a section tree for a page builder. "
               "Never fabricate specific claims (awards, customer counts, certifications) the business didn't state.",
        user_prompt=f"Business: {workspace.name}, industry: {workspace.industry or workspace.niche}, "
                    f"products/services: {workspace.products_services}\n"
                    f"Page goal: {payload.goal}\nTone: {payload.tone}\n"
                    'Return JSON: {"title":"","sections":[  '
                    '{"type":"hero","headline":"","subheadline":"","cta_text":""},  '
                    '{"type":"features","heading":"","items":[{"title":"","description":""}]},  '
                    '{"type":"testimonial_placeholder","note":"business should replace with a real testimonial"},  '
                    '{"type":"cta","heading":"","cta_text":""}  ]}',
        max_tokens=1200,
    )

    base_slug = slugify(result["title"])
    slug = base_slug
    i = 1
    while db.query(BuiltPage).filter(BuiltPage.slug == slug).first():
        slug = f"{base_slug}-{i}"
        i += 1

    page = BuiltPage(workspace_id=payload.workspace_id, page_type=payload.page_type, slug=slug, title=result["title"], sections=result["sections"])
    db.add(page)
    db.commit()
    db.refresh(page)
    return page


@router.get("/api/site-builder/pages")
def list_pages(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(BuiltPage).filter(BuiltPage.workspace_id == workspace_id).all()


@router.post("/api/site-builder/pages/{page_id}/publish")
def publish_page(page_id: uuid.UUID, workspace_id: uuid.UUID, publish: bool = True, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    page = db.query(BuiltPage).filter(BuiltPage.id == page_id).first()
    if page:
        page.is_published = publish
        db.commit()
    return page


def _render_section_html(section: dict) -> str:
    t = section.get("type")
    if t == "hero":
        return f'''<section style="padding:80px 24px; text-align:center;">
            <h1 style="font-size:40px; margin-bottom:16px;">{section.get("headline","")}</h1>
            <p style="font-size:18px; color:#555; margin-bottom:24px;">{section.get("subheadline","")}</p>
            <button style="background:#F5A623; border:none; padding:14px 28px; border-radius:8px; font-weight:700; cursor:pointer;">{section.get("cta_text","Get Started")}</button>
        </section>'''
    if t == "features":
        items = "".join(f'<div style="padding:20px;"><h3>{i.get("title","")}</h3><p style="color:#555;">{i.get("description","")}</p></div>' for i in section.get("items", []))
        return f'<section style="padding:60px 24px;"><h2 style="text-align:center; margin-bottom:32px;">{section.get("heading","")}</h2><div style="display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:16px; max-width:900px; margin:0 auto;">{items}</div></section>'
    if t == "cta":
        return f'''<section style="padding:60px 24px; text-align:center; background:#111B2E; color:white;">
            <h2 style="margin-bottom:20px;">{section.get("heading","")}</h2>
            <button style="background:#35D0BA; border:none; padding:14px 28px; border-radius:8px; font-weight:700; cursor:pointer;">{section.get("cta_text","Contact Us")}</button>
        </section>'''
    if t == "testimonial_placeholder":
        return f'<section style="padding:30px 24px; text-align:center; color:#999; font-style:italic;">[{section.get("note","Add a real customer testimonial here")}]</section>'
    return ""


@router.get("/api/public/site/{slug}", response_class=HTMLResponse)
def render_published_page(slug: str, db: Session = Depends(get_db)):
    """Real, public, no-login HTML rendering of a published page — this is the live site/landing page."""
    page = db.query(BuiltPage).filter(BuiltPage.slug == slug, BuiltPage.is_published == True).first()  # noqa: E712
    if not page:
        raise HTTPException(404, "Page not found or not published")

    body = "".join(_render_section_html(s) for s in page.sections)
    return f"""<!DOCTYPE html><html><head><meta charset="utf-8"><title>{page.title}</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>body{{font-family:-apple-system,Inter,sans-serif; margin:0; color:#111;}}</style>
</head><body>{body}</body></html>"""
