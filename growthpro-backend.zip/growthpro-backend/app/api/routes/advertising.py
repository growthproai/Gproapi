"""
Ad Center (spec sections 25-27). Every campaign is created in `draft` /
Meta-`PAUSED` status — nothing spends money until the user explicitly
approves it via /approve. AI generates ad copy suggestions per ad format
(video/photo/lead/carousel/text); the actual platform API calls (Google
Ads, Meta Ads) require developer-token/App Review approval on the platform
side before they'll work (see the service files for exactly what to apply for).
"""
import uuid
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.core.security import decrypt_token
from app.models.user import User
from app.models.workspace import Workspace
from app.models.advertising import AdCampaign, AdPlatform, AdFormat, CampaignStatus
from app.models.meta_account import MetaAccount
from app.services.ai_service import generate_json
from app.services import meta_ads_service

router = APIRouter(prefix="/api/advertising", tags=["advertising"])

FORMAT_PROMPTS = {
    "video_ad": "a video ad script (hook, body, CTA) plus a suggested video length in seconds",
    "photo_ad": "static image ad copy (headline, primary text, CTA) plus an image concept description",
    "lead_ad": "a native lead-generation ad (headline, primary text, CTA) plus 3-4 suggested lead-form questions",
    "carousel_ad": "a 3-4 card carousel ad — each card with its own headline and short text",
    "text_ad": "a Google Search-style text ad: 3 headline variants (<=30 chars each) and 2 description variants (<=90 chars each)",
}


class SmartCampaignRequest(BaseModel):
    """Section 26 — Smart Campaign: business + goal + location + budget -> AI proposal."""
    workspace_id: uuid.UUID
    platform: AdPlatform
    ad_format: AdFormat = AdFormat.photo_ad
    goal: str
    location: str
    daily_budget: int  # smallest currency unit


@router.post("/smart-campaign")
@limiter.limit("10/hour")
def create_smart_campaign(request: Request, payload: SmartCampaignRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace: Workspace = get_workspace_or_403(payload.workspace_id, db, user)
    format_instruction = FORMAT_PROMPTS.get(payload.ad_format.value, FORMAT_PROMPTS["photo_ad"])

    ai_result = generate_json(
        system="You are an ad campaign strategist. Never claim a specific ROAS/CTR/conversion rate as guaranteed. "
               "Generate creative appropriate to the requested ad format specifically.",
        user_prompt=f"Business: {workspace.name}, industry: {workspace.industry or workspace.niche}\n"
                    f"Goal: {payload.goal}\nLocation: {payload.location}\nDaily budget: {payload.daily_budget}\n"
                    f"Ad format: {payload.ad_format.value} — generate {format_instruction}\n"
                    'Return JSON: {"objective":"traffic|leads|sales|awareness|video_views",'
                    '"audience_suggestion":"","ad_copy":[{"headline":"","primary_text":"","cta":"","video_script":"(only if video_ad)",'
                    '"image_concept":"(only if photo_ad/carousel_ad)","lead_form_questions":["(only if lead_ad)"]}],'
                    '"creative_concept":""}',
        max_tokens=1400,
    )

    campaign = AdCampaign(
        workspace_id=payload.workspace_id, platform=payload.platform, ad_format=payload.ad_format, objective=ai_result["objective"],
        daily_budget=payload.daily_budget, ai_generated_copy=ai_result, status=CampaignStatus.draft,
    )
    db.add(campaign)
    db.commit()
    db.refresh(campaign)
    return campaign


@router.get("/campaigns")
def list_campaigns(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(AdCampaign).filter(AdCampaign.workspace_id == workspace_id).all()


@router.post("/campaigns/{campaign_id}/approve")
def approve_campaign(campaign_id: uuid.UUID, workspace_id: uuid.UUID, ad_account_id: str | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """
    The ONLY endpoint that can move a campaign past `draft`. For Meta, this
    actually calls the real Marketing API (still PAUSED on Meta's side —
    launching live spend is a deliberate separate action, not bundled here).
    """
    get_workspace_or_403(workspace_id, db, user)
    campaign = db.query(AdCampaign).filter(AdCampaign.id == campaign_id).first()
    if not campaign:
        raise HTTPException(404, "Campaign not found")

    if campaign.platform == AdPlatform.meta and ad_account_id:
        meta_account = db.query(MetaAccount).filter(MetaAccount.workspace_id == workspace_id).first()
        if not meta_account:
            raise HTTPException(400, "No Meta account connected")
        token = decrypt_token(meta_account.encrypted_long_lived_token)
        copy = campaign.ai_generated_copy.get("ad_copy", [{}])[0]
        result = meta_ads_service.create_campaign(
            ad_account_id, token, name=f"GrowthPro - {campaign.objective} - {campaign.ad_format.value}",
            objective=f"OUTCOME_{campaign.objective.upper()}", daily_budget_cents=campaign.daily_budget or 0,
        )
        campaign.external_campaign_id = result.get("id")

    campaign.status = CampaignStatus.active
    campaign.approved_by_user_id = user.id
    from datetime import datetime, timezone
    campaign.approved_at = datetime.now(timezone.utc)
    db.commit()
    db.refresh(campaign)
    return campaign


@router.post("/campaigns/{campaign_id}/pause")
def pause_campaign(campaign_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    campaign = db.query(AdCampaign).filter(AdCampaign.id == campaign_id).first()
    if campaign:
        campaign.status = CampaignStatus.paused
        db.commit()
    return campaign
