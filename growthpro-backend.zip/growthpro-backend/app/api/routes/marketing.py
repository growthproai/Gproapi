"""AI Marketing Plan generator (spec section 23) — business + market + goal + budget -> full plan."""
import uuid
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.workspace import Workspace
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/marketing", tags=["marketing"])


class MarketingPlanRequest(BaseModel):
    workspace_id: uuid.UUID
    goal: str
    budget: str | None = None
    timeframe: str = "30 days"


@router.post("/plan")
@limiter.limit("10/hour")
def generate_marketing_plan(request: Request, payload: MarketingPlanRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace: Workspace = get_workspace_or_403(payload.workspace_id, db, user)

    result = generate_json(
        system="You are an AI marketing strategist. Never promise guaranteed results, guaranteed rankings, "
               "or guaranteed ROI — frame budget/KPI numbers as planning targets, not promises.",
        user_prompt=f"Business: {workspace.name}, industry: {workspace.industry or workspace.niche}, "
                    f"target market: {workspace.target_market}, country: {workspace.country}\n"
                    f"Goal: {payload.goal}\nBudget: {payload.budget or 'not specified'}\nTimeframe: {payload.timeframe}\n"
                    'Return JSON: {"strategy_summary":"","target_audience":"",'
                    '"recommended_channels":["..."],"content_themes":["..."],"offer_ideas":["..."],'
                    '"suggested_budget_split":[{"channel":"","percent":0}],'
                    '"kpis_to_track":["..."],"timeline":[{"week":"","focus":""}]}',
        max_tokens=1500,
    )
    return result


class OfferRequest(BaseModel):
    workspace_id: uuid.UUID
    context: str | None = None


@router.post("/offers")
@limiter.limit("15/hour")
def generate_offers(request: Request, payload: OfferRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 24 — AI Offer Generator."""
    workspace: Workspace = get_workspace_or_403(payload.workspace_id, db, user)

    result = generate_json(
        system="You are a promotions/offer strategist. Every offer must be realistic for a small/medium "
               "business to actually run — no offers that require infrastructure the business likely doesn't have.",
        user_prompt=f"Business: {workspace.name}, industry: {workspace.industry or workspace.niche}, "
                    f"products/services: {workspace.products_services}\nAdditional context: {payload.context or 'n/a'}\n"
                    'Return JSON: {"offers":[{"type":"discount|bundle|package|coupon|limited_time|lead_magnet|'
                    'free_trial|upsell|cross_sell","description":"","reasoning":""}]}',
    )
    return result
