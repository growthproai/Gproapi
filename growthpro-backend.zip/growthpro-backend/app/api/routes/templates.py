import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.services.business_templates import list_templates, get_template

router = APIRouter(prefix="/api/templates", tags=["templates"])


@router.get("")
def all_templates():
    return list_templates()


@router.post("/{template_key}/apply")
def apply_template(template_key: str, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Applies a template's suggested goal to the workspace — content/KPI suggestions are read-only guidance, not auto-created content."""
    workspace = get_workspace_or_403(workspace_id, db, user)
    template = get_template(template_key)
    if not template:
        raise HTTPException(404, "Template not found")
    workspace.main_goal = template["suggested_main_goal"]
    db.commit()
    return {"applied": True, "template": template}
