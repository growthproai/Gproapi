import uuid
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.backlink import Backlink

router = APIRouter(prefix="/api/backlinks", tags=["backlinks"])


class BacklinkCreate(BaseModel):
    workspace_id: uuid.UUID
    domain: str
    status: str = "not_contacted"
    notes: str | None = None


@router.get("")
def list_backlinks(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(Backlink).filter(Backlink.workspace_id == workspace_id).all()


@router.post("")
def add_backlink(payload: BacklinkCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Backlink(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.delete("/{backlink_id}")
def delete_backlink(backlink_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    db.query(Backlink).filter(Backlink.id == backlink_id).delete()
    db.commit()
    return {"deleted": True}
