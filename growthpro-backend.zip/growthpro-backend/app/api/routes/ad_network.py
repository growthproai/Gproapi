"""
GrowthPro Ad Network (spec section 28) — publisher inventory + a serving/
billing loop that actually debits the advertiser's wallet and credits the
publisher on every impression. The mechanics work. What this build does
NOT include, and what you must not launch without:

  1. Fraud/bot-traffic detection — `ip_hash` is stored as a basic signal,
     but there's no actual bot-scoring, click-fraud, or invalid-traffic
     filtering here. Ad networks lose real money to fraud without this.
  2. Publisher payout compliance — paying out publisher earnings (their
     `Wallet` balance, once withdrawable) likely requires money-transmitter
     licensing or a payment-facilitator partner (e.g. Stripe Connect) in
     most jurisdictions once you're moving third-party funds, not just
     charging your own customers. This is a legal/compliance question for
     wherever you incorporate, not something code can resolve.
  3. Publisher property verification — `Publisher.is_verified` exists but
     there's no automated check that a publisher actually owns the site
     they registered (e.g. a DNS TXT record or meta-tag verification flow).

Treat this as the transaction engine's foundation, not a launch-ready network.
"""
import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.ad_network import AdSlot, NetworkImpression
from app.models.advertising import AdCampaign, CampaignStatus
from app.models.marketplace import Publisher
from app.models.organization import Membership
from app.api.routes.wallet import credit_wallet, debit_wallet, _get_or_create_wallet
from app.models.wallet import TransactionType

router = APIRouter(prefix="/api/ad-network", tags=["ad-network"])


class AdSlotCreate(BaseModel):
    publisher_id: uuid.UUID
    slot_name: str
    width: int | None = None
    height: int | None = None
    floor_price_cpm: int = 0


@router.post("/slots")
def create_ad_slot(payload: AdSlotCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    publisher = db.query(Publisher).filter(Publisher.id == payload.publisher_id, Publisher.user_id == user.id).first()
    if not publisher:
        raise HTTPException(403, "You don't own this publisher property")
    row = AdSlot(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/slots")
def list_my_slots(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    my_publisher_ids = [p.id for p in db.query(Publisher).filter(Publisher.user_id == user.id)]
    return db.query(AdSlot).filter(AdSlot.publisher_id.in_(my_publisher_ids)).all()


@router.post("/serve/{ad_slot_id}")
def serve_ad(ad_slot_id: uuid.UUID, workspace_organization_id: uuid.UUID, db: Session = Depends(get_db)):
    """
    Called by a publisher's page/app at render time (no user auth — this is
    a server-to-server call from the publisher's own backend). Finds the
    highest-paying active campaign, charges the advertiser's wallet, credits
    the publisher, records the impression. No auction/bidding logic yet —
    picks the first eligible active campaign above the slot's floor price.
    """
    slot = db.query(AdSlot).filter(AdSlot.id == ad_slot_id).first()
    if not slot:
        raise HTTPException(404, "Ad slot not found")

    campaign = db.query(AdCampaign).filter(
        AdCampaign.platform == "growthpro_network", AdCampaign.status == CampaignStatus.active,
        AdCampaign.daily_budget >= slot.floor_price_cpm,
    ).first()
    if not campaign:
        return {"served": False, "reason": "No eligible active campaign for this slot right now"}

    cpm = max(slot.floor_price_cpm, 1)
    cost = cpm // 1000 or 1  # per-impression cost from the CPM rate
    platform_commission_percent = 20
    publisher_earning = int(cost * (100 - platform_commission_percent) / 100)

    campaign_workspace = campaign.workspace_id
    from app.models.workspace import Workspace
    advertiser_org_id = db.query(Workspace.organization_id).filter(Workspace.id == campaign_workspace).scalar()

    try:
        debit_wallet(db, advertiser_org_id, cost, TransactionType.ad_spend, f"Ad Network impression on slot {slot.slot_name}")
    except HTTPException:
        return {"served": False, "reason": "Advertiser wallet has insufficient balance"}

    publisher = db.query(Publisher).filter(Publisher.id == slot.publisher_id).first()
    if publisher.user_id:
        publisher_org = db.query(Membership.organization_id).filter(Membership.user_id == publisher.user_id).scalar()
        if publisher_org:
            credit_wallet(db, publisher_org, publisher_earning, TransactionType.ad_spend, f"Ad Network earning: slot {slot.slot_name}")

    db.add(NetworkImpression(ad_slot_id=slot.id, campaign_id=campaign.id, cost_charged=cost, publisher_earning=publisher_earning))
    db.commit()

    return {"served": True, "campaign_id": str(campaign.id), "ad_copy": campaign.ai_generated_copy}


@router.get("/publishers/{publisher_id}/earnings")
def publisher_earnings(publisher_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    publisher = db.query(Publisher).filter(Publisher.id == publisher_id, Publisher.user_id == user.id).first()
    if not publisher:
        raise HTTPException(403, "Not your publisher property")
    slot_ids = [s.id for s in db.query(AdSlot).filter(AdSlot.publisher_id == publisher_id)]
    impressions = db.query(NetworkImpression).filter(NetworkImpression.ad_slot_id.in_(slot_ids)).all()
    return {
        "total_impressions": len(impressions),
        "total_clicks": sum(i.was_clicked for i in impressions),
        "total_earnings": sum(i.publisher_earning for i in impressions),
    }
