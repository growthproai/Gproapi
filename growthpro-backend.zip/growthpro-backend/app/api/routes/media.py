"""Video/photo upload endpoint — the real file-upload flow the campaign wizard was missing."""
import uuid
from fastapi import APIRouter, Depends, UploadFile, File, Form, HTTPException, Request
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.media_asset import MediaAsset
from app.services import storage_service

router = APIRouter(prefix="/api/media", tags=["media"])

MAX_SIZE_BYTES = 200 * 1024 * 1024  # 200MB — generous for short-form video, adjust per your storage budget
ALLOWED_TYPES = {"video/mp4", "video/quicktime", "video/webm", "image/jpeg", "image/png", "image/webp"}


@router.post("/upload")
@limiter.limit("30/hour")
async def upload_media(
    request: Request,
    workspace_id: uuid.UUID = Form(...),
    file: UploadFile = File(...),
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    get_workspace_or_403(workspace_id, db, user)

    if file.content_type not in ALLOWED_TYPES:
        raise HTTPException(400, f"Unsupported file type: {file.content_type}. Allowed: {ALLOWED_TYPES}")

    file_bytes = await file.read()
    if len(file_bytes) > MAX_SIZE_BYTES:
        raise HTTPException(400, f"File too large ({len(file_bytes)} bytes) — max {MAX_SIZE_BYTES} bytes")

    try:
        result = storage_service.upload_file(file_bytes, file.filename, file.content_type, str(workspace_id))
    except Exception as e:
        raise HTTPException(500, f"Storage upload failed — check S3_* settings in .env: {e}")

    asset = MediaAsset(
        workspace_id=workspace_id, filename=file.filename, content_type=file.content_type,
        size_bytes=result["size_bytes"], storage_key=result["storage_key"], public_url=result["public_url"],
        uploaded_by_user_id=user.id,
    )
    db.add(asset)
    db.commit()
    db.refresh(asset)
    return asset


@router.get("")
def list_media(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(MediaAsset).filter(MediaAsset.workspace_id == workspace_id).order_by(MediaAsset.created_at.desc()).all()


@router.delete("/{asset_id}")
def delete_media(asset_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    asset = db.query(MediaAsset).filter(MediaAsset.id == asset_id).first()
    if not asset:
        raise HTTPException(404, "Not found")
    try:
        storage_service.delete_file(asset.storage_key)
    except Exception:
        pass  # storage delete failing shouldn't block removing the DB record
    db.delete(asset)
    db.commit()
    return {"deleted": True}
