import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.core.security import decrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.tiktok_account import TikTokAccount
from app.services import tiktok_service

router = APIRouter(prefix="/api/tiktok", tags=["tiktok"])


def _get_account(workspace_id: uuid.UUID, db: Session) -> TikTokAccount:
    account = db.query(TikTokAccount).filter(TikTokAccount.workspace_id == workspace_id).first()
    if not account:
        raise HTTPException(404, "No TikTok account connected for this workspace.")
    return account


@router.get("/videos")
def videos(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    account = _get_account(workspace_id, db)
    token = decrypt_token(account.encrypted_access_token)
    return tiktok_service.list_videos(token)


class DraftRequest(BaseModel):
    workspace_id: uuid.UUID
    video_url: str
    title: str


@router.post("/videos/draft")
def create_draft(payload: DraftRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """User-approved draft upload only — never auto-publishes (spec section 62, 64)."""
    get_workspace_or_403(payload.workspace_id, db, user)
    account = _get_account(payload.workspace_id, db)
    token = decrypt_token(account.encrypted_access_token)
    return tiktok_service.upload_video_as_draft(token, payload.video_url, payload.title)
