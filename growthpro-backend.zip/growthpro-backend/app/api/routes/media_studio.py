"""
AI Media Studio (spec sections 29-30). Important honesty boundary: this
build does NOT actually resize/transcode/compress images or video (that
needs ffmpeg + real media processing infrastructure — a meaningfully large
addition on top of everything else here). What it DOES do for real: AI
analysis and generation of alt text, captions, subtitles-as-text, thumbnail
concepts, and short-clip timestamp suggestions from a transcript — all
text-generation tasks the AI service already handles well.
"""
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
import uuid

from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.db.database import get_db
from sqlalchemy.orm import Session
from app.models.user import User
from app.services.ai_service import generate_json, generate

router = APIRouter(prefix="/api/media-studio", tags=["media-studio"])


class AltTextRequest(BaseModel):
    workspace_id: uuid.UUID
    image_description: str  # what's in the image, described by the user — no actual image analysis in this build
    context: str | None = None  # e.g. the page/post it's going on


@router.post("/alt-text")
@limiter.limit("30/hour")
def generate_alt_text(request: Request, payload: AltTextRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    text = generate(
        system="Write concise, descriptive, SEO-friendly alt text (under 125 characters). No 'image of' prefix.",
        user_prompt=f"Image shows: {payload.image_description}\nContext: {payload.context or 'n/a'}",
        max_tokens=100,
    )
    return {"alt_text": text.strip()}


class ThumbnailConceptRequest(BaseModel):
    workspace_id: uuid.UUID
    video_topic: str
    platform: str = "YouTube"


@router.post("/thumbnail-concept")
@limiter.limit("20/hour")
def thumbnail_concept(request: Request, payload: ThumbnailConceptRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 24 — concepts/text/layout suggestions, not an actual generated image."""
    get_workspace_or_403(payload.workspace_id, db, user)
    result = generate_json(
        system="You are a thumbnail design strategist. Describe a concept — you don't generate the actual image.",
        user_prompt=f"Video topic: {payload.video_topic}\nPlatform: {payload.platform}\n"
                    'Return JSON: {"concept":"","overlay_text_options":["","",""],"layout_suggestion":"",'
                    '"color_direction":"","emotional_focus":""}',
    )
    return result


class VideoRepurposeRequest(BaseModel):
    workspace_id: uuid.UUID
    transcript: str  # user pastes the transcript — no actual video/audio processing in this build


@router.post("/video-repurpose")
@limiter.limit("15/hour")
def video_repurpose(request: Request, payload: VideoRepurposeRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 30 — suggests short-clip timestamps + captions from a transcript, doesn't cut actual video."""
    get_workspace_or_403(payload.workspace_id, db, user)
    result = generate_json(
        system="You are a short-form video editor's assistant, working from a transcript with no timestamps unless "
               "given — so 'timestamp' suggestions should be phrased as which section of the transcript, not exact seconds, "
               "unless the transcript itself includes timing.",
        user_prompt=f'Transcript:\n"""{payload.transcript[:6000]}"""\n'
                    'Return JSON: {"suggested_clips":[{"transcript_excerpt":"","reason_its_a_good_clip":"",'
                    '"suggested_caption":"","suggested_hashtags":["..."]}],"overall_summary":""}',
        max_tokens=1500,
    )
    return result


class ViralityCheckRequest(BaseModel):
    workspace_id: uuid.UUID
    platform: str  # youtube | instagram | tiktok | facebook
    caption_or_title: str
    hashtags: list[str] = []
    has_hook_in_first_3s: bool = False
    video_length_seconds: int | None = None


@router.post("/virality-check")
@limiter.limit("30/hour")
def virality_check(request: Request, payload: ViralityCheckRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """
    Scores content against KNOWN, PUBLIC best-practice signals that
    correlate with reach on each platform (hook strength, caption length,
    hashtag relevance, CTA presence, ideal length range). This is NOT a
    prediction of virality and NEVER promises trending/going viral — no
    legitimate tool can promise that, since ranking algorithms are private
    and engagement-manipulation (bots, engagement pods, fake views) violates
    every platform's Terms of Service and this platform's own no-fake-
    engagement principle. This only improves the odds through real practices.
    """
    get_workspace_or_403(payload.workspace_id, db, user)
    result = generate_json(
        system="You are a social media content strategist scoring against PUBLICLY KNOWN best practices only "
               "(hook strength, caption length/readability, hashtag relevance and count, clear CTA, ideal length "
               "for the platform). NEVER claim this predicts virality or trending — frame everything as 'improves "
               "the odds of reach', never a guarantee. Do not suggest bots, engagement pods, purchased "
               "engagement, or any manipulation tactic — these violate platform ToS.",
        user_prompt=f"Platform: {payload.platform}\nCaption/title: {payload.caption_or_title}\n"
                    f"Hashtags: {payload.hashtags}\nHas a hook in the first 3 seconds: {payload.has_hook_in_first_3s}\n"
                    f"Video length: {payload.video_length_seconds or 'n/a'} seconds\n"
                    'Return JSON: {"best_practice_score":0-100,"strengths":["..."],"improvements":["..."],'
                    '"hashtag_feedback":"","length_feedback":""}',
    )
    result["_disclaimer"] = "Scores real best-practice signals only — never predicts or guarantees virality/trending. No legitimate tool can promise that; be skeptical of any that do."
    return result
