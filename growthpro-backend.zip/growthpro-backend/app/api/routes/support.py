"""Support Center (spec section 57) — tickets with an AI first-response, human escalation available."""
import uuid
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, require_platform_admin
from app.core.limiter import limiter
from app.models.user import User
from app.models.support import SupportTicket, TicketMessage, TicketStatus
from app.services.ai_service import generate

router = APIRouter(prefix="/api/support", tags=["support"])

# A small, honest knowledge base — the AI only answers from this, so it can't
# invent details about features that don't exist (spec section 57: "AI should
# answer common questions and escalate complex issues" — escalation is the
# default for anything not covered here).
KNOWLEDGE_BASE = """
- GrowthPro connects Google Search Console, YouTube, Facebook, Instagram, and TikTok via OAuth (Settings > Integrations).
- SEO keyword volume and rank checks use real data when DataForSEO is configured; otherwise they're AI estimates, clearly labeled.
- Ad campaigns always start as drafts and never spend money until explicitly approved.
- Billing is handled via Stripe; ad spend is charged directly to the business's own connected ad account, not through GrowthPro.
- The Growth Score is GrowthPro's own metric, never an official Google/Meta ranking.
"""


class TicketCreate(BaseModel):
    subject: str
    message: str
    organization_id: uuid.UUID | None = None


@router.post("")
@limiter.limit("10/hour")
def create_ticket(request: Request, payload: TicketCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ticket = SupportTicket(user_id=user.id, organization_id=payload.organization_id, subject=payload.subject)
    db.add(ticket)
    db.flush()
    db.add(TicketMessage(ticket_id=ticket.id, author_user_id=user.id, body=payload.message))
    db.commit()

    # AI first-response — grounded only in the knowledge base above, escalates anything else.
    ai_reply = generate(
        system=f"You are GrowthPro's support assistant. Answer ONLY using this knowledge base:\n{KNOWLEDGE_BASE}\n"
               "If the question isn't covered, say clearly that this needs a human team member and that "
               "the ticket has been escalated — never guess or make up an answer.",
        user_prompt=f"Subject: {payload.subject}\nMessage: {payload.message}",
        max_tokens=400,
    )
    db.add(TicketMessage(ticket_id=ticket.id, author_user_id=None, is_ai_reply="true", body=ai_reply))
    db.commit()
    db.refresh(ticket)
    return ticket


@router.get("")
def list_my_tickets(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    return db.query(SupportTicket).filter(SupportTicket.user_id == user.id).order_by(SupportTicket.created_at.desc()).all()


@router.get("/{ticket_id}/messages")
def get_ticket_messages(ticket_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
    if not ticket or (ticket.user_id != user.id and not user.is_platform_admin):
        raise HTTPException(403, "Not authorized")
    return db.query(TicketMessage).filter(TicketMessage.ticket_id == ticket_id).order_by(TicketMessage.created_at).all()


class ReplyCreate(BaseModel):
    body: str


@router.post("/{ticket_id}/reply")
def reply_to_ticket(ticket_id: uuid.UUID, payload: ReplyCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
    if not ticket or (ticket.user_id != user.id and not user.is_platform_admin):
        raise HTTPException(403, "Not authorized")
    db.add(TicketMessage(ticket_id=ticket_id, author_user_id=user.id, body=payload.body))
    if user.is_platform_admin:
        ticket.status = TicketStatus.in_progress
    db.commit()
    return {"replied": True}


@router.get("/admin/all")
def list_all_tickets(db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    return db.query(SupportTicket).order_by(SupportTicket.created_at.desc()).all()


@router.post("/{ticket_id}/status")
def update_status(ticket_id: uuid.UUID, status: TicketStatus, db: Session = Depends(get_db), _: User = Depends(require_platform_admin)):
    ticket = db.query(SupportTicket).filter(SupportTicket.id == ticket_id).first()
    if ticket:
        ticket.status = status
        db.commit()
    return ticket
