import uuid
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from itsdangerous import URLSafeSerializer, BadSignature

from app.db.database import get_db
from app.core.config import settings
from app.core.security import encrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.tiktok_account import TikTokAccount
from app.models.audit_log import AuditLog
from app.services import tiktok_oauth_service, tiktok_service

router = APIRouter(prefix="/api/tiktok", tags=["tiktok-oauth"])
_signer = URLSafeSerializer(settings.SECRET_KEY, salt="tiktok-oauth-state")


@router.get("/oauth/authorize")
def authorize(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    state = _signer.dumps({"workspace_id": str(workspace_id)})
    return RedirectResponse(tiktok_oauth_service.build_authorization_url(state))


@router.get("/oauth/callback")
def callback(code: str, state: str, db: Session = Depends(get_db)):
    try:
        payload = _signer.loads(state)
    except BadSignature:
        raise HTTPException(400, "Invalid OAuth state")
    workspace_id = uuid.UUID(payload["workspace_id"])

    tokens = tiktok_oauth_service.exchange_code_for_tokens(code)
    user_info = tiktok_service.get_user_info(tokens["access_token"])

    account = TikTokAccount(
        workspace_id=workspace_id,
        open_id=tokens["open_id"],
        display_name=user_info.get("display_name"),
        encrypted_access_token=encrypt_token(tokens["access_token"]),
        encrypted_refresh_token=encrypt_token(tokens["refresh_token"]),
        scopes=tiktok_oauth_service.SCOPES,
    )
    db.add(account)
    db.add(AuditLog(action="tiktok_account_connected", meta={"workspace_id": str(workspace_id)}))
    db.commit()

    return RedirectResponse(f"{settings.FRONTEND_URL}/settings/integrations?connected=tiktok")
