import uuid
import secrets
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.organization import Membership
from app.models.notification import WebhookEndpoint, WebhookDelivery

router = APIRouter(prefix="/api/webhooks", tags=["webhooks"])

AVAILABLE_EVENTS = [
    "user.created", "business.created", "website.connected", "lead.created", "lead.updated",
    "deal.created", "deal.won", "campaign.started", "campaign.completed", "conversion.created",
    "payment.completed", "subscription.updated",
]


class WebhookCreate(BaseModel):
    organization_id: uuid.UUID
    url: str
    events: list[str]


@router.get("/events")
def list_available_events():
    return AVAILABLE_EVENTS


@router.post("")
def register_webhook(payload: WebhookCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if not db.query(Membership).filter(Membership.user_id == user.id, Membership.organization_id == payload.organization_id).first():
        raise HTTPException(403, "Not a member of this organization")
    invalid = set(payload.events) - set(AVAILABLE_EVENTS)
    if invalid:
        raise HTTPException(400, f"Unknown event(s): {invalid}")

    endpoint = WebhookEndpoint(organization_id=payload.organization_id, url=payload.url, events=payload.events, signing_secret=secrets.token_hex(32))
    db.add(endpoint)
    db.commit()
    db.refresh(endpoint)
    return endpoint  # signing_secret is only ever returned here, at creation — store it now


@router.get("")
def list_webhooks(organization_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    if not db.query(Membership).filter(Membership.user_id == user.id, Membership.organization_id == organization_id).first():
        raise HTTPException(403, "Not a member of this organization")
    endpoints = db.query(WebhookEndpoint).filter(WebhookEndpoint.organization_id == organization_id).all()
    for e in endpoints:
        e.signing_secret = e.signing_secret[:8] + "..."  # never re-expose the full secret after creation
    return endpoints


@router.get("/{webhook_id}/deliveries")
def webhook_deliveries(webhook_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    endpoint = db.query(WebhookEndpoint).filter(WebhookEndpoint.id == webhook_id).first()
    if not endpoint or not db.query(Membership).filter(Membership.user_id == user.id, Membership.organization_id == endpoint.organization_id).first():
        raise HTTPException(403, "Not authorized")
    return db.query(WebhookDelivery).filter(WebhookDelivery.webhook_endpoint_id == webhook_id).order_by(WebhookDelivery.attempted_at.desc()).limit(50).all()
