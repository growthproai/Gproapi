"""
AI Business Chat / "Ask GrowthPro" (spec section 48-49). Pulls real
workspace context (business profile + CRM stats + latest SEO audit) into
every answer instead of a generic chatbot with no memory of the business.
Stateless per-call for now — a full conversation history table would be
the natural next step once this proves useful.
"""
import uuid
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.workspace import Workspace
from app.models.crm import Lead, Deal, LeadStatus
from app.models.seo import SEOAudit
from app.models.website import Website
from app.services.ai_service import generate

router = APIRouter(prefix="/api/ai-chat", tags=["ai-chat"])


def _business_context(db: Session, workspace: Workspace) -> str:
    open_deals = db.query(Deal).filter(Deal.workspace_id == workspace.id, Deal.stage.notin_([LeadStatus.won, LeadStatus.lost])).count()
    hot_leads = db.query(Lead).filter(Lead.workspace_id == workspace.id, Lead.temperature == "hot", Lead.status != LeadStatus.won).count()
    website = db.query(Website).filter(Website.workspace_id == workspace.id).first()
    latest_audit = (
        db.query(SEOAudit).join(Website, SEOAudit.website_id == Website.id)
        .filter(Website.workspace_id == workspace.id).order_by(SEOAudit.created_at.desc()).first()
        if website else None
    )
    return (
        f"Business: {workspace.name}, industry: {workspace.industry or workspace.niche or 'not set'}, "
        f"country: {workspace.country or 'not set'}, main goal: {workspace.main_goal or 'not set'}.\n"
        f"Open deals: {open_deals}. Hot leads awaiting follow-up: {hot_leads}.\n"
        f"Latest SEO score: {latest_audit.score_overall if latest_audit else 'no audit run yet'}."
    )


class ChatRequest(BaseModel):
    workspace_id: uuid.UUID
    message: str


@router.post("/ask")
@limiter.limit("30/hour")
def ask(request: Request, payload: ChatRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace = get_workspace_or_403(payload.workspace_id, db, user)
    context = _business_context(db, workspace)

    answer = generate(
        system="You are GrowthPro's business assistant. Answer using ONLY the real business context given — "
               "if the question needs data you don't have (e.g. traffic numbers when no analytics are connected), "
               "say so plainly and suggest what to connect, rather than guessing a plausible-sounding answer.",
        user_prompt=f"Business context:\n{context}\n\nUser question: {payload.message}",
        max_tokens=800,
    )
    return {"answer": answer}
