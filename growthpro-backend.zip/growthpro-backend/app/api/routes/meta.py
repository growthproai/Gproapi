import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.core.security import decrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.meta_account import MetaAccount
from app.services import meta_graph_service

router = APIRouter(prefix="/api/meta", tags=["meta"])


def _get_account(workspace_id: uuid.UUID, db: Session) -> MetaAccount:
    account = db.query(MetaAccount).filter(MetaAccount.workspace_id == workspace_id).first()
    if not account:
        raise HTTPException(404, "No Facebook/Instagram account connected for this workspace.")
    return account


@router.get("/page/insights")
def page_insights(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    account = _get_account(workspace_id, db)
    token = decrypt_token(account.encrypted_long_lived_token)
    return meta_graph_service.get_page_insights(account.facebook_page_id, token)


@router.get("/page/posts")
def page_posts(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    account = _get_account(workspace_id, db)
    token = decrypt_token(account.encrypted_long_lived_token)
    return meta_graph_service.list_page_posts(account.facebook_page_id, token)


class PublishRequest(BaseModel):
    workspace_id: uuid.UUID
    message: str
    link: str | None = None


class InstagramPublishRequest(BaseModel):
    workspace_id: uuid.UUID
    media_url: str  # from POST /api/media/upload's public_url
    caption: str
    is_video: bool = False


@router.post("/page/publish")
def publish(payload: PublishRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Explicit user-triggered publish — never automatic (spec section 62)."""
    get_workspace_or_403(payload.workspace_id, db, user)
    account = _get_account(payload.workspace_id, db)
    token = decrypt_token(account.encrypted_long_lived_token)
    return meta_graph_service.publish_page_post(account.facebook_page_id, token, payload.message, payload.link)


@router.post("/instagram/publish")
def publish_instagram(payload: InstagramPublishRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Real Instagram photo/Reel publish — explicit user-triggered, never automatic (spec section 62)."""
    get_workspace_or_403(payload.workspace_id, db, user)
    account = _get_account(payload.workspace_id, db)
    if not account.instagram_business_id:
        raise HTTPException(404, "No Instagram professional account linked to this workspace's Page.")
    token = decrypt_token(account.encrypted_long_lived_token)
    return meta_graph_service.publish_instagram_media(account.instagram_business_id, token, payload.media_url, payload.caption, payload.is_video)


@router.get("/instagram/media")
def instagram_media(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    account = _get_account(workspace_id, db)
    if not account.instagram_business_id:
        raise HTTPException(404, "No Instagram professional account linked to this workspace's Page.")
    token = decrypt_token(account.encrypted_long_lived_token)
    return meta_graph_service.get_instagram_media_insights(account.instagram_business_id, token)
