import uuid
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.rank_tracking import RankEntry

router = APIRouter(prefix="/api/rank-tracking", tags=["rank-tracking"])


class RankEntryCreate(BaseModel):
    workspace_id: uuid.UUID
    keyword: str
    search_engine: str = "Google"
    country: str = "Global"
    device: str = "mobile"
    position: int


@router.get("")
def list_entries(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(RankEntry).filter(RankEntry.workspace_id == workspace_id).order_by(RankEntry.checked_at).all()


@router.post("")
def add_entry(payload: RankEntryCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = RankEntry(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row
