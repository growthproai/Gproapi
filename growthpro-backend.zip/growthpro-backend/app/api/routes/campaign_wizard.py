"""
Unified Campaign Wizard (spec sections 20-22, 26, 35-36): one flow that
takes "I want to post X, here, for these people" and handles everything —
platform choice, content generation with SEO/hashtags baked in, audience
targeting, and (only when a budget is given) turning it into a real paid
ad. This mirrors how the platforms themselves work: organic posts are
never targeted by audience — only paid ads are, because that's the only
mechanism these platforms actually offer for reaching a specific
demographic. So `daily_budget` present = paid, targeted ad (draft, needs
approval before spending). `daily_budget` absent = organic content,
untargeted, scheduled or added to your content library.
"""
import uuid
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.workspace import Workspace
from app.models.content import ContentItem
from app.models.scheduled_post import ScheduledPost, PostPlatform, PostStatus
from app.models.advertising import AdCampaign, AdPlatform, AdFormat, CampaignStatus
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/campaign-wizard", tags=["campaign-wizard"])

DESTINATIONS = {
    "facebook": {"kind": "social", "post_platform": "facebook", "ad_platform": "meta"},
    "instagram": {"kind": "social", "post_platform": "instagram", "ad_platform": "meta"},
    "tiktok": {"kind": "social", "post_platform": "tiktok", "ad_platform": "tiktok"},
    "youtube": {"kind": "content_only", "content_type": "youtube"},
    "website": {"kind": "content_only", "content_type": "blog"},
    "blog": {"kind": "content_only", "content_type": "blog"},
}

CONTENT_TYPE_INSTRUCTION = {
    "video": "a video caption/description with a strong hook, plus a suggested on-screen hook line",
    "photo": "an image post caption",
    "article": "a full SEO article/blog post with headings",
}


class CampaignWizardRequest(BaseModel):
    workspace_id: uuid.UUID
    destination: str  # facebook | instagram | tiktok | youtube | website | blog
    content_type: str  # video | photo | article
    topic: str
    language: str = "English"
    # Targeting — only applied when daily_budget is set (paid ads only; platforms don't target organic reach)
    target_country: str | None = None
    target_city: str | None = None
    target_profession: str | None = None
    target_age_min: int | None = None
    target_age_max: int | None = None
    # If set, this becomes a paid, targeted ad (draft, needs /approve). If absent, it's organic content.
    daily_budget: int | None = None
    goal: str | None = None  # required if daily_budget is set — e.g. "leads", "traffic", "sales"
    media_url: str | None = None  # from POST /api/media/upload's public_url — the actual video/photo file


@router.post("/create")
@limiter.limit("15/hour")
def create_from_wizard(request: Request, payload: CampaignWizardRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace: Workspace = get_workspace_or_403(payload.workspace_id, db, user)
    dest = DESTINATIONS.get(payload.destination)
    if not dest:
        return {"error": f"Unknown destination '{payload.destination}'. Choose one of: {list(DESTINATIONS.keys())}"}

    content_instruction = CONTENT_TYPE_INSTRUCTION.get(payload.content_type, CONTENT_TYPE_INSTRUCTION["photo"])
    is_boosted = payload.daily_budget is not None and payload.daily_budget > 0

    # ---- Auto SEO: caption, hashtags, description, meta title — generated together so they're consistent ----
    seo_content = generate_json(
        system="You are an SEO + social copywriter. Generate consistent, platform-appropriate content — "
               "never fabricate statistics or guarantee results. Hashtags must be genuinely relevant, not generic spam.",
        user_prompt=f"Business: {workspace.name}, industry: {workspace.industry or workspace.niche}\n"
                    f"Destination: {payload.destination} ({payload.content_type})\n"
                    f"Topic: {payload.topic}\nLanguage: {payload.language}\n"
                    f"Generate {content_instruction}\n"
                    'Return JSON: {"caption_or_title":"","body_or_description":"","hashtags":["..."],'
                    '"seo_meta_description":"(only meaningful for website/blog)"}',
        max_tokens=1200,
    )

    result: dict = {"seo_content": seo_content, "destination": payload.destination, "is_boosted": is_boosted}

    if dest["kind"] == "content_only":
        # YouTube metadata or website/blog article — goes into the content library,
        # since there's no direct auto-publish path for these in this build yet.
        item = ContentItem(
            workspace_id=payload.workspace_id, content_type=dest["content_type"], topic=payload.topic,
            language=payload.language, output=f"{seo_content['caption_or_title']}\n\n{seo_content['body_or_description']}\n\n"
                                                f"Hashtags: {' '.join('#'+h.lstrip('#') for h in seo_content.get('hashtags', []))}",
        )
        db.add(item)
        db.commit()
        db.refresh(item)
        result["content_item"] = item
        return result

    if is_boosted:
        if not payload.goal:
            return {"error": "goal is required when setting a daily_budget (e.g. 'leads', 'traffic', 'sales')"}
        ad_format = AdFormat.video_ad if payload.content_type == "video" else AdFormat.photo_ad
        campaign = AdCampaign(
            workspace_id=payload.workspace_id, platform=AdPlatform(dest["ad_platform"]), ad_format=ad_format,
            objective=payload.goal, daily_budget=payload.daily_budget, destination="social",
            target_country=payload.target_country, target_city=payload.target_city,
            target_profession=payload.target_profession, target_age_min=payload.target_age_min, target_age_max=payload.target_age_max,
            ai_generated_copy={
                "objective": payload.goal,
                "audience_suggestion": f"{payload.target_profession or 'General audience'} in {payload.target_city or payload.target_country or 'target location'}"
                                        + (f", age {payload.target_age_min}-{payload.target_age_max}" if payload.target_age_min else ""),
                "ad_copy": [{
                    "headline": seo_content["caption_or_title"], "primary_text": seo_content["body_or_description"],
                    "cta": "Learn More", "media_url": payload.media_url,
                }],
            },
            status=CampaignStatus.draft,
        )
        db.add(campaign)
        db.commit()
        db.refresh(campaign)
        result["ad_campaign"] = campaign
        result["_next_step"] = f"Review then POST /api/advertising/campaigns/{campaign.id}/approve to launch — never spends until approved."
        return result

    # Organic, untargeted post — scheduled as a draft for the user to review/schedule/publish.
    caption_with_tags = seo_content["caption_or_title"] + "\n\n" + " ".join("#" + h.lstrip("#") for h in seo_content.get("hashtags", []))
    post = ScheduledPost(
        workspace_id=payload.workspace_id, platform=PostPlatform(dest["post_platform"]),
        message=caption_with_tags, link=payload.media_url,
        scheduled_for=datetime.now(timezone.utc) + timedelta(minutes=5),
        status=PostStatus.draft,
    )
    db.add(post)
    db.commit()
    db.refresh(post)
    result["scheduled_post"] = post
    result["_next_step"] = "This is a draft — set a real scheduled_for time and change status to 'scheduled' when ready (organic posts aren't targeted by audience; only paid ads are)."
    return result
