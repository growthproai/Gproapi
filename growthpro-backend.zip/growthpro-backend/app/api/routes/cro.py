"""A/B Testing + CRO suggestions (spec sections 33-34)."""
import uuid
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.cro import Experiment, ExperimentStatus
from app.services.stats_service import two_proportion_z_test
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/cro", tags=["cro"])


class ExperimentCreate(BaseModel):
    workspace_id: uuid.UUID
    name: str
    element_type: str
    variant_a: dict
    variant_b: dict


@router.post("/experiments")
def create_experiment(payload: ExperimentCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Experiment(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/experiments")
def list_experiments(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(Experiment).filter(Experiment.workspace_id == workspace_id).all()


class RecordEvent(BaseModel):
    workspace_id: uuid.UUID
    variant: str  # "a" or "b"
    event: str    # "visit" or "conversion"


@router.post("/experiments/{experiment_id}/record")
def record_event(experiment_id: uuid.UUID, payload: RecordEvent, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Call this from the tracking pixel / page code whenever a visitor sees a variant or converts."""
    get_workspace_or_403(payload.workspace_id, db, user)
    exp = db.query(Experiment).filter(Experiment.id == experiment_id).first()
    if not exp:
        raise HTTPException(404, "Experiment not found")

    field = f"variant_{payload.variant}_{'visitors' if payload.event == 'visit' else 'conversions'}"
    setattr(exp, field, getattr(exp, field) + 1)
    db.commit()
    return {"recorded": True}


@router.get("/experiments/{experiment_id}/results")
def experiment_results(experiment_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    exp = db.query(Experiment).filter(Experiment.id == experiment_id).first()
    if not exp:
        raise HTTPException(404, "Experiment not found")
    stats = two_proportion_z_test(exp.variant_a_conversions, exp.variant_a_visitors, exp.variant_b_conversions, exp.variant_b_visitors)
    return {"experiment": exp, "stats": stats}


@router.post("/experiments/{experiment_id}/conclude")
def conclude_experiment(experiment_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    exp = db.query(Experiment).filter(Experiment.id == experiment_id).first()
    if exp:
        exp.status = ExperimentStatus.concluded
        db.commit()
    return exp


class CroAnalysisRequest(BaseModel):
    workspace_id: uuid.UUID
    page_content: str


@router.post("/analyze")
@limiter.limit("15/hour")
def cro_analysis(request: Request, payload: CroAnalysisRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Section 33 — CRO suggestions: analyze a page's conversion elements (CTA, trust signals, etc)."""
    get_workspace_or_403(payload.workspace_id, db, user)
    result = generate_json(
        system="You are a conversion-rate-optimization analyst working only from the page content given.",
        user_prompt=f'Page content:\n"""{payload.page_content[:5000]}"""\n'
                    'Return JSON: {"cta_analysis":"","trust_signals_found":["..."],"trust_signals_missing":["..."],'
                    '"suggested_tests":[{"element":"","current":"","test_idea":"","hypothesis":""}]}',
    )
    return result
