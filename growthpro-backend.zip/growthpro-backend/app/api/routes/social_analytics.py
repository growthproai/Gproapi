"""
Unified Social Growth analytics (spec section 19) — pulls real numbers from
whichever platforms are connected (Meta, YouTube already have OAuth wired
up; TikTok has content endpoints but its Analytics API needs a separate
approved scope) and returns one combined view instead of the caller having
to hit three different route groups.
"""
import uuid
from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.core.security import decrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.meta_account import MetaAccount
from app.models.youtube_account import YouTubeAccount
from app.models.tiktok_account import TikTokAccount
from app.services import meta_graph_service, youtube_service, tiktok_service, google_oauth_service

router = APIRouter(prefix="/api/social-analytics", tags=["social-analytics"])


@router.get("/overview")
def social_overview(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """
    One call, one response per connected platform — each with a clear
    `connected: true/false` so the frontend can show "connect this" prompts
    instead of silently omitting a platform that just isn't linked yet.
    """
    get_workspace_or_403(workspace_id, db, user)
    result: dict = {}

    meta = db.query(MetaAccount).filter(MetaAccount.workspace_id == workspace_id).first()
    if meta:
        try:
            token = decrypt_token(meta.encrypted_long_lived_token)
            insights = meta_graph_service.get_page_insights(meta.facebook_page_id, token)
            result["facebook"] = {"connected": True, "page_name": meta.facebook_page_name, "insights": insights}
        except Exception as e:
            result["facebook"] = {"connected": True, "error": str(e)}
        if meta.instagram_business_id:
            try:
                token = decrypt_token(meta.encrypted_long_lived_token)
                media = meta_graph_service.get_instagram_media_insights(meta.instagram_business_id, token)
                result["instagram"] = {"connected": True, "username": meta.instagram_username, "recent_media": media[:10]}
            except Exception as e:
                result["instagram"] = {"connected": True, "error": str(e)}
        else:
            result["instagram"] = {"connected": False}
    else:
        result["facebook"] = {"connected": False}
        result["instagram"] = {"connected": False}

    yt = db.query(YouTubeAccount).filter(YouTubeAccount.workspace_id == workspace_id).first()
    if yt:
        try:
            creds = google_oauth_service.credentials_from_refresh_token(decrypt_token(yt.encrypted_refresh_token))
            channel = youtube_service.get_my_channel(creds)
            stats = channel.get("statistics", {})
            result["youtube"] = {
                "connected": True, "channel_title": yt.channel_title,
                "subscribers": stats.get("subscriberCount"), "total_views": stats.get("viewCount"),
                "video_count": stats.get("videoCount"),
            }
        except Exception as e:
            result["youtube"] = {"connected": True, "error": str(e)}
    else:
        result["youtube"] = {"connected": False}

    tiktok = db.query(TikTokAccount).filter(TikTokAccount.workspace_id == workspace_id).first()
    if tiktok:
        try:
            token = decrypt_token(tiktok.encrypted_access_token)
            videos = tiktok_service.list_videos(token)
            result["tiktok"] = {"connected": True, "display_name": tiktok.display_name, "video_count": len(videos)}
        except Exception as e:
            result["tiktok"] = {"connected": True, "error": str(e)}
    else:
        result["tiktok"] = {"connected": False}

    return result
