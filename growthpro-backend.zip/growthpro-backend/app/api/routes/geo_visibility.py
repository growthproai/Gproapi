"""
AI/GEO Search Intelligence (spec section 18). Asks the AI model a realistic
user query and checks whether/how it mentions the brand — a sampled proxy
for AI visibility, run over time to spot trends. NOT a real measurement of
actual ChatGPT/Perplexity/Google-AI-Overview user traffic (no such API
exists publicly) — every result is labeled as a sampled check, never
presented as verified analytics (spec section 66: Trust Center principle).
"""
import uuid
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.workspace import Workspace
from app.models.geo_visibility import GeoVisibilityCheck
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/geo-visibility", tags=["geo-visibility"])


class GeoCheckRequest(BaseModel):
    workspace_id: uuid.UUID
    query: str  # a realistic query a customer might ask an AI assistant


@router.post("/check")
@limiter.limit("20/hour")
def run_geo_check(request: Request, payload: GeoCheckRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    workspace: Workspace = get_workspace_or_403(payload.workspace_id, db, user)

    result = generate_json(
        system="You are answering as a general AI assistant would to a real user query — answer naturally and "
               "honestly based on your own knowledge, don't try to specifically promote any brand. Then, "
               "separately, report on your own answer.",
        user_prompt=f'A user asks: "{payload.query}"\n'
                    f'First, answer naturally as you normally would.\n'
                    f'Then report: did your answer mention "{workspace.name}"? Did it mention any competitors '
                    f'in the {workspace.industry or workspace.niche or "same"} space?\n'
                    'Return JSON: {"brand_mentioned":"yes|no|indirectly","mention_context":"quote or paraphrase of how, if at all",'
                    '"competitors_mentioned":["..."],"raw_response_excerpt":"first 2-3 sentences of your natural answer"}',
    )

    row = GeoVisibilityCheck(workspace_id=payload.workspace_id, query=payload.query, **result)
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("/history")
def geo_history(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    checks = db.query(GeoVisibilityCheck).filter(GeoVisibilityCheck.workspace_id == workspace_id).order_by(GeoVisibilityCheck.checked_at.desc()).all()
    mentioned = sum(1 for c in checks if c.brand_mentioned == "yes")
    return {
        "checks": checks,
        "visibility_rate_percent": round(mentioned / len(checks) * 100, 1) if checks else None,
        "_note": "Sampled AI-response checks, not verified analytics from any AI provider — treat as directional, not exact.",
    }
