import uuid
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.core.config import settings
from app.api.deps import get_current_user
from app.models.user import User
from app.models.organization import Membership
from app.models.subscription import Plan, Subscription
from app.models.audit_log import AuditLog
from app.services import stripe_service

router = APIRouter(prefix="/api/billing", tags=["billing"])


class CheckoutRequest(BaseModel):
    organization_id: uuid.UUID
    plan_code: str
    stripe_price_id: str  # the Stripe Price ID configured for this plan in the Stripe Dashboard


@router.post("/checkout-session")
def start_checkout(payload: CheckoutRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    membership = db.query(Membership).filter(
        Membership.user_id == user.id, Membership.organization_id == payload.organization_id
    ).first()
    if not membership:
        raise HTTPException(403, "Not a member of this organization")

    customer_id = stripe_service.get_or_create_customer(user.email, str(payload.organization_id))
    session = stripe_service.create_checkout_session(customer_id, payload.stripe_price_id, str(payload.organization_id))
    return {"checkout_url": session.url}


@router.post("/webhook")
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    """
    Stripe calls this directly (no auth header) — trust comes from verifying
    the signature, not from a JWT. Register this URL in the Stripe Dashboard
    webhook settings: checkout.session.completed, customer.subscription.updated,
    customer.subscription.deleted, invoice.payment_failed.
    """
    payload = await request.body()
    sig_header = request.headers.get("stripe-signature", "")
    try:
        event = stripe_service.construct_webhook_event(payload, sig_header)
    except Exception as e:
        raise HTTPException(400, f"Webhook signature verification failed: {e}")

    event_type = event["type"]
    data = event["data"]["object"]

    if event_type == "checkout.session.completed":
        org_id = data["metadata"]["organization_id"]
        sub = db.query(Subscription).filter(Subscription.organization_id == uuid.UUID(org_id)).first()
        if not sub:
            sub = Subscription(organization_id=uuid.UUID(org_id), plan_id=_default_plan_id(db))
            db.add(sub)
        sub.status = "active"
        sub.stripe_customer_id = data.get("customer")
        sub.stripe_subscription_id = data.get("subscription")
        db.add(AuditLog(action="subscription_activated", meta={"organization_id": org_id}))
        db.commit()

    elif event_type == "customer.subscription.deleted":
        sub = db.query(Subscription).filter(Subscription.stripe_subscription_id == data["id"]).first()
        if sub:
            sub.status = "canceled"
            db.commit()

    elif event_type == "invoice.payment_failed":
        sub = db.query(Subscription).filter(Subscription.stripe_customer_id == data.get("customer")).first()
        if sub:
            sub.status = "past_due"
            db.commit()

    return {"received": True}


def _default_plan_id(db: Session):
    plan = db.query(Plan).first()
    return plan.id if plan else None


@router.get("/subscription")
def get_subscription(organization_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    membership = db.query(Membership).filter(
        Membership.user_id == user.id, Membership.organization_id == organization_id
    ).first()
    if not membership:
        raise HTTPException(403, "Not a member of this organization")
    return db.query(Subscription).filter(Subscription.organization_id == organization_id).first()


@router.post("/portal-session")
def portal_session(organization_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """Lets the customer manage/cancel their subscription via Stripe's hosted portal."""
    membership = db.query(Membership).filter(
        Membership.user_id == user.id, Membership.organization_id == organization_id
    ).first()
    if not membership:
        raise HTTPException(403, "Not a member of this organization")
    sub = db.query(Subscription).filter(Subscription.organization_id == organization_id).first()
    if not sub or not sub.stripe_customer_id:
        raise HTTPException(404, "No active Stripe customer for this organization yet")
    session = stripe_service.create_billing_portal_session(sub.stripe_customer_id)
    return {"portal_url": session.url}
