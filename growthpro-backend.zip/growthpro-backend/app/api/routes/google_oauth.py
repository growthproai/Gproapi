import uuid
import httpx
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from itsdangerous import URLSafeSerializer, BadSignature

from app.db.database import get_db
from app.core.config import settings
from app.core.security import encrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.google_account import GoogleAccount
from app.models.youtube_account import YouTubeAccount
from app.models.audit_log import AuditLog
from app.services import google_oauth_service, youtube_service

router = APIRouter(prefix="/api/google", tags=["google-oauth"])
_signer = URLSafeSerializer(settings.SECRET_KEY, salt="google-oauth-state")


def _fetch_google_email(access_token: str) -> str:
    """
    creds.id_token from the OAuth flow is a raw JWT string, not decoded
    claims — the reliable way to get the connected account's email is to
    call Google's userinfo endpoint with the fresh access token.
    """
    try:
        resp = httpx.get(
            "https://openidconnect.googleapis.com/v1/userinfo",
            headers={"Authorization": f"Bearer {access_token}"},
            timeout=10,
        )
        resp.raise_for_status()
        return resp.json().get("email", "")
    except Exception:
        return ""


@router.get("/oauth/authorize")
def authorize(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """
    Step 1 of real Google OAuth: confirm the user can access this workspace,
    then redirect them to Google's consent screen. `state` carries the
    workspace_id (signed, so it can't be tampered with) through the redirect.
    """
    get_workspace_or_403(workspace_id, db, user)
    state = _signer.dumps({"workspace_id": str(workspace_id)})
    return RedirectResponse(google_oauth_service.build_authorization_url(state))


@router.get("/oauth/callback")
def callback(code: str, state: str, db: Session = Depends(get_db)):
    """
    Step 2: Google redirects back here with an auth `code`. We exchange it
    for real access + refresh tokens, then store the refresh token ENCRYPTED
    against the workspace encoded in `state`. This is the point where a
    workspace actually becomes connected to a live Google account.
    """
    try:
        payload = _signer.loads(state)
    except BadSignature:
        raise HTTPException(400, "Invalid OAuth state")

    workspace_id = uuid.UUID(payload["workspace_id"])
    creds = google_oauth_service.exchange_code_for_tokens(code, state)

    if not creds.refresh_token:
        raise HTTPException(
            400,
            "Google didn't return a refresh token. This usually means the account "
            "already granted access before — revoke access at "
            "https://myaccount.google.com/permissions and try connecting again.",
        )

    encrypted = encrypt_token(creds.refresh_token)
    google_email = _fetch_google_email(creds.token)
    google_account = GoogleAccount(
        workspace_id=workspace_id,
        google_email=google_email,
        encrypted_refresh_token=encrypted,
        scopes=list(creds.scopes or []),
    )
    db.add(google_account)

    # Try to also register the YouTube channel on the same grant.
    try:
        channel = youtube_service.get_my_channel(creds)
        if channel:
            db.add(YouTubeAccount(
                workspace_id=workspace_id,
                channel_id=channel["id"],
                channel_title=channel.get("snippet", {}).get("title", ""),
                encrypted_refresh_token=encrypted,
            ))
    except Exception:
        pass  # user may not have a YouTube channel — Search Console connection still succeeds

    db.add(AuditLog(action="google_account_connected", meta={"workspace_id": str(workspace_id)}))
    db.commit()

    return RedirectResponse(f"{settings.FRONTEND_URL}/settings/integrations?connected=google")
