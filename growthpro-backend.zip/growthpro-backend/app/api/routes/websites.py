import uuid
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.website import Website

router = APIRouter(prefix="/api/websites", tags=["websites"])


class WebsiteCreate(BaseModel):
    workspace_id: uuid.UUID
    url: str


@router.get("")
def list_websites(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(Website).filter(Website.workspace_id == workspace_id).all()


@router.post("")
def add_website(payload: WebsiteCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Website(workspace_id=payload.workspace_id, url=payload.url)
    db.add(row)
    db.commit()
    db.refresh(row)
    return row
