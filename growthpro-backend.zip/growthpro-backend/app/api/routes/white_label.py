import uuid
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user
from app.models.user import User
from app.models.organization import Organization, Membership, MemberRole
from app.services.white_label_service import resolve_branding

router = APIRouter(prefix="/api/white-label", tags=["white-label"])


class WhiteLabelUpdate(BaseModel):
    organization_id: uuid.UUID
    domain: str | None = None
    logo_url: str | None = None


@router.post("/configure")
def configure_white_label(payload: WhiteLabelUpdate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    membership = db.query(Membership).filter(
        Membership.user_id == user.id, Membership.organization_id == payload.organization_id
    ).first()
    if not membership or membership.role not in (MemberRole.owner, MemberRole.admin):
        raise HTTPException(403, "Only an owner/admin can configure white-label branding")

    org = db.query(Organization).filter(Organization.id == payload.organization_id).first()
    if payload.domain:
        existing = db.query(Organization).filter(Organization.white_label_domain == payload.domain).first()
        if existing and existing.id != org.id:
            raise HTTPException(400, "That domain is already in use by another organization")
        org.white_label_domain = payload.domain
    if payload.logo_url:
        org.white_label_logo_url = payload.logo_url
    db.commit()
    return {
        "configured": True,
        "next_step": f"Point a CNAME record for {payload.domain} to your app's hosting domain, "
                      "then your reverse proxy (Caddy/Traefik/nginx) needs to provision SSL for it — "
                      "see DEPLOYMENT_WHITE_LABEL.md for the exact config.",
    }


@router.get("/resolve")
def resolve(request: Request, db: Session = Depends(get_db)):
    """Frontend calls this on load with its own Host header to know which branding to render."""
    return resolve_branding(db, request.headers.get("host", ""))
