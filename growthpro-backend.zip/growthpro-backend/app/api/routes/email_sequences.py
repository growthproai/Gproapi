"""Email drip sequences (spec section 41 — Marketing Automation, email variant)."""
import uuid
from datetime import datetime, timedelta, timezone
from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.core.limiter import limiter
from app.models.user import User
from app.models.email_sequence import EmailSequence, SequenceEnrollment
from app.services.ai_service import generate_json

router = APIRouter(prefix="/api/email-sequences", tags=["email-sequences"])


class SequenceCreate(BaseModel):
    workspace_id: uuid.UUID
    name: str
    trigger: str = "lead_created"
    steps: list  # [{"delay_days": 0, "subject": "", "body": ""}, ...]


@router.post("")
def create_sequence(payload: SequenceCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = EmailSequence(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.get("")
def list_sequences(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(EmailSequence).filter(EmailSequence.workspace_id == workspace_id).all()


class GenerateSequenceRequest(BaseModel):
    workspace_id: uuid.UUID
    goal: str  # e.g. "welcome new leads", "re-engage cold leads"
    num_emails: int = 3


@router.post("/generate")
@limiter.limit("10/hour")
def generate_sequence(request: Request, payload: GenerateSequenceRequest, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    """AI drafts a full drip sequence — still requires human review before activating (spec section 60)."""
    get_workspace_or_403(payload.workspace_id, db, user)
    result = generate_json(
        system="You are an email marketing strategist. Write genuinely useful, non-spammy emails — no fake urgency, "
               "no manufactured scarcity, no misleading subject lines.",
        user_prompt=f"Goal: {payload.goal}\nNumber of emails: {payload.num_emails}\n"
                    'Return JSON: {"steps":[{"delay_days":0,"subject":"","body":""}, ...]}',
        max_tokens=1500,
    )
    return result


@router.post("/{sequence_id}/enroll")
def enroll_contact(sequence_id: uuid.UUID, workspace_id: uuid.UUID, email: str, lead_id: uuid.UUID | None = None, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    sequence = db.query(EmailSequence).filter(EmailSequence.id == sequence_id).first()
    if not sequence or not sequence.steps:
        return {"error": "Sequence not found or has no steps"}

    first_delay = sequence.steps[0].get("delay_days", 0)
    enrollment = SequenceEnrollment(
        sequence_id=sequence_id, lead_id=lead_id, email=email,
        next_send_at=datetime.now(timezone.utc) + timedelta(days=first_delay),
    )
    db.add(enrollment)
    db.commit()
    db.refresh(enrollment)
    return enrollment


@router.post("/{sequence_id}/toggle")
def toggle_sequence(sequence_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    seq = db.query(EmailSequence).filter(EmailSequence.id == sequence_id).first()
    if seq:
        seq.is_active = not seq.is_active
        db.commit()
    return seq
