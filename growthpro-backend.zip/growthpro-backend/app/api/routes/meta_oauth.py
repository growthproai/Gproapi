import uuid
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse
from sqlalchemy.orm import Session
from itsdangerous import URLSafeSerializer, BadSignature

from app.db.database import get_db
from app.core.config import settings
from app.core.security import encrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.meta_account import MetaAccount
from app.models.audit_log import AuditLog
from app.services import meta_oauth_service

router = APIRouter(prefix="/api/meta", tags=["meta-oauth"])
_signer = URLSafeSerializer(settings.SECRET_KEY, salt="meta-oauth-state")


@router.get("/oauth/authorize")
def authorize(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    state = _signer.dumps({"workspace_id": str(workspace_id)})
    return RedirectResponse(meta_oauth_service.build_authorization_url(state))


@router.get("/oauth/callback")
def callback(code: str, state: str, db: Session = Depends(get_db)):
    try:
        payload = _signer.loads(state)
    except BadSignature:
        raise HTTPException(400, "Invalid OAuth state")
    workspace_id = uuid.UUID(payload["workspace_id"])

    short_token = meta_oauth_service.exchange_code_for_token(code)
    long_token = meta_oauth_service.exchange_for_long_lived_token(short_token)

    pages = meta_oauth_service.get_pages(long_token)
    if not pages:
        raise HTTPException(400, "No Facebook Pages found for this account. You need to manage at least one Page.")

    # MVP: connect the first page returned. A real UI would let the user pick.
    page = pages[0]
    page_access_token = page["access_token"]
    ig_account = meta_oauth_service.get_instagram_business_account(page["id"], page_access_token)

    account = MetaAccount(
        workspace_id=workspace_id,
        facebook_page_id=page["id"],
        facebook_page_name=page.get("name"),
        instagram_business_id=(ig_account or {}).get("id"),
        instagram_username=(ig_account or {}).get("username"),
        encrypted_long_lived_token=encrypt_token(page_access_token),
        scopes=meta_oauth_service.SCOPES,
    )
    db.add(account)
    db.add(AuditLog(action="meta_account_connected", meta={"workspace_id": str(workspace_id), "page": page.get("name")}))
    db.commit()

    return RedirectResponse(f"{settings.FRONTEND_URL}/settings/integrations?connected=meta")
