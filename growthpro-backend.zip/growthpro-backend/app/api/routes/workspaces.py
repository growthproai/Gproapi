import uuid
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.models.workspace import Workspace
from app.models.organization import Membership
from app.schemas.workspace import WorkspaceCreate, WorkspaceOut, BusinessSetupWizard
from app.api.deps import get_current_user
from app.models.user import User

router = APIRouter(prefix="/api/workspaces", tags=["workspaces"])


@router.get("", response_model=list[WorkspaceOut])
def list_workspaces(db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    org_ids = [m.organization_id for m in db.query(Membership).filter(Membership.user_id == user.id)]
    return db.query(Workspace).filter(Workspace.organization_id.in_(org_ids)).all()


@router.post("", response_model=WorkspaceOut)
def create_workspace(
    payload: WorkspaceCreate,
    organization_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    membership = db.query(Membership).filter(
        Membership.user_id == user.id, Membership.organization_id == organization_id
    ).first()
    if not membership:
        raise HTTPException(403, "Not a member of this organization")

    ws = Workspace(organization_id=organization_id, name=payload.name, niche=payload.niche)
    db.add(ws)
    db.commit()
    db.refresh(ws)
    return ws


@router.post("/setup-wizard", response_model=WorkspaceOut)
def business_setup_wizard(
    payload: BusinessSetupWizard,
    organization_id: uuid.UUID,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    """
    Section 4: the guided onboarding form — one call creates a fully-configured
    workspace instead of a bare name, so AI Business Doctor / Growth Score /
    dashboard defaults all have real context from the first moment.
    """
    membership = db.query(Membership).filter(
        Membership.user_id == user.id, Membership.organization_id == organization_id
    ).first()
    if not membership:
        raise HTTPException(403, "Not a member of this organization")

    ws = Workspace(organization_id=organization_id, **payload.model_dump())
    db.add(ws)
    db.commit()
    db.refresh(ws)
    return ws
