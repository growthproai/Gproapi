import uuid
from fastapi import APIRouter, Depends
from pydantic import BaseModel
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.automation import Workflow, WorkflowTrigger, WorkflowRun

router = APIRouter(prefix="/api/automation", tags=["automation"])


class WorkflowCreate(BaseModel):
    workspace_id: uuid.UUID
    name: str
    trigger: WorkflowTrigger
    conditions: list = []
    actions: list = []


@router.get("/workflows")
def list_workflows(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(Workflow).filter(Workflow.workspace_id == workspace_id).all()


@router.post("/workflows")
def create_workflow(payload: WorkflowCreate, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(payload.workspace_id, db, user)
    row = Workflow(**payload.model_dump())
    db.add(row)
    db.commit()
    db.refresh(row)
    return row


@router.post("/workflows/{workflow_id}/toggle")
def toggle_workflow(workflow_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    wf = db.query(Workflow).filter(Workflow.id == workflow_id).first()
    if wf:
        wf.is_active = not wf.is_active
        db.commit()
    return wf


@router.get("/workflows/{workflow_id}/runs")
def workflow_runs(workflow_id: uuid.UUID, workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    return db.query(WorkflowRun).filter(WorkflowRun.workflow_id == workflow_id).order_by(WorkflowRun.ran_at.desc()).limit(50).all()
