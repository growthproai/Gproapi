import uuid
from datetime import date, timedelta
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.db.database import get_db
from app.core.security import decrypt_token
from app.api.deps import get_current_user, get_workspace_or_403
from app.models.user import User
from app.models.google_account import GoogleAccount
from app.services import google_oauth_service, search_console_service

router = APIRouter(prefix="/api/search-console", tags=["search-console"])


def _get_credentials(workspace_id: uuid.UUID, db: Session):
    account = db.query(GoogleAccount).filter(GoogleAccount.workspace_id == workspace_id).first()
    if not account:
        raise HTTPException(404, "No Google account connected for this workspace. Connect via /api/google/oauth/authorize first.")
    refresh_token = decrypt_token(account.encrypted_refresh_token)
    return google_oauth_service.credentials_from_refresh_token(refresh_token)


@router.get("/sites")
def sites(workspace_id: uuid.UUID, db: Session = Depends(get_db), user: User = Depends(get_current_user)):
    get_workspace_or_403(workspace_id, db, user)
    creds = _get_credentials(workspace_id, db)
    return search_console_service.list_sites(creds)


@router.get("/performance")
def performance(
    workspace_id: uuid.UUID,
    site_url: str,
    days: int = 28,
    db: Session = Depends(get_db),
    user: User = Depends(get_current_user),
):
    get_workspace_or_403(workspace_id, db, user)
    creds = _get_credentials(workspace_id, db)
    end = date.today()
    start = end - timedelta(days=days)
    return search_console_service.get_search_performance(
        creds, site_url, start.isoformat(), end.isoformat(), dimensions=["query", "page"]
    )
