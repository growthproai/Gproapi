import uuid
from datetime import datetime
from pydantic import BaseModel


class WorkspaceCreate(BaseModel):
    name: str
    niche: str | None = None


class BusinessSetupWizard(BaseModel):
    """Section 4 — the onboarding form a new workspace fills out once."""
    name: str
    website_url: str | None = None
    industry: str | None = None
    country: str | None = None
    city: str | None = None
    products_services: str | None = None
    target_market: str | None = None
    business_size: str | None = None
    monthly_marketing_budget: str | None = None
    main_goal: str | None = None


class WorkspaceOut(BaseModel):
    id: uuid.UUID
    organization_id: uuid.UUID
    name: str
    niche: str | None = None
    website_url: str | None = None
    industry: str | None = None
    country: str | None = None
    city: str | None = None
    products_services: str | None = None
    target_market: str | None = None
    business_size: str | None = None
    monthly_marketing_budget: str | None = None
    main_goal: str | None = None
    created_at: datetime

    class Config:
        from_attributes = True
