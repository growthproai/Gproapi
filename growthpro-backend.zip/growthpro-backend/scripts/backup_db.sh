#!/usr/bin/env bash
# Daily Postgres backup (spec section 77). Run via cron or a scheduled CI job:
#   0 2 * * * /path/to/scripts/backup_db.sh >> /var/log/growthpro-backup.log 2>&1
set -euo pipefail

BACKUP_DIR="${BACKUP_DIR:-/var/backups/growthpro}"
RETENTION_DAYS="${RETENTION_DAYS:-30}"
TIMESTAMP=$(date +%Y%m%d-%H%M%S)
FILE="$BACKUP_DIR/growthpro-$TIMESTAMP.sql.gz"

mkdir -p "$BACKUP_DIR"
echo "Backing up database to $FILE ..."
pg_dump "$DATABASE_URL" | gzip > "$FILE"

# Optional: upload to S3-compatible storage instead of / in addition to keeping it local.
# aws s3 cp "$FILE" "s3://your-backup-bucket/growthpro/" 

echo "Pruning backups older than $RETENTION_DAYS days ..."
find "$BACKUP_DIR" -name "growthpro-*.sql.gz" -mtime +"$RETENTION_DAYS" -delete

echo "Done: $FILE"
