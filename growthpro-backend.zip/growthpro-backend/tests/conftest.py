"""
Shared test fixtures. Uses an in-memory SQLite DB for speed — this catches
logic bugs (route wiring, response shapes, auth checks) fast, but SQLite
doesn't enforce everything Postgres does (some JSON/array column behaviors
differ), so this is a first safety net, not a substitute for testing
against real Postgres before deploying.
"""
import os
os.environ.setdefault("SECRET_KEY", "test-secret-key")
os.environ.setdefault("TOKEN_ENCRYPTION_KEY", "zx8mM8V0uW8h9y0hxE1kY5c9nJ3lD7qA2sT6vB4wR1o=")
os.environ.setdefault("DATABASE_URL", "sqlite:///:memory:")

import pytest
from fastapi.testclient import TestClient
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker, declarative_base
from sqlalchemy.pool import StaticPool

from app.db.database import Base, get_db
import app.db.base  # noqa: F401 — registers every model on Base.metadata
from app.main import app

engine = create_engine("sqlite:///:memory:", connect_args={"check_same_thread": False}, poolclass=StaticPool)
TestingSessionLocal = sessionmaker(bind=engine)


@pytest.fixture()
def db_session():
    Base.metadata.create_all(bind=engine)
    session = TestingSessionLocal()
    yield session
    session.close()
    Base.metadata.drop_all(bind=engine)


@pytest.fixture()
def client(db_session):
    def override_get_db():
        yield db_session
    app.dependency_overrides[get_db] = override_get_db
    with TestClient(app) as c:
        yield c
    app.dependency_overrides.clear()


@pytest.fixture()
def auth_client(client):
    """Registers a user + org, returns (client, access_token, headers)."""
    resp = client.post("/api/auth/register", json={
        "email": "test@example.com", "password": "testpass123",
        "full_name": "Test User", "organization_name": "Test Org",
    })
    token = resp.json()["access_token"]
    client.headers.update({"Authorization": f"Bearer {token}"})
    return client
