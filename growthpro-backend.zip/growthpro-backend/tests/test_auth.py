def test_register_creates_user_and_org(client):
    resp = client.post("/api/auth/register", json={
        "email": "new@example.com", "password": "securepass123",
        "full_name": "New User", "organization_name": "New Org",
    })
    assert resp.status_code == 200
    assert "access_token" in resp.json()


def test_register_duplicate_email_fails(client):
    payload = {"email": "dup@example.com", "password": "pass12345", "organization_name": "Org"}
    client.post("/api/auth/register", json=payload)
    resp = client.post("/api/auth/register", json=payload)
    assert resp.status_code == 400


def test_login_wrong_password_fails(client):
    client.post("/api/auth/register", json={"email": "u@example.com", "password": "correctpass", "organization_name": "Org"})
    resp = client.post("/api/auth/login", data={"username": "u@example.com", "password": "wrongpass"})
    assert resp.status_code == 401


def test_me_requires_auth(client):
    resp = client.get("/api/auth/me")
    assert resp.status_code == 401


def test_me_returns_current_user(auth_client):
    resp = auth_client.get("/api/auth/me")
    assert resp.status_code == 200
    assert resp.json()["email"] == "test@example.com"
