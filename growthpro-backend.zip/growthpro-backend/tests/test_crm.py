def _create_workspace(auth_client, db_session):
    from app.models.organization import Organization
    org = db_session.query(Organization).first()
    resp = auth_client.post(f"/api/workspaces?organization_id={org.id}", json={"name": "Test WS"})
    return resp.json()["id"]


def test_create_and_list_lead(auth_client, db_session):
    ws_id = _create_workspace(auth_client, db_session)
    resp = auth_client.post("/api/crm/leads", json={"workspace_id": ws_id, "name": "John Doe", "email": "john@example.com"})
    assert resp.status_code == 200
    assert resp.json()["status"] == "new"

    list_resp = auth_client.get(f"/api/crm/leads?workspace_id={ws_id}")
    assert list_resp.status_code == 200
    assert len(list_resp.json()) == 1


def test_deal_pipeline_stage_transition(auth_client, db_session):
    ws_id = _create_workspace(auth_client, db_session)
    deal = auth_client.post("/api/crm/deals", json={"workspace_id": ws_id, "title": "Big Deal", "value": 5000}).json()
    resp = auth_client.post(f"/api/crm/deals/{deal['id']}/stage?workspace_id={ws_id}&stage=won")
    assert resp.status_code == 200
    assert resp.json()["stage"] == "won"
    assert resp.json()["closed_at"] is not None


def test_wallet_debit_fails_on_insufficient_balance(auth_client, db_session):
    from app.models.organization import Organization
    from app.api.routes.wallet import debit_wallet
    from app.models.wallet import TransactionType
    from fastapi import HTTPException

    org = db_session.query(Organization).first()
    try:
        debit_wallet(db_session, org.id, 1000, TransactionType.ad_spend, "test debit")
        assert False, "should have raised"
    except HTTPException as e:
        assert e.status_code == 402
