import uuid


def _get_org_id(client):
    me = client.get("/api/auth/me").json()
    # organization_id isn't on /me — fetch via workspaces list after creating one indirectly.
    # Simplest reliable path for this test: query the DB isn't available here, so we
    # register fresh and capture org id from a workspace list after wizard creation instead.
    return me


def test_workspace_isolation_between_orgs(client, db_session):
    """The core multi-tenant guarantee: user B must never see user A's workspace."""
    client.post("/api/auth/register", json={"email": "a@example.com", "password": "pass12345", "organization_name": "Org A"})
    token_a = client.post("/api/auth/login", data={"username": "a@example.com", "password": "pass12345"}).json()["access_token"]

    client.post("/api/auth/register", json={"email": "b@example.com", "password": "pass12345", "organization_name": "Org B"})
    token_b = client.post("/api/auth/login", data={"username": "b@example.com", "password": "pass12345"}).json()["access_token"]

    from app.models.organization import Organization
    org_a = db_session.query(Organization).filter(Organization.slug == "org-a").first()

    client.headers.update({"Authorization": f"Bearer {token_a}"})
    ws_resp = client.post(f"/api/workspaces?organization_id={org_a.id}", json={"name": "A's Workspace"})
    assert ws_resp.status_code == 200
    ws_id = ws_resp.json()["id"]

    # user B tries to access user A's workspace-scoped data — must be forbidden
    client.headers.update({"Authorization": f"Bearer {token_b}"})
    resp = client.get(f"/api/seo/keywords?workspace_id={ws_id}")
    assert resp.status_code in (403, 404, 405)  # 405 if GET isn't defined on that path — still not a data leak
